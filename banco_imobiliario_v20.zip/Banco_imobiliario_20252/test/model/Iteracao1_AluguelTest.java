package model;

import static org.junit.Assert.*;
import org.junit.*;

/**
 * Regras de aluguel (1ª iteração):
 * - Terreno só cobra com ≥1 casa.
 * - Companhia cobra mesmo sem casa.
 * - Hotel cobra o valor máximo.
 */
public class Iteracao1_AluguelTest {

    private ModelFacade facade;

    @Before
    public void setup() {
        facade = new ModelFacade();
        facade.reset();
        facade.adicionarJogador("A"); // dono
        facade.adicionarJogador("B"); // visitante
    }

    // Funções Auxiliares
    private void moverAte(String nome) {
        int guard = 0;
        while (guard++ < 300) {
            ModelFacade.MovementResult mv = facade.deslocarJogadorDaVez(1);
            if (mv.getNomeEspaco().equalsIgnoreCase(nome)) break;
        }
    }
    private void processHere() { facade.processarCasaAtualDaVez(); }
    private void endTurn()     { facade.finalizarTurno(); }
    private int saldoDaVez()   { return facade.getJogadorDaVezSnapshot().getSaldo(); }

    @Test
    public void aluguel_terrenoECia() {
        // Terreno com 1 casa: B cai em Leblon e paga 30 para A
        moverAte("Leblon");
        assertTrue(facade.comprarPropriedadeAtualDaVez());
        endTurn(); endTurn(); moverAte("Leblon");
        assertTrue(facade.construirNaPropriedadeAtualDaVez());

        endTurn();                // B
        moverAte("Leblon");
        int bAntes = saldoDaVez();
        endTurn(); int aAntes = saldoDaVez(); endTurn();
        processHere();            // B paga
        int bDepois = saldoDaVez();
        endTurn(); int aDepois = saldoDaVez();

        assertEquals(bAntes - 30, bDepois);
        assertEquals(aAntes + 30, aDepois);

        // Companhia sem casa: B cai e paga 25 para A
        endTurn(); endTurn();     // volta A
        moverAte("Companhia de Viação");
        assertTrue(facade.comprarPropriedadeAtualDaVez());

        endTurn();                // B
        moverAte("Companhia de Viação");
        int b2Antes = saldoDaVez();
        endTurn(); int a2Antes = saldoDaVez(); endTurn();
        processHere();            // B paga
        int b2Depois = saldoDaVez();
        endTurn(); int a2Depois = saldoDaVez();

        assertEquals(b2Antes - 25, b2Depois);
        assertEquals(a2Antes + 25, a2Depois);
    }

    @Test
    public void terrenoSemCasa_naoCobra() {
        // B cai em terreno de A sem construção: ninguém paga/recebe
        moverAte("Leblon");
        assertTrue(facade.comprarPropriedadeAtualDaVez());

        endTurn();                // B
        moverAte("Leblon");
        int bAntes = saldoDaVez();
        endTurn(); int aAntes = saldoDaVez(); endTurn();

        processHere();            // sem cobrança

        int bDepois = saldoDaVez();
        endTurn(); int aDepois = saldoDaVez();

        assertEquals(bAntes, bDepois);
        assertEquals(aAntes, aDepois);
    }

    @Test
    public void aluguelComHotel() {
        // B cai em terreno de A com hotel: débito/crédito de 550
        moverAte("Leblon"); assertTrue(facade.comprarPropriedadeAtualDaVez());
        for (int i = 0; i < 4; i++) { endTurn(); endTurn(); moverAte("Leblon"); assertTrue(facade.construirNaPropriedadeAtualDaVez()); }
        endTurn(); endTurn(); moverAte("Leblon"); assertTrue(facade.construirNaPropriedadeAtualDaVez()); // hotel

        endTurn();                // B
        moverAte("Leblon");
        int bAntes = saldoDaVez();
        endTurn(); int aAntes = saldoDaVez(); endTurn();

        processHere();            // B paga hotel

        int bDepois = saldoDaVez();
        endTurn(); int aDepois = saldoDaVez();

        assertEquals(bAntes - 550, bDepois);
        assertEquals(aAntes + 550, aDepois);
    }
}
