package model;

import static org.junit.Assert.*;
import org.junit.*;

/**
 * Movimento e Bônus (1ª iteração):
 * - 40 passos → volta à mesma posição e ganha bônus da Partida.
 * - Rolar dados e mover a soma → cai na casa esperada.
 */
public class Iteracao1_MovimentoEBonusTest {

    private ModelFacade facade;

    @Before
    public void setup() {
        facade = new ModelFacade();
        facade.reset();
        facade.adicionarJogador("A");
        facade.adicionarJogador("B");
    }

    // Funções Auxiliares
    private int saldoDaVez() { return facade.getJogadorDaVezSnapshot().getSaldo(); }
    private int posDaVez()   { return facade.getJogadorDaVezSnapshot().getPosicao(); }

    @Test
    public void passarPartidaCredito() {
        // Completar 1 volta credita o bônus e mantém a posição congruente
        int saldoAntes = saldoDaVez();
        int posAntes   = posDaVez();

        facade.deslocarJogadorDaVez(40);

        assertEquals(posAntes, posDaVez());
        assertEquals(saldoAntes + Regras.BONUS_PARTIDA, saldoDaVez());
    }

    @Test
    public void rolarDados_e_moverPelaSoma() {
        // Rola os dados, move a soma e confere posição e MovementResult
        int posInicial = posDaVez();

        int[] d = facade.lancarDados();
        assertEquals(2, d.length);
        assertTrue(d[0] >= 1 && d[0] <= 6);
        assertTrue(d[1] >= 1 && d[1] <= 6);

        int soma = d[0] + d[1];
        ModelFacade.MovementResult mv = facade.deslocarJogadorDaVez(soma);

        int esperado = (posInicial + soma) % 40;
        assertEquals(esperado, posDaVez());
        assertEquals(esperado, mv.getNovaPosicao());
        assertNotNull(mv.getNomeEspaco());
        assertFalse(mv.getNomeEspaco().isBlank());
    }
}
