package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Fachada do modelo do jogo.
 *
 * É a camada que concentra:
 * - estado dos jogadores e do tabuleiro;
 * - regras de movimento, prisão, compra, construção e venda;
 * - aplicação das cartas de Sorte/Revés;
 * - lógica de save/load em arquivo texto;
 * - regra extra de construção baseada em histórico de visitas do dono.
 *
 * A View nunca fala direto com as classes internas do model, só com esta fachada.
 */
public class ModelFacade {

    // ===== DTOs expostos para a camada de UI =====

    /**
     * Snapshot imutável de um jogador (usado pela UI sem expor Jogador).
     */
    public static final class PlayerSnapshot {
        private final String nome;
        private final int saldo;
        private final int posicao;
        private final boolean preso;
        private final int qtdProps;

        public PlayerSnapshot(String nome, int saldo, int posicao, boolean preso, int qtdProps) {
            this.nome = nome;
            this.saldo = saldo;
            this.posicao = posicao;
            this.preso = preso;
            this.qtdProps = qtdProps;
        }

        public String getNome()    { return nome; }
        public int getSaldo()      { return saldo; }
        public int getPosicao()    { return posicao; }
        public boolean isPreso()   { return preso; }
        public int getQtdProps()   { return qtdProps; }
    }

    /**
     * Resultado de um movimento: nova posição, nome e tipo do espaço.
     * Serve para a UI conseguir escrever log e saber o que aconteceu.
     */
    public static final class MovementResult {
        private final int novaPosicao;
        private final String nomeCasa;
        private final Espaco.Tipo tipo;
        private final boolean companhia;

        public MovementResult(int novaPosicao, String nomeCasa, Espaco.Tipo tipo, boolean companhia) {
            this.novaPosicao = novaPosicao;
            this.nomeCasa = nomeCasa;
            this.tipo = tipo;
            this.companhia = companhia;
        }

        public int getNovaPosicao() { return novaPosicao; }
        public String getNomeCasa() { return nomeCasa; }
        public String getNomeEspaco() { return nomeCasa; }
        public String getTipoNome() { return (tipo == null ? "" : tipo.name()); }
        public boolean isPropriedade() { return tipo == Espaco.Tipo.PROPRIEDADE; }
        public boolean isCompanhia() { return companhia; }
        public boolean isSorteOuReves() { return tipo == Espaco.Tipo.SORTE_OU_REVES; }
    }

    /**
     * Snapshot de uma propriedade de jogador (para listar na UI).
     */
    public static final class PropriedadeSnapshot {
        private final String nome;
        private final int casas;
        private final boolean hotel;
        private final int preco;
        private final int precoConstrucao;

        public PropriedadeSnapshot(String nome, int casas, boolean hotel, int preco, int precoConstrucao) {
            this.nome = nome;
            this.casas = casas;
            this.hotel = hotel;
            this.preco = preco;
            this.precoConstrucao = precoConstrucao;
        }

        public String getNome()             { return nome; }
        public int getCasas()               { return casas; }
        public boolean isHotel()            { return hotel; }
        public int getPreco()               { return preco; }
        public int getPrecoConstrucao()     { return precoConstrucao; }
    }

    /**
     * Informações da propriedade onde o jogador da vez está parado.
     */
    public static final class PropriedadeInfo {
        private final String nome;
        private final int preco;
        private final int precoConstrucao;
        private final int casas;
        private final boolean hotel;
        private final String donoNome;
        private final boolean companhia;

        public PropriedadeInfo(String nome, int preco, int precoConstrucao,
                               int casas, boolean hotel,
                               String donoNome, boolean companhia) {
            this.nome = nome;
            this.preco = preco;
            this.precoConstrucao = precoConstrucao;
            this.casas = casas;
            this.hotel = hotel;
            this.donoNome = donoNome;
            this.companhia = companhia;
        }

        public String getNome()             { return nome; }
        public int getPreco()               { return preco; }
        public int getPrecoConstrucao()     { return precoConstrucao; }
        public int getCasas()               { return casas; }
        public boolean isHotel()            { return hotel; }
        public String getDonoNome()         { return donoNome; }
        public boolean isCompanhia()        { return companhia; }
    }

    // ===== Estado interno do jogo =====

    private final Tabuleiro tabuleiro = new Tabuleiro();
    private final List<Jogador> jogadores = new ArrayList<>();
    private int indiceJogadorAtual = 0;

    /**
     * Controle de visitas do dono por propriedade.
     * Regra usada para limitar construções:
     * total de construções permitidas (casas + hotel) = visitasDoDono - 1.
     */
    private final HashMap<Propriedade, Integer> visitasDoDono = new HashMap<>();

    // Baralho de Sorte/Revés e última carta exibida
    private final BaralhoSorteReves baralho = new BaralhoSorteReves();
    private String ultimaCartaImagemPath = null;
    private boolean cartaSorteRevesAtiva = false;
    private int ultimaSomaDados = 0;

    // ===== Helpers para SAVE/LOAD =====

    /** Busca um jogador pelo nome exato, ou null se não achar. */
    private Jogador encontrarJogadorPorNome(String nome) {
        if (nome == null) return null;
        for (Jogador j : jogadores) {
            if (nome.equals(j.getNome())) return j;
        }
        return null;
    }

    /** Converte string em int com valor padrão em caso de erro. */
    private int parseIntSafe(String s, int defaultValue) {
        if (s == null) return defaultValue;
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    // ===== Setup básico =====

    /**
     * Limpa todo o estado do jogo (jogadores, cartas ativas, visitas).
     * Usado antes de iniciar uma nova partida ou ao importar um save.
     */
    public void reset() {
        jogadores.clear();
        indiceJogadorAtual = 0;
        cartaSorteRevesAtiva = false;
        ultimaCartaImagemPath = null;
        visitasDoDono.clear();
        ultimaSomaDados = 0;
    }

    /**
     * Adiciona um novo jogador com saldo inicial padrão.
     */
    public void adicionarJogador(String nome) {
        jogadores.add(new Jogador(nome, Regras.SALDO_INICIAL));
    }

    // ===== Consultas de jogador =====

    private Jogador jogadorDaVez() {
        return jogadores.get(indiceJogadorAtual);
    }

    /**
     * Retorna um snapshot do jogador da vez.
     */
    public PlayerSnapshot getJogadorDaVezSnapshot() {
        Jogador j = jogadorDaVez();
        return new PlayerSnapshot(
                j.getNome(),
                j.getSaldo(),
                j.getPosicao(),
                j.isPreso(),
                j.getPropriedades().size()
        );
    }

    /**
     * Retorna snapshots de todos os jogadores na ordem atual.
     */
    public List<PlayerSnapshot> getJogadoresSnapshot() {
        List<PlayerSnapshot> out = new ArrayList<>();
        for (Jogador j : jogadores) {
            out.add(new PlayerSnapshot(
                    j.getNome(),
                    j.getSaldo(),
                    j.getPosicao(),
                    j.isPreso(),
                    j.getPropriedades().size()
            ));
        }
        return Collections.unmodifiableList(out);
    }

    /**
     * Retorna info da propriedade onde o jogador da vez está,
     * ou null se não estiver em uma propriedade.
     */
    public PropriedadeInfo getPropriedadeAtualInfo() {
        Jogador j = jogadorDaVez();
        Espaco e = tabuleiro.getEspaco(j.getPosicao());
        if (!(e instanceof Propriedade)) return null;

        Propriedade p = (Propriedade) e;
        String donoNome = (p.getDono() != null ? p.getDono().getNome() : null);
        boolean companhia = p.getPrecoConstrucao() <= 0;

        return new PropriedadeInfo(
                p.getNome(),
                p.getPreco(),
                p.getPrecoConstrucao(),
                p.getCasas(),
                p.isHotel(),
                donoNome,
                companhia
        );
    }

    /**
     * Jogo é considerado encerrado quando só resta 1 jogador ativo.
     */
    public boolean jogoEncerrado() {
        int vivos = 0;
        for (Jogador j : jogadores) {
            if (j.estaAtivo()) vivos++;
        }
        return vivos <= 1;
    }

    // ===== Regra nova de construção baseada em visitas =====

    /** Total de construções já feitas na propriedade (casas + hotel). */
    private static int construcoesRealizadas(Propriedade p) {
        return p.getCasas() + (p.isHotel() ? 1 : 0);
    }

    /** Número de visitas do dono registradas para essa propriedade. */
    private int visitasDoDono(Propriedade p) {
        return visitasDoDono.getOrDefault(p, 0);
    }

    /**
     * Ao comprar uma propriedade, considera que o dono já fez 1 visita.
     */
    private void inicializarVisitaAoComprar(Propriedade p) {
        visitasDoDono.put(p, 1);
    }

    /**
     * Ao cair na própria propriedade, incrementa a contagem de visitas do dono.
     */
    private void registrarVisitaSeDono(Jogador j, Propriedade p) {
        if (p.getDono() == j) {
            int v = visitasDoDono.getOrDefault(p, 0);
            v = (v == 0) ? 1 : (v + 1);
            visitasDoDono.put(p, v);
        }
    }

    /**
     * Remove o contador de visitas de uma propriedade (após venda/falência).
     */
    private void limparVisitas(Propriedade p) {
        visitasDoDono.remove(p);
    }

    /**
     * Regra: só pode construir se construcoesRealizadas < visitasDoDono - 1.
     */
    private boolean podeConstruirPeloHistorico(Propriedade p) {
        if (p.getPrecoConstrucao() <= 0) return false; // companhia não constrói
        int construcoes = construcoesRealizadas(p);
        int limiteTotalPermitido = visitasDoDono(p) - 1;
        return construcoes < limiteTotalPermitido;
    }

    // ===== Dados e movimento =====

    /**
     * Rola dois dados e retorna valores individuais.
     */
    public int[] lancarDados() {
        return Dado.rolarDois();
    }

    /**
     * Move o jogador da vez um número fixo de casas.
     * Aplica bônus de partida ao dar a volta.
     */
    public MovementResult deslocarJogadorDaVez(int passos) {
        Jogador j = jogadorDaVez();
        int posAnterior = j.getPosicao();
        int tamanho = tabuleiro.tamanho();
        int soma = posAnterior + passos;
        int novaPos = soma % tamanho;

        if (soma >= tamanho) j.creditar(Regras.BONUS_PARTIDA);

        j.setPosicao(novaPos);
        ultimaSomaDados = passos;
        Espaco e = tabuleiro.getEspaco(novaPos);
        boolean companhia = (e instanceof Propriedade)
                && ((Propriedade) e).getPrecoConstrucao() <= 0;

        return new MovementResult(novaPos, e.getNome(), e.getTipo(), companhia);
    }

    /**
     * Fluxo padrão de jogar os dados da vez:
     * - trata duplas e possível ida à prisão por 3 duplas;
     * - movimenta o peão;
     * - limpa qualquer carta Sorte/Revés pendente.
     */
    public MovementResult jogarDadosDaVez(int d1, int d2) {
        Jogador j = jogadorDaVez();
        ultimaSomaDados = d1 + d2;

        if (d1 == d2) {
            j.registrarDupla();
            if (j.getDuplasSeguidas() >= 3) {
                j.enviarParaPrisao(tabuleiro.getIndicePrisao());
                j.resetarDuplas();
                cartaSorteRevesAtiva = false;
                ultimaCartaImagemPath = null;
                return new MovementResult(j.getPosicao(), "Prisao", Espaco.Tipo.PRISAO, false);
            }
        } else {
            j.resetarDuplas();
        }

        int passos = d1 + d2;
        int posAnterior = j.getPosicao();
        int tamanho = tabuleiro.tamanho();
        int soma = posAnterior + passos;
        int novaPos = soma % tamanho;

        if (soma >= tamanho) j.creditar(Regras.BONUS_PARTIDA);
        j.setPosicao(novaPos);

        Espaco e = tabuleiro.getEspaco(novaPos);
        boolean companhia = (e instanceof Propriedade)
                && ((Propriedade) e).getPrecoConstrucao() <= 0;

        cartaSorteRevesAtiva = false;
        ultimaCartaImagemPath = null;

        return new MovementResult(novaPos, e.getNome(), e.getTipo(), companhia);
    }

    // ===== Prisão =====

    /**
     * Tenta usar uma carta "Sair da prisão" para o jogador da vez.
     * Retorna true se havia carta e o jogador foi libertado.
     */
    public boolean usarCartaSairLivreDaVez() {
        Jogador j = jogadorDaVez();
        if (j.consumirCartaSaidaLivreSeDisponivel()) {
            j.sairDaPrisao();
            return true;
        }
        return false;
    }

    /**
     * Tenta libertar o jogador da vez com base nos dados tirados.
     * - Se for dupla, sai da prisão.
     * - Caso contrário, conta mais um turno preso e pode pagar multa ao atingir o limite.
     */
    public boolean tentarSairDaPrisaoComDadosDaVez(int d1, int d2) {
        Jogador j = jogadorDaVez();
        if (!j.isPreso()) return true;

        if (d1 == d2) {
            j.sairDaPrisao();
            return true;
        }

        j.incrementarTurnoPrisao();
        if (j.getTurnosNaPrisao() >= Regras.TURNOS_MAX_PRISAO) {
            j.debitar(Regras.MULTA_SAIDA_PRISAO);
            j.sairDaPrisao();
            return true;
        }
        return false;
    }

    /**
     * Concede uma carta "Sair da prisão" para o jogador da vez.
     */
    public void concederCartaSairLivreJogadorDaVez() {
        Jogador j = jogadorDaVez();
        if (j != null) j.ganharCartaSaidaLivre();
    }

    // ===== Processamento da casa atual =====

    /**
     * Processa o efeito da casa onde o jogador da vez parou:
     * prisão, sorte/revés, aluguel, lucros, imposto etc.
     * Também controla a carta Sorte/Revés ativa e visitas para construção.
     */
    public void processarCasaAtualDaVez() {
        Jogador j = jogadorDaVez();
        Espaco e = tabuleiro.getEspaco(j.getPosicao());
        System.out.println("[DEBUG CASA] pos=" + j.getPosicao() + " tipo=" + e.getTipo());

        switch (e.getTipo()) {
            case VA_PARA_PRISAO:
                j.enviarParaPrisao(tabuleiro.getIndicePrisao());
                cartaSorteRevesAtiva = false;
                ultimaCartaImagemPath = null;
                break;

            case SORTE_OU_REVES: {
                CartaSorteReves carta = baralho.comprar();
                carta.aplicar(j, jogadores, tabuleiro);
                cartaSorteRevesAtiva = true;
                ultimaCartaImagemPath = carta.getImagemPath();
                break;
            }

            case PROPRIEDADE: {
                Propriedade p = (Propriedade) e;
                Jogador dono = p.getDono();

                // Aluguel quando a propriedade tem dono e não é o próprio jogador
                if (dono != null && dono != j) {
                    boolean ehCompanhia = p.getPrecoConstrucao() <= 0;
                    if (ehCompanhia) {
                        int base = p.calcularAluguel();
                        int multiplicador = ultimaSomaDados > 0 ? ultimaSomaDados : 1;
                        int aluguel = base * multiplicador;
                        j.debitar(aluguel);
                        dono.creditar(aluguel);
                    } else {
                        if (p.getCasas() > 0 || p.isHotel()) {
                            int aluguel = p.calcularAluguel();
                            j.debitar(aluguel);
                            dono.creditar(aluguel);
                        }
                    }
                }

                // Se caiu na própria propriedade, registra visita (para construção futura)
                if (dono == j) {
                    registrarVisitaSeDono(j, p);
                }

                cartaSorteRevesAtiva = false;
                ultimaCartaImagemPath = null;
                break;
            }

            case LUCROS_DIVIDENDOS: {
                int antes = j.getSaldo();
                j.creditar(Regras.LUCROS_DIVIDENDOS_VALOR);
                int delta = j.getSaldo() - antes;
                System.out.println("[DEBUG DIVIDENDOS] +" + Regras.LUCROS_DIVIDENDOS_VALOR + " (delta=" + delta + ")");
                cartaSorteRevesAtiva = false;
                ultimaCartaImagemPath = null;
                break;
            }

            case PARADA_LIVRE:
                cartaSorteRevesAtiva = false;
                ultimaCartaImagemPath = null;
                break;

            case IMPOSTO:
                j.debitar(Regras.IMPOSTO_RENDA_VALOR);
                cartaSorteRevesAtiva = false;
                ultimaCartaImagemPath = null;
                break;

            case PRISAO:
            case PARTIDA:
            default:
                cartaSorteRevesAtiva = false;
                ultimaCartaImagemPath = null;
                break;
        }
    }

    // ===== Propriedade: compra, construção, venda =====

    /**
     * Tenta comprar a propriedade onde o jogador da vez está.
     * Respeita saldo e se já tem dono.
     */
    public boolean comprarPropriedadeAtualDaVez() {
        Jogador j = jogadorDaVez();
        Espaco e = tabuleiro.getEspaco(j.getPosicao());
        if (!(e instanceof Propriedade)) return false;

        Propriedade p = (Propriedade) e;
        if (p.getDono() != null) return false;
        if (j.getSaldo() < p.getPreco()) return false;

        j.debitar(p.getPreco());
        p.setDono(j);
        j.adicionarPropriedade(p);

        // Primeira visita considerada na compra
        inicializarVisitaAoComprar(p);
        return true;
    }

    /**
     * Tenta construir na propriedade onde o jogador da vez está.
     * Verifica:
     * - se é dono;
     * - se não é companhia;
     * - se ainda não chegou em hotel;
     * - se tem saldo;
     * - se passou na regra de histórico de visitas.
     */
    public boolean construirNaPropriedadeAtualDaVez() {
        Jogador j = jogadorDaVez();
        Espaco e = tabuleiro.getEspaco(j.getPosicao());
        if (!(e instanceof Propriedade)) return false;

        Propriedade p = (Propriedade) e;

        if (p.getDono() != j) return false;
        if (p.isHotel()) return false;
        if (p.getPrecoConstrucao() <= 0) return false;
        if (j.getSaldo() < p.getPrecoConstrucao()) return false;

        if (!podeConstruirPeloHistorico(p)) return false;

        // Constrói apenas uma etapa (casa ou hotel)
        j.debitar(p.getPrecoConstrucao());
        p.construirCasaOuHotel();
        return true;
    }

    /**
     * Retorna as propriedades do jogador da vez em forma de snapshot.
     */
    public List<PropriedadeSnapshot> getPropriedadesDoJogadorDaVez() {
        Jogador j = jogadorDaVez();
        List<PropriedadeSnapshot> out = new ArrayList<>();
        for (Propriedade p : j.getPropriedades()) {
            out.add(new PropriedadeSnapshot(
                    p.getNome(),
                    p.getCasas(),
                    p.isHotel(),
                    p.getPreco(),
                    p.getPrecoConstrucao()
            ));
        }
        return out;
    }

    /**
     * Tenta vender uma propriedade pelo nome de volta ao banco.
     * Se vender, remove do jogador e limpa o contador de visitas.
     */
    public boolean venderPropriedadePorNome(String nome) {
        Jogador j = jogadorDaVez();
        Propriedade p = tabuleiro.encontrarPropriedadePorNome(nome);
        if (p == null || p.getDono() != j) return false;

        boolean ok = p.venderDeVoltaAoBanco(j);
        if (ok) {
            j.removerPropriedade(p);
            limparVisitas(p);
        }
        return ok;
    }

    /**
     * Remove jogadores falidos, devolvendo suas propriedades ao banco,
     * e ajusta o índice do jogador atual.
     */
    private void removerFalidos() {
        if (jogadores.isEmpty()) return;

        for (int i = jogadores.size() - 1; i >= 0; i--) {
            Jogador j = jogadores.get(i);
            if (!j.estaAtivo()) {
                for (Propriedade p : j.limparPropriedades()) {
                    p.resetarParaBanco();
                    limparVisitas(p);
                }
                jogadores.remove(i);
                if (i < indiceJogadorAtual) indiceJogadorAtual--;
            }
        }

        if (indiceJogadorAtual < 0 && !jogadores.isEmpty()) indiceJogadorAtual = 0;
        if (indiceJogadorAtual >= jogadores.size() && !jogadores.isEmpty()) indiceJogadorAtual = 0;
    }

    /**
     * Finaliza o turno do jogador atual:
     * - reseta duplas;
     * - remove falidos;
     * - avança o índice da vez;
     * - limpa qualquer carta Sorte/Revés ativa.
     */
    public void finalizarTurno() {
        jogadorDaVez().resetarDuplas();
        removerFalidos();
        if (jogadores.isEmpty()) return;

        indiceJogadorAtual = (indiceJogadorAtual + 1) % jogadores.size();
        cartaSorteRevesAtiva = false;
        ultimaCartaImagemPath = null;
    }

    /**
     * Embaralha a ordem dos jogadores no início de uma partida.
     */
    public void embaralharOrdemJogadores() {
        if (jogadores.size() <= 1) return;
        java.util.Collections.shuffle(jogadores, new java.util.Random());
        indiceJogadorAtual = 0;
    }

    // ===== SAVE / LOAD em texto =====

    /**
     * Exporta o estado atual do jogo em formato de texto simples.
     *
     * Formato:
     *   BANCO_IMOBILIARIO_SAVE_V1
     *   JOGADOR_ATUAL;indice
     *   PLAYER;nome;saldo;posicao;preso(0/1)
     *   PROP;nomePropriedade;donoOu-;casas;hotel(0/1)
     */
    public List<String> exportarEstadoComoTexto() {
        List<String> linhas = new ArrayList<>();

        linhas.add("BANCO_IMOBILIARIO_SAVE_V1");
        linhas.add("JOGADOR_ATUAL;" + indiceJogadorAtual);

        for (Jogador j : jogadores) {
            StringBuilder sb = new StringBuilder();
            sb.append("PLAYER;");
            sb.append(j.getNome()).append(';');
            sb.append(j.getSaldo()).append(';');
            sb.append(j.getPosicao()).append(';');
            sb.append(j.isPreso() ? "1" : "0");
            linhas.add(sb.toString());
        }

        int n = tabuleiro.tamanho();
        for (int i = 0; i < n; i++) {
            Espaco e = tabuleiro.getEspaco(i);
            if (e instanceof Propriedade) {
                Propriedade p = (Propriedade) e;
                Jogador dono = p.getDono();
                String donoNome = (dono == null ? "-" : dono.getNome());
                StringBuilder sb = new StringBuilder();
                sb.append("PROP;");
                sb.append(p.getNome()).append(';');
                sb.append(donoNome).append(';');
                sb.append(p.getCasas()).append(';');
                sb.append(p.isHotel() ? "1" : "0");
                linhas.add(sb.toString());
            }
        }

        return linhas;
    }

    /**
     * Recria o estado do jogo a partir de um arquivo exportado.
     * Lança IllegalArgumentException se o formato não bater com o esperado.
     */
    public void importarEstadoDeTexto(List<String> linhas) {
        if (linhas == null || linhas.isEmpty()) {
            throw new IllegalArgumentException("Arquivo de save vazio.");
        }

        int idx = 0;
        String cabecalho = linhas.get(idx++).trim();
        if (!"BANCO_IMOBILIARIO_SAVE_V1".equals(cabecalho)) {
            throw new IllegalArgumentException("Formato de save desconhecido.");
        }

        int indiceAtualLido = 0;
        List<String[]> playersRaw = new ArrayList<>();
        List<String[]> propsRaw   = new ArrayList<>();

        for (; idx < linhas.size(); idx++) {
            String linha = linhas.get(idx);
            if (linha == null) continue;
            linha = linha.trim();
            if (linha.isEmpty()) continue;

            String[] partes = linha.split(";");
            if (partes.length == 0) continue;

            String tag = partes[0];
            if ("JOGADOR_ATUAL".equals(tag)) {
                if (partes.length > 1) {
                    indiceAtualLido = parseIntSafe(partes[1], 0);
                }
            } else if ("PLAYER".equals(tag)) {
                playersRaw.add(partes);
            } else if ("PROP".equals(tag)) {
                propsRaw.add(partes);
            }
        }

        // Limpa estado atual
        reset();

        // Recria jogadores
        for (String[] p : playersRaw) {
            if (p.length < 5) continue;
            String nome   = p[1];
            int saldo     = parseIntSafe(p[2], Regras.SALDO_INICIAL);
            int posicao   = parseIntSafe(p[3], 0);
            boolean preso = "1".equals(p[4]) || "true".equalsIgnoreCase(p[4]);

            adicionarJogador(nome);
            Jogador j = jogadores.get(jogadores.size() - 1);

            int delta = saldo - Regras.SALDO_INICIAL;
            if (delta > 0) j.creditar(delta);
            else if (delta < 0) j.debitar(-delta);

            if (preso) {
                j.enviarParaPrisao(tabuleiro.getIndicePrisao());
            } else {
                j.setPosicao(posicao);
                j.sairDaPrisao();
            }
        }

        visitasDoDono.clear();

        // Recria propriedades e reconstruções
        for (String[] p : propsRaw) {
            if (p.length < 5) continue;
            String nomeProp = p[1];
            String donoNome = p[2];
            int casas       = parseIntSafe(p[3], 0);
            boolean hotel   = "1".equals(p[4]) || "true".equalsIgnoreCase(p[4]);

            Propriedade prop = tabuleiro.encontrarPropriedadePorNome(nomeProp);
            if (prop == null) continue;

            prop.resetarParaBanco();

            if (donoNome != null && !"-".equals(donoNome) && !donoNome.isEmpty()) {
                Jogador dono = encontrarJogadorPorNome(donoNome);
                if (dono != null) {
                    prop.setDono(dono);
                    dono.adicionarPropriedade(prop);

                    int construcoes = construcoesRealizadas(prop);
                    int visitas = construcoes + 1;
                    if (visitas < 1) visitas = 1;
                    visitasDoDono.put(prop, visitas);
                }
            }

            prop.carregarEstadoConstrucoes(casas, hotel);
        }

        // Ajusta índice do jogador da vez
        if (jogadores.isEmpty()) {
            indiceJogadorAtual = 0;
        } else {
            if (indiceAtualLido < 0) indiceAtualLido = 0;
            if (indiceAtualLido >= jogadores.size()) indiceAtualLido = 0;
            indiceJogadorAtual = indiceAtualLido;
        }

        cartaSorteRevesAtiva = false;
        ultimaCartaImagemPath = null;
        ultimaSomaDados = 0;
    }

    // ===== Integração com a UI via GameManager =====

    /**
     * Indica se há uma carta Sorte/Revés atualmente ativa para exibição.
     */
    public boolean temCartaSorteRevesAtiva() {
        return cartaSorteRevesAtiva && ultimaCartaImagemPath != null;
    }

    /**
     * Caminho da imagem da última carta Sorte/Revés aplicada.
     */
    public String getUltimaCartaImagemPath() {
        return ultimaCartaImagemPath;
    }

    /**
     * Limpa a carta Sorte/Revés ativa (usado quando a UI "fecha" a carta).
     */
    public void limparCartaSorteReves() {
        cartaSorteRevesAtiva = false;
        ultimaCartaImagemPath = null;
    }
}
