package model;

import java.util.List;

/**
 * Representa uma carta de Sorte/Revés do jogo
 * (como as cartas de “Chance” do Banco Imobiliário).
 *
 * Cada carta tem:
 * - um id (1..30) que casa com a imagem chance<id>.png
 * - um tipo geral (SORTE ou REVES)
 * - um efeito (receber, pagar, ir para prisão, etc.)
 * - um valor numérico usado em alguns efeitos
 */
class CartaSorteReves {

    /** Indica se a carta é “boa” (SORTE) ou “ruim” (REVÉS). */
    public enum Tipo { SORTE, REVES }

    /**
     * Tipo de efeito que a carta produz no jogo.
     * Cada valor corresponde a uma regra específica de movimentação e dinheiro.
     */
    public enum Efeito {
        RECEBER,            // jogador ganha um valor fixo
        PAGAR,              // jogador paga um valor fixo
        RECEBER_DE_CADA,    // jogador recebe um valor de cada outro jogador
        IR_PARA_PRISAO,     // jogador vai direto para a prisão
        AVANCAR_PARTIDA,    // jogador vai para a partida e recebe o bônus
        CARTA_SAIDA_LIVRE   // jogador ganha carta de “Saída Livre da Prisão”
    }

    private final int id;              // 1..30, usado para escolher a imagem
    private final Tipo tipo;           // SORTE ou REVES
    private final Efeito efeito;       // regra aplicada pela carta
    private final int valor;           // usado em efeitos que mexem com dinheiro
    private final String descricaoCurta; // texto resumido, útil para log/debug

    /**
     * Cria uma carta de Sorte/Revés totalmente definida.
     *
     * @param id             identificador da carta (para casar com a imagem)
     * @param tipo           se é carta de sorte ou revés
     * @param efeito         tipo de efeito que será aplicado no jogo
     * @param valor          valor em dinheiro usado pelo efeito (se aplicável)
     * @param descricaoCurta descrição curta, usada para mensagens e logs
     */
    public CartaSorteReves(int id, Tipo tipo, Efeito efeito, int valor, String descricaoCurta) {
        this.id = id;
        this.tipo = tipo;
        this.efeito = efeito;
        this.valor = valor;
        this.descricaoCurta = descricaoCurta;
    }

    public int getId() { return id; }
    public Tipo getTipo() { return tipo; }
    public Efeito getEfeito() { return efeito; }
    public int getValor() { return valor; }
    public String getDescricaoCurta() { return descricaoCurta; }

    /**
     * Devolve o caminho da imagem correspondente a esta carta.
     * Ex.: id=3 -> "imagem/sorteReves/chance3.png".
     */
    public String getImagemPath() {
        return "imagem/sorteReves/chance" + id + ".png";
    }

    /**
     * Aplica o efeito da carta no jogador atual e, quando necessário,
     * também nos demais jogadores ou na posição no tabuleiro.
     *
     * @param atual     jogador que comprou a carta
     * @param todos     lista de todos os jogadores da partida
     * @param tabuleiro tabuleiro atual, usado para saber índices de partida e prisão
     */
    public void aplicar(Jogador atual, List<Jogador> todos, Tabuleiro tabuleiro) {
        switch (efeito) {
            case RECEBER:
                atual.creditar(valor);
                break;

            case PAGAR:
                atual.debitar(valor);
                break;

            case RECEBER_DE_CADA:
                for (Jogador j : todos) {
                    if (j != atual && j.estaAtivo()) {
                        j.debitar(valor);
                        atual.creditar(valor);
                    }
                }
                break;

            case IR_PARA_PRISAO:
                atual.enviarParaPrisao(tabuleiro.getIndicePrisao());
                break;

            case AVANCAR_PARTIDA:
                // Move direto para a partida e aplica o bônus de saída
                int partida = tabuleiro.getIndicePartida();
                atual.setPosicao(partida);
                atual.creditar(Regras.BONUS_PARTIDA);
                break;

            case CARTA_SAIDA_LIVRE:
                atual.ganharCartaSaidaLivre();
                break;
        }
    }
}
