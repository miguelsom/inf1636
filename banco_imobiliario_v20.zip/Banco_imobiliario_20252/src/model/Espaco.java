package model;

/**
 * Representa um espaço genérico do tabuleiro.
 * Cada espaço tem um nome visível e um tipo que define seu comportamento.
 */
abstract class Espaco {

    /**
     * Tipos possíveis de espaços do tabuleiro.
     */
    enum Tipo {
        PARTIDA,          // casa inicial / ponto de partida
        PROPRIEDADE,      // terreno ou companhia negociável
        SORTE_OU_REVES,   // casa de compra de carta sorte/revés
        PRISAO,           // prisão (apenas visita ao cair aqui)
        VA_PARA_PRISAO,   // envia o jogador diretamente para a prisão
        PARADA_LIVRE,     // casa sem efeito
        LUCROS_DIVIDENDOS,// ganhos diversos (não usado nesta iteração)
        IMPOSTO           // cobrança de impostos (não usado nesta iteração)
    }

    private final String nome;
    private final Tipo tipo;

    /**
     * Cria um espaço do tabuleiro com nome e tipo.
     *
     * @param nome nome exibido no tabuleiro
     * @param tipo tipo de espaço
     */
    Espaco(String nome, Tipo tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }

    /**
     * Retorna o nome exibido deste espaço.
     */
    String getNome() {
        return nome;
    }

    /**
     * Retorna o tipo deste espaço no tabuleiro.
     */
    Tipo getTipo() {
        return tipo;
    }
}
