package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Representa o tabuleiro do jogo, com 40 espaços fixos (índices 0..39).
 *
 * Características principais:
 * - Índice da prisão armazenado durante a montagem.
 * - Acesso rápido (O(1)) a propriedades pelo nome.
 * - Companhias são propriedades com precoConstrucao = 0 (não constroem).
 */
class Tabuleiro {

    private final List<Espaco> espacos = new ArrayList<>();
    private final Map<String, Propriedade> propriedadesPorNome = new HashMap<>();
    private int indicePrisao = -1;

    /**
     * Cria o tabuleiro padrão e monta as 40 casas na ordem correta.
     */
    Tabuleiro() {
        montar();
    }

    /**
     * Adiciona a propriedade à lista de espaços e ao mapa de consulta por nome.
     *
     * @param p propriedade a registrar
     */
    private void registrar(Propriedade p) {
        espacos.add(p);
        propriedadesPorNome.put(p.getNome().toLowerCase(), p);
    }

    /**
     * Fábrica interna de propriedades.
     *
     * @param nome            nome exibível
     * @param preco           preço de compra
     * @param aluguelBase     aluguel sem construção
     * @param a1              aluguel com 1 casa
     * @param a2              aluguel com 2 casas
     * @param a3              aluguel com 3 casas
     * @param a4              aluguel com 4 casas
     * @param hotel           aluguel com hotel
     * @param precoConstrucao custo por construção (0 para companhias)
     * @return nova propriedade criada
     */
    private Propriedade prop(String nome, int preco, int aluguelBase,
                             int a1, int a2, int a3, int a4, int hotel, int precoConstrucao) {
        return new Propriedade(nome, preco, aluguelBase, a1, a2, a3, a4, hotel, precoConstrucao);
    }

    /**
     * Monta a sequência de 40 espaços do tabuleiro oficial.
     * Define também o índice da prisão.
     */
    private void montar() {
    	// 0 PARTIDA
        espacos.add(new Espaco("PARTIDA", Espaco.Tipo.PARTIDA) {});

        // 1 Leblon
        registrar(prop("Leblon", 100, 6, 30, 90, 270, 400, 500, 50));
        // 2 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 3 Av. Presidente Vargas
        registrar(prop("Av. Presidente Vargas", 60, 2, 10, 30, 90, 160, 250, 50));
        // 4 Av. Nossa Sra. De Copacabana
        registrar(prop("Av. Nossa S. De Copacabana", 60, 4, 20, 60, 180, 320, 450, 50));
        // 5 Companhia Ferroviária (companhia)
        registrar(prop("Companhia Ferroviária", 200, 50, 50, 100, 200, 300, 400, 0));
        // 6 Av. Brigadeiro Faria Lima
        registrar(prop("Av. Brigadero Faria Lima", 240, 20, 100, 300, 750, 925, 1100, 150));
        // 7 Companhia de Viação (companhia)
        registrar(prop("Companhia de Viação", 200, 50, 50, 100, 200, 300, 400, 0));
        // 8 Av. Rebouças
        registrar(prop("Av. Rebouças", 220, 18, 90, 250, 700, 875, 1050, 150));
        // 9 Av. 9 de Julho
        registrar(prop("Av. 9 de Julho", 320, 18, 90, 250, 700, 875, 1050, 150));

        // 10 PRISÃO (de visita) - índice dinâmico
        indicePrisao = espacos.size();
        espacos.add(new Espaco("PRISÃO", Espaco.Tipo.PRISAO) {});

        // 11 Av. Europa
        registrar(prop("Av. Europa", 200, 16, 80, 220, 600, 800, 1000, 100));
        // 12 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 13 Rua Augusta
        registrar(prop("Rua Augusta", 180, 14, 70, 200, 550, 750, 950, 100));
        // 14 Av. Pacaembú
        registrar(prop("Av. Pacaembú", 180, 14, 70, 200, 550, 750, 950, 100));
        // 15 Companhia de Táxi (companhia)
        registrar(prop("Companhia de Táxi", 150, 40, 40, 100, 200, 300, 400, 0));
        // 16 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 17 Interlagos
        registrar(prop("Interlagos", 350, 35, 175, 500, 1100, 1300, 1500, 200));
        // 18 Lucros ou Dividendos
        espacos.add(new Espaco("Lucros ou Dividendos", Espaco.Tipo.LUCROS_DIVIDENDOS) {});
        // 19 Morumbi
        registrar(prop("Morumbi", 400, 50, 200, 600, 1400, 1700, 2000, 200));

        // 20 PARADA LIVRE
        espacos.add(new Espaco("PARADA LIVRE", Espaco.Tipo.PARADA_LIVRE) {});

        // 21 Flamengo
        registrar(prop("Flamengo", 120, 8, 40, 100, 300, 450, 600, 50));
        // 22 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 23 Botafogo
        registrar(prop("Botafogo", 100, 6, 30, 90, 270, 400, 500, 50));
        // 24 Imposto de Renda
        espacos.add(new Espaco("Imposto de Renda", Espaco.Tipo.IMPOSTO) {});
        // 25 Companhia de Navegação (companhia)
        registrar(prop("Companhia de Navegação", 150, 40, 40, 100, 200, 300, 400, 0));
        // 26 Av. Brasil
        registrar(prop("Av. Brasil", 160, 12, 60, 180, 500, 700, 900, 100));
        // 27 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 28 Av. Paulista
        registrar(prop("Av. Paulista", 140, 10, 50, 150, 450, 625, 750, 100));
        // 29 Jardim Europa
        registrar(prop("Jardim Europa", 140, 10, 50, 150, 450, 625, 750, 100));

        // 30 VÁ PARA A PRISÃO
        espacos.add(new Espaco("VÁ PARA A PRISÃO", Espaco.Tipo.VA_PARA_PRISAO) {});

        // 31 Copacabana
        registrar(prop("Copacabana", 260, 22, 110, 330, 800, 975, 1150, 150));
        // 32 Companhia de Aviação (companhia)
        registrar(prop("Companhia de Aviação", 200, 55, 50, 100, 200, 300, 400, 0));
        // 33 Av. Vieira Souto
        registrar(prop("Av. Vieira Souto", 320, 28, 150, 450, 1000, 1200, 1400, 200));
        // 34 Av. Atlântica
        registrar(prop("Av. Atlântica", 300, 26, 130, 390, 900, 1100, 1275, 200));
        // 35 Companhia de Táxi Aéreo (companhia)
        registrar(prop("Companhia de Táxi Aéreo", 200, 50, 50, 100, 200, 300, 400, 0));
        // 36 Ipanema
        registrar(prop("Ipanema", 300, 26, 130, 390, 900, 1100, 1275, 200));
        // 37 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 38 Jardim Paulista
        registrar(prop("Jardim Paulista", 280, 24, 120, 360, 850, 1025, 1200, 150));
        // 39 Brooklin
        registrar(prop("Brooklin", 260, 22, 110, 330, 800, 975, 1150, 150));
    }

    /**
     * Retorna a quantidade total de espaços do tabuleiro.
     *
     * @return número de casas
     */
    int tamanho() {
        return espacos.size();
    }

    /**
     * Obtém o espaço correspondente ao índice informado.
     *
     * @param idx índice da casa (0 até tamanho()-1)
     * @return espaço do tabuleiro na posição informada
     * @throws IndexOutOfBoundsException se o índice for inválido
     */
    Espaco getEspaco(int idx) {
        return espacos.get(idx);
    }

    /**
     * Retorna o índice da casa de prisão.
     *
     * @return índice da prisão
     */
    int getIndicePrisao() {
        return indicePrisao;
    }

    /**
     * Procura uma propriedade pelo nome, ignorando maiúsculas e minúsculas.
     *
     * @param nome nome da propriedade
     * @return a propriedade encontrada ou null se não houver
     */
    Propriedade encontrarPropriedadePorNome(String nome) {
        if (nome == null) return null;
        return propriedadesPorNome.get(nome.toLowerCase());
    }

    /**
     * Retorna o índice da casa de Partida.
     * Aqui, o tabuleiro assume que a posição 0 é sempre "PARTIDA".
     *
     * @return índice da casa de partida
     */
    public int getIndicePartida() {
        return 0;
    }
}
