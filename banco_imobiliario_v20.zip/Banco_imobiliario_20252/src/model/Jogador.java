package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Representa um jogador do jogo:
 * nome, saldo, posição no tabuleiro, status de prisão
 * e lista de propriedades que ele possui.
 */
class Jogador {

    private final String nome;
    private int saldo;
    private int posicao;
    private boolean preso;
    private int turnosNaPrisao;
    private int cartasSaidaLivre;   // cartas "Sair da Prisão"
    private int duplasSeguidas;     // quantas duplas de dados seguidas tirou

    // Propriedades atualmente pertencentes ao jogador
    private final List<Propriedade> propriedades = new ArrayList<>();

    /**
     * Cria um novo jogador com saldo inicial e posição na casa 0.
     *
     * @param nome         nome do jogador
     * @param saldoInicial saldo inicial definido pelas regras
     */
    Jogador(String nome, int saldoInicial) {
        this.nome = nome;
        this.saldo = saldoInicial;
        this.posicao = 0;
        this.preso = false;
        this.turnosNaPrisao = 0;
        this.cartasSaidaLivre = 0;
    }

    String getNome()          { return nome; }
    int getSaldo()            { return saldo; }
    int getPosicao()          { return posicao; }
    boolean isPreso()         { return preso; }
    int getTurnosNaPrisao()   { return turnosNaPrisao; }

    /**
     * Retorna uma visão somente leitura das propriedades do jogador.
     */
    List<Propriedade> getPropriedades() {
        return Collections.unmodifiableList(propriedades);
    }

    /**
     * Aumenta o saldo do jogador.
     */
    void creditar(int valor) {
        saldo += valor;
    }

    /**
     * Diminui o saldo do jogador.
     */
    void debitar(int valor) {
        saldo -= valor;
    }

    /**
     * Atualiza a posição no tabuleiro.
     */
    void setPosicao(int nova) {
        posicao = nova;
    }

    /**
     * Adiciona uma propriedade ao portfólio (compra).
     */
    void adicionarPropriedade(Propriedade p) {
        propriedades.add(p);
    }

    /**
     * Remove uma propriedade do portfólio (venda/devolução).
     */
    void removerPropriedade(Propriedade p) {
        propriedades.remove(p);
    }

    /**
     * Remove todas as propriedades do jogador e devolve a lista removida.
     * Usado em situações como falência, para devolver tudo ao banco.
     */
    List<Propriedade> limparPropriedades() {
        List<Propriedade> copia = new ArrayList<>(propriedades);
        propriedades.clear();
        return copia;
    }

    // ===== Prisão =====

    /**
     * Envia o jogador para a prisão e zera o contador de turnos preso.
     *
     * @param indicePrisao índice da casa de prisão no tabuleiro
     */
    void enviarParaPrisao(int indicePrisao) {
        preso = true;
        posicao = indicePrisao;
        turnosNaPrisao = 0;
    }

    /**
     * Libera o jogador da prisão e zera o contador de turnos preso.
     */
    void sairDaPrisao() {
        preso = false;
        turnosNaPrisao = 0;
    }

    /**
     * Marca que o jogador passou mais um turno preso.
     */
    void incrementarTurnoPrisao() {
        turnosNaPrisao++;
    }

    /**
     * Tenta usar uma carta "Sair da Prisão".
     *
     * @return true se havia carta disponível e ela foi consumida
     */
    boolean consumirCartaSaidaLivreSeDisponivel() {
        if (cartasSaidaLivre > 0) {
            cartasSaidaLivre--;
            return true;
        }
        return false;
    }

    /**
     * Concede uma carta "Sair da Prisão" ao jogador.
     */
    void ganharCartaSaidaLivre() {
        cartasSaidaLivre++;
    }

    /**
     * Indica se o jogador ainda está ativo no jogo
     * de acordo com a regra de saldo mínimo.
     */
    boolean estaAtivo() {
        return saldo >= Regras.VALOR_MINIMO_ATIVO;
    }

    // ===== Controle de duplas de dados =====

    void registrarDupla()        { duplasSeguidas++; }
    void resetarDuplas()         { duplasSeguidas = 0; }
    int getDuplasSeguidas()      { return duplasSeguidas; }

    @Override
    public String toString() {
        return nome + " - Saldo: $" + saldo + (preso ? " (Preso)" : "");
    }
}
