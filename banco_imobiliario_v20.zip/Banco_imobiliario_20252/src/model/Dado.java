package model;

import java.util.Random;

/**
 * Representa um dado de seis faces usado no jogo.
 * Fornece métodos estáticos para rolar um ou dois dados.
 * Classe utilitária: não deve ser instanciada.
 */
final class Dado {

    /** Gerador de números aleatórios compartilhado por todas as rolagens. */
    private static final Random RNG = new Random();

    private Dado() { } // evita criação de instâncias

    /**
     * Rola um dado de seis faces.
     *
     * @return inteiro entre 1 e 6 (inclusive)
     */
    static int rolar() {
        return RNG.nextInt(6) + 1;
    }

    /**
     * Rola dois dados de seis faces.
     *
     * @return array de tamanho 2 com os resultados, cada posição entre 1 e 6
     */
    static int[] rolarDois() {
        return new int[]{rolar(), rolar()};
    }
}
