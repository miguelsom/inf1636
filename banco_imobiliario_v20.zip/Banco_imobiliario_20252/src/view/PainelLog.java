package view;

import controller.GameListener;
import controller.GameManager;

import javax.swing.*;
import java.awt.*;

/**
 * Painel que exibe o log de atividades do jogo.
 *
 * Mostra em uma área de texto as mensagens geradas pelo GameManager
 * durante a partida (rolagens, compras, eventos etc.).
 */
public class PainelLog extends JPanel implements GameListener {

    /** Fachada do jogo usada para ler o texto do log. */
    private final GameManager game = GameManager.getInstance();
    /** Área de texto somente leitura onde o log é exibido. */
    private final JTextArea txt = new JTextArea();

    /**
     * Cria o painel de log com título simples e área rolável.
     */
    public PainelLog() {
        setLayout(new BorderLayout());

        add(new JLabel("Log"), BorderLayout.NORTH);

        txt.setEditable(false);
        txt.setLineWrap(true);
        txt.setWrapStyleWord(true);

        add(new JScrollPane(txt), BorderLayout.CENTER);

        game.addGameListener(this);
        atualizar();
    }

    /**
     * Atualiza o conteúdo exibido no texto com o log atual do GameManager
     * e rola automaticamente para a última linha.
     */
    private void atualizar() {
        txt.setText(game.getLogText());
        txt.setCaretPosition(txt.getDocument().getLength());
    }

    /**
     * Chamado quando o estado do jogo muda; força a atualização do log na tela.
     */
    @Override
    public void onGameStateChanged() {
        atualizar();
    }
}
