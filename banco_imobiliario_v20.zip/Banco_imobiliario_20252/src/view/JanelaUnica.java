package view;

import controller.GameManager;

import javax.swing.*;
import java.awt.*;

/**
 * Janela principal do jogo.
 *
 * Mostra em uma única janela:
 * - tabuleiro com os pinos dos jogadores
 * - painel de carta e dados
 * - log da rodada
 * - botão para salvar a partida
 *
 * Também observa o estado do jogo e, quando o jogo termina,
 * abre o diálogo de resultado final.
 */
public class JanelaUnica extends JFrame {

    private final GameManager game = GameManager.getInstance();
    private boolean endDialogShown = false;

    /**
     * Abre um JFileChooser para o usuário escolher onde salvar o jogo
     * e delega a gravação ao GameManager. Não exibe mensagens de sucesso/erro.
     */
    private void onSalvarJogo() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Salvar jogo em arquivo (.txt)");
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        java.io.File file = chooser.getSelectedFile();
        if (file == null) return;

        String path = file.getAbsolutePath();
        if (!path.toLowerCase().endsWith(".txt")) {
            path = path + ".txt";
        }

        // Só tenta salvar, sem popup
        game.salvarJogoEmArquivo(path);
    }

    /**
     * Monta a janela principal com:
     * - tabuleiro ao centro
     * - coluna esquerda com salvar, carta e dados
     * - log na parte inferior
     * Registra ainda um listener global para detectar o fim do jogo.
     */
    public JanelaUnica() {
        super("Banco Imobiliário — Iteração 2");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        // Centro: tabuleiro
        PainelTabuleiro painelTabuleiro = new PainelTabuleiro();
        painelTabuleiro.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        add(painelTabuleiro, BorderLayout.CENTER);

        // Coluna à esquerda (salvar, carta, dados)
        JPanel colunaEsquerda = new JPanel(new BorderLayout(6, 6));
        colunaEsquerda.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));

        // Topo da coluna: botão salvar
        JPanel painelTopoEsquerdo = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        JButton botaoSalvar = new JButton("Salvar partida");
        botaoSalvar.addActionListener(e -> onSalvarJogo());
        painelTopoEsquerdo.add(botaoSalvar);
        colunaEsquerda.add(painelTopoEsquerdo, BorderLayout.NORTH);

        // Meio: carta de Sorte/Revés
        PainelCarta painelCarta = new PainelCarta();
        colunaEsquerda.add(painelCarta, BorderLayout.CENTER);

        // Base: dados e ações de turno
        PainelDados painelDados = new PainelDados();
        colunaEsquerda.add(painelDados, BorderLayout.SOUTH);

        colunaEsquerda.setPreferredSize(new Dimension(300, 600));
        add(colunaEsquerda, BorderLayout.WEST);

        // Parte inferior: log da rodada
        PainelLog painelLog = new PainelLog();
        painelLog.setPreferredSize(new Dimension(200, 140));
        add(painelLog, BorderLayout.SOUTH);

        // Listener global de mudanças de estado do jogo.
        // Repaint geral e, se o jogo acabou, mostra o diálogo de encerramento.
        game.addGameListener(new controller.GameListener() {
            @Override
            public void onGameStateChanged() {
                repaint();
                if (!endDialogShown && game.jogoEncerrado()) {
                    endDialogShown = true;
                    EndGameDialog dlg = new EndGameDialog(JanelaUnica.this, game.getRankingPorSaldo());
                    dlg.setVisible(true);
                }
            }
        });

        setSize(1200, 820);
    }
}
