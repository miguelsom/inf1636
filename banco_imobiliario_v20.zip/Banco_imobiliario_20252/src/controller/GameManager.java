package controller;

import model.ModelFacade;

import java.util.*;

/**
 * GameManager (Singleton).
 *
 * Responsável por:
 * - Centralizar toda a lógica de coordenação do jogo para a camada de View.
 * - Expor apenas métodos de alto nível (rolar dados, encerrar turno, comprar, vender, etc.).
 * - Notificar os listeners (interfaces gráficas) quando algo muda.
 *
 * A View nunca acessa o Model diretamente, só passa por aqui.
 */
public final class GameManager implements GameObservable {

    // ===================== Singleton =====================

    /** Instância única do gerenciador do jogo. */
    private static final GameManager INSTANCE = new GameManager();

    /** Acesso global ao Singleton. */
    public static GameManager getInstance() { return INSTANCE; }

    /** Construtor privado para impedir múltiplas instâncias. */
    private GameManager() {}

    /** Fachada do modelo (parte "regra de negócio"). */
    private final ModelFacade model = new ModelFacade();

    // ===================== Listeners (UI) =====================

    /** Lista de observadores de estado (painéis, janelas, etc.). */
    private final List<GameListener> listeners = new ArrayList<>();

    /**
     * Registra um novo listener para ser avisado quando o estado do jogo mudar.
     */
    public void addGameListener(GameListener l) {
        if (l == null) return;
        synchronized (listeners) {
            if (!listeners.contains(l)) listeners.add(l);
        }
    }

    /**
     * Remove um listener previamente registrado.
     */
    public void removeGameListener(GameListener l) {
        if (l == null) return;
        synchronized (listeners) { listeners.remove(l); }
    }

    /**
     * Notifica todos os listeners que o estado do jogo mudou.
     */
    private void notificarListeners() {
        List<GameListener> snap;
        synchronized (listeners) { snap = new ArrayList<>(listeners); }
        for (GameListener l : snap) {
            try { l.onGameStateChanged(); } catch (Exception ignored) {}
        }
    }

    /**
     * Permite que a View force um refresh (repaint) chamando os listeners.
     */
    public void refreshUI() { notificarListeners(); }

    // ===================== Info por índice de ordem =====================

    /**
     * Retorna a posição no tabuleiro do jogador dado o índice de ordem.
     */
    public int getPosicaoDoJogadorPorIndice(int idx) {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        if (idx < 0 || idx >= snaps.size()) return 0;
        return snaps.get(idx).getPosicao();
    }

    /**
     * Retorna o nome do jogador dado o índice de ordem.
     */
    public String getNomeJogadorPorIndice(int idx) {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        if (idx < 0 || idx >= snaps.size()) return "—";
        return snaps.get(idx).getNome();
    }

    /**
     * Retorna o saldo do jogador dado o índice de ordem.
     */
    public int getSaldoDoJogadorPorIndice(int idx) {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        if (idx < 0 || idx >= snaps.size()) return 0;
        return snaps.get(idx).getSaldo();
    }

    // ===================== Estado de UI / Fluxo =====================

    /** Indica se o jogador da vez ainda pode rolar os dados neste turno. */
    private boolean podeRolar = true;
    /** Último lançamento de dados (d1, d2). */
    private int[] ultimoLancamento = {0, 0};
    /** Nome da última casa onde o jogador parou. */
    private String ultimaCasaNome = null;
    /** Indica se a última casa é uma propriedade (terreno/companhia). */
    private boolean ultimaCasaEhPropriedade = false;
    /** Indica se o jogo foi encerrado manualmente (antes do fim normal). */
    private boolean encerradoForcado = false;

    // ===================== Peões (pins) =====================

    /** Mapeia nome do jogador -> id do peão (0..5). */
    private final Map<String, Integer> pinPorNome = new HashMap<>();
    /** Vetor com id do peão por posição de ordem de jogador. */
    private int[] pinIdPorJogador = new int[0];

    // ===================== Sorte/Revés (exibição) =====================

    /** Se true, existe uma carta de Sorte/Revés ativa para exibir. */
    private boolean mostrarSorteReves = false;
    /** Caminho da imagem da carta Sorte/Revés atual. */
    private String caminhoCartaSorteReves = null;

    // ===================== LOG DE ATIVIDADES (para PainelLog) =====================

    /** Lista de mensagens de log da rodada atual. */
    private final List<String> activityLog = new ArrayList<>();

    /**
     * Adiciona uma linha ao log e notifica a UI.
     */
    private void addLog(String msg) {
        if (msg == null || msg.isEmpty()) return;
        activityLog.add(msg);
        notificarListeners();
    }

    /**
     * Retorna todo o log em uma única String (cada linha com \n).
     */
    public String getLogText() {
        if (activityLog.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String s : activityLog) sb.append(s).append("\n");
        return sb.toString();
    }

    /**
     * Apaga o log atual (usado ao trocar de turno).
     */
    private void clearLog() {
        activityLog.clear();
        notificarListeners();
    }

    // ===================== DTOs expostos à View =====================

    /**
     * Projeção simples da propriedade onde o jogador DA VEZ está.
     * Usada pela View para mostrar informações sem acessar o model direto.
     */
    public static final class PropriedadeVM {
        public final String nome;
        public final int preco;
        public final int precoConstrucao;
        public final int casas;
        public final boolean hotel;
        public final String donoNome;   // null = Banco
        public final Integer donoPinId; // null = Banco
        public final boolean companhia;

        public PropriedadeVM(String nome, int preco, int precoConstrucao,
                             int casas, boolean hotel,
                             String donoNome, Integer donoPinId,
                             boolean companhia) {
            this.nome = nome;
            this.preco = preco;
            this.precoConstrucao = precoConstrucao;
            this.casas = casas;
            this.hotel = hotel;
            this.donoNome = donoNome;
            this.donoPinId = donoPinId;
            this.companhia = companhia;
        }
    }

    /**
     * Resumo usado para listar propriedades do jogador da vez (para venda).
     */
    public static final class PropriedadeResumo {
        public final String nome;
        public final int preco;
        public final int precoConstrucao;
        public final int casas;
        public final boolean hotel;
        public final boolean companhia;

        public PropriedadeResumo(String nome, int preco, int precoConstrucao,
                                 int casas, boolean hotel, boolean companhia) {
            this.nome = nome;
            this.preco = preco;
            this.precoConstrucao = precoConstrucao;
            this.casas = casas;
            this.hotel = hotel;
            this.companhia = companhia;
        }
    }

    // ============================================================
    // Setup / Nova Partida
    // ============================================================

    /**
     * Inicia uma nova partida com a quantidade informada de jogadores.
     * Reseta o model, cria jogadores, embaralha ordem e reseta estado de UI.
     */
    public void iniciarNovaPartida(int qtdJogadores) {
        if (qtdJogadores < 2) qtdJogadores = 2;
        if (qtdJogadores > 6) qtdJogadores = 6;

        model.reset();
        for (int i = 1; i <= qtdJogadores; i++) model.adicionarJogador("Jogador " + i);
        if (qtdJogadores > 1) model.embaralharOrdemJogadores();

        podeRolar = true;
        ultimoLancamento[0] = ultimoLancamento[1] = 0;
        ultimaCasaNome = null;
        ultimaCasaEhPropriedade = false;

        mostrarSorteReves = false;
        caminhoCartaSorteReves = null;

        pinPorNome.clear();
        for (int i = 1; i <= qtdJogadores; i++) pinPorNome.put("Jogador " + i, (i - 1) % 6);

        clearLog();
        addLog("Nova partida iniciada com " + qtdJogadores + " jogadores.");
        addLog("Vez de: " + getNomeJogadorDaVez());

        reconstruirPinsNaOrdemAtual();
        notificarListeners();
    }

    /**
     * Define explicitamente quais pinos (ids 0..5) cada jogador vai usar.
     */
    public void definirPinsPorJogador(int[] pinIds) {
        if (pinIds == null) return;
        int n = getNumeroJogadores();
        if (pinIds.length != n) return;

        pinPorNome.clear();
        for (int i = 1; i <= n; i++) pinPorNome.put("Jogador " + i, pinIds[i - 1]);
        reconstruirPinsNaOrdemAtual();
        notificarListeners();
    }

    /**
     * Recria o vetor auxiliar de pinos na ordem atual de jogadores.
     * Usado para desenhar no tabuleiro com base em snapshots.
     */
    private void reconstruirPinsNaOrdemAtual() {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        pinIdPorJogador = new int[snaps.size()];
        for (int i = 0; i < snaps.size(); i++) {
            String nome = snaps.get(i).getNome();
            Integer pin = pinPorNome.get(nome);
            pinIdPorJogador[i] = (pin != null) ? pin : (i % 6);
        }
    }

    // ============================================================
    // Consultas para a View
    // ============================================================

    /** Número total de jogadores na partida. */
    public int getNumeroJogadores() { return model.getJogadoresSnapshot().size(); }

    /** Nome do jogador atualmente na vez. */
    public String getNomeJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getNome() : "—";
    }

    /** Saldo (dinheiro) do jogador da vez. */
    public int getSaldoJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getSaldo() : 0;
    }

    /** Posição do jogador da vez no tabuleiro (0..39). */
    public int getPosicaoJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getPosicao() : 0;
    }

    /** Quantidade de propriedades pertencentes ao jogador da vez. */
    public int getQtdPropriedadesJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getQtdProps() : 0;
    }

    /** Indica se o jogador da vez pode rolar dados agora. */
    public boolean podeRolarDados() { return podeRolar; }

    /** Último lançamento de dados (cópia defensiva). */
    public int[] getUltimoLancamento() { return ultimoLancamento.clone(); }

    /** Nome da última casa onde o jogador parou. */
    public String getUltimaCasaNome() { return ultimaCasaNome; }

    /** Indica se a última casa é propriedade. */
    public boolean isUltimaCasaPropriedade() { return ultimaCasaEhPropriedade; }

    /**
     * Retorna o id do pino do jogador pelo índice de ordem.
     */
    public int getPinIdDoJogador(int idx) {
        if (idx < 0 || idx >= pinIdPorJogador.length) return idx % 6;
        return pinIdPorJogador[idx];
    }

    /**
     * Retorna o id do pino do jogador da vez.
     */
    public int getPinIdDoJogadorDaVez() {
        String nome = getNomeJogadorDaVez();
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        for (int i = 0; i < snaps.size(); i++) {
            if (snaps.get(i).getNome().equals(nome)) return getPinIdDoJogador(i);
        }
        return 0;
    }

    // ===================== Propriedade atual (para PainelCarta/ações) =====================

    /**
     * Retorna um "view model" da propriedade onde o jogador da vez está parado.
     * Se a casa não for propriedade, retorna null.
     */
    public PropriedadeVM getPropriedadeAtualVM() {
        ModelFacade.PropriedadeInfo info = model.getPropriedadeAtualInfo();
        if (info == null) return null;

        Integer donoPin = null;
        if (info.getDonoNome() != null) {
            Integer p = pinPorNome.get(info.getDonoNome());
            if (p != null) donoPin = p;
        }

        return new PropriedadeVM(
                info.getNome(),
                info.getPreco(),
                info.getPrecoConstrucao(),
                info.getCasas(),
                info.isHotel(),
                info.getDonoNome(),
                donoPin,
                info.isCompanhia()
        );
    }

    // ===================== Sorte/Revés (exibição) =====================

    /** Indica se há uma carta de Sorte/Revés ativa para exibir. */
    public boolean temCartaSorteReves() { return mostrarSorteReves && caminhoCartaSorteReves != null; }

    /** Caminho da imagem da carta de Sorte/Revés atual. */
    public String getImagemCartaSorteRevesPath() { return caminhoCartaSorteReves; }

    /**
     * Limpa a carta Sorte/Revés atualmente ativa (tanto na UI quanto no model).
     */
    public void limparCartaSorteReves() {
        mostrarSorteReves = false;
        caminhoCartaSorteReves = null;
        model.limparCartaSorteReves();
        notificarListeners();
    }

    /**
     * Indica se o jogador da vez está preso.
     */
    public boolean jogadorDaVezEstaPreso() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null && s.isPreso());
    }

    // ===================== Ações principais (turno) =====================

    /**
     * Fluxo padrão de rolagem de dados:
     * - Se não pode rolar, não faz nada.
     * - Se preso, tenta primeiro usar carta "sair livre" e depois seguir regras da prisão.
     * - Se não preso, anda no tabuleiro e processa a casa.
     * - Controla regra de "dupla" e se pode rolar novamente.
     */
    public int[] rolarDados() {
        if (!podeRolar) return getUltimoLancamento();

        int[] d = model.lancarDados();
        ultimoLancamento = d.clone();

        // ---- Tratamento de prisão ----
        if (jogadorDaVezEstaPreso()) {
            boolean usouCarta = model.usarCartaSairLivreDaVez();
            if (usouCarta) {
                addLog(getNomeJogadorDaVez() + " usou a carta 'Sair da prisão'.");
                // Cai no fluxo normal abaixo
            } else {
                boolean saiu = model.tentarSairDaPrisaoComDadosDaVez(d[0], d[1]);
                if (saiu) {
                    addLog(getNomeJogadorDaVez() + " saiu da prisão (" + d[0] + "+" + d[1] + ").");
                    ModelFacade.MovementResult mr = model.deslocarJogadorDaVez(d[0] + d[1]);
                    model.processarCasaAtualDaVez();
                    aplicarMovementResult(mr);
                } else {
                    addLog(getNomeJogadorDaVez() + " tentou sair da prisão (" + d[0] + "+" + d[1] + "), mas não conseguiu.");
                    aplicarMovementResult(null);
                }
                podeRolar = false;
                notificarListeners();
                return getUltimoLancamento();
            }
        }

        // ---- Fluxo normal (não preso / acabou de sair com a carta) ----
        ModelFacade.MovementResult mr = model.jogarDadosDaVez(d[0], d[1]);
        addLog(getNomeJogadorDaVez() + " rolou " + d[0] + "+" + d[1] + " e parou em " + mr.getNomeEspaco() + " (" + mr.getTipoNome() + ").");
        model.processarCasaAtualDaVez();
        aplicarMovementResult(mr);

        boolean dupla = (d[0] == d[1]);
        boolean foiParaPrisao = jogadorDaVezEstaPreso()
                || (mr != null && "VA_PARA_PRISAO".equals(mr.getTipoNome()));

        if (foiParaPrisao) addLog(getNomeJogadorDaVez() + " foi para a PRISÃO.");
        if (dupla && !foiParaPrisao) addLog("Dupla! " + getNomeJogadorDaVez() + " pode rolar novamente.");

        // Só pode rolar de novo se tirou dupla e não foi para prisão.
        podeRolar = (!foiParaPrisao) && dupla;
        notificarListeners();
        return getUltimoLancamento();
    }

    /**
     * Versão de teste da rolagem de dados:
     * permite forçar valores específicos (usado pelo atalho 'T').
     */
    public int[] rolarDadosForcado(int d1, int d2) {
        if (!podeRolar) return getUltimoLancamento();
        if (d1 < 1 || d1 > 6 || d2 < 1 || d2 > 6) return getUltimoLancamento();

        ultimoLancamento = new int[]{d1, d2};

        // ---- Tratamento de prisão ----
        if (jogadorDaVezEstaPreso()) {
            boolean usouCarta = model.usarCartaSairLivreDaVez();
            if (usouCarta) {
                addLog(getNomeJogadorDaVez() + " usou a carta 'Sair da prisão'.");
                // Cai no fluxo normal abaixo
            } else {
                boolean saiu = model.tentarSairDaPrisaoComDadosDaVez(d1, d2);
                if (saiu) {
                    addLog(getNomeJogadorDaVez() + " saiu da prisão (" + d1 + "+" + d2 + ").");
                    ModelFacade.MovementResult mr = model.deslocarJogadorDaVez(d1 + d2);
                    model.processarCasaAtualDaVez();
                    aplicarMovementResult(mr);
                } else {
                    addLog(getNomeJogadorDaVez() + " tentou sair da prisão (" + d1 + "+" + d2 + "), mas não conseguiu.");
                    aplicarMovementResult(null);
                }
                podeRolar = false;
                notificarListeners();
                return getUltimoLancamento();
            }
        }

        // ---- Fluxo normal ----
        ModelFacade.MovementResult mr = model.jogarDadosDaVez(d1, d2);
        addLog(getNomeJogadorDaVez() + " rolou " + d1 + "+" + d2 + " e parou em " + mr.getNomeEspaco() + " (" + mr.getTipoNome() + ").");
        model.processarCasaAtualDaVez();
        aplicarMovementResult(mr);

        boolean dupla = (d1 == d2);
        boolean foiParaPrisao = jogadorDaVezEstaPreso()
                || (mr != null && "VA_PARA_PRISAO".equals(mr.getTipoNome()));

        if (foiParaPrisao) addLog(getNomeJogadorDaVez() + " foi para a PRISÃO.");
        if (dupla && !foiParaPrisao) addLog("Dupla! " + getNomeJogadorDaVez() + " pode rolar novamente.");

        podeRolar = (!foiParaPrisao) && dupla;
        notificarListeners();
        return getUltimoLancamento();
    }

    /**
     * Atualiza campos auxiliares (nome da casa, flags de propriedade, carta Sorte/Revés).
     */
    private void aplicarMovementResult(ModelFacade.MovementResult mr) {
        if (mr != null) {
            ultimaCasaNome = mr.getNomeEspaco();
            ultimaCasaEhPropriedade = mr.isPropriedade();

            if (model.temCartaSorteRevesAtiva()) {
                caminhoCartaSorteReves = model.getUltimaCartaImagemPath();
                mostrarSorteReves = (caminhoCartaSorteReves != null);
                if (mostrarSorteReves) addLog("Carta Sorte/Revés revelada.");
            } else {
                mostrarSorteReves = false;
                caminhoCartaSorteReves = null;
            }
        } else {
            mostrarSorteReves = false;
            caminhoCartaSorteReves = null;
        }
    }

    /**
     * Finaliza o turno do jogador atual e passa a vez.
     * Também reseta flags de UI (pode rolar, dados, carta, log, etc.).
     */
    public void encerrarTurno() {
        String atual = getNomeJogadorDaVez();
        model.finalizarTurno();

        podeRolar = true;
        ultimoLancamento[0] = ultimoLancamento[1] = 0;
        ultimaCasaNome = null;
        ultimaCasaEhPropriedade = false;

        mostrarSorteReves = false;
        caminhoCartaSorteReves = null;

        clearLog();
        addLog("Vez de: " + getNomeJogadorDaVez());

        reconstruirPinsNaOrdemAtual();
        notificarListeners();
    }

    // ===================== Encerramento de jogo =====================

    /**
     * Força o encerramento do jogo imediatamente.
     * A View detecta isso e exibe a tela de ranking.
     */
    public void encerrarJogoAgora() {
        this.encerradoForcado = true;
        notificarListeners();
    }

    /**
     * Retorna true se o jogo acabou (por eliminação normal ou encerramento forçado).
     */
    public boolean jogoEncerrado() {
        return encerradoForcado || model.jogoEncerrado();
    }

    // ============================================================
    // Delegates (View chama só estes métodos)
    // ============================================================

    /**
     * Retorna lista imutável com todas as propriedades do jogador da vez.
     * Usada na tela de "Demais Ações" para listar/vender.
     */
    public List<PropriedadeResumo> getPropriedadesDoJogadorDaVezVM() {
        List<ModelFacade.PropriedadeSnapshot> src = model.getPropriedadesDoJogadorDaVez();
        List<PropriedadeResumo> out = new ArrayList<>();
        for (ModelFacade.PropriedadeSnapshot ps : src) {
            out.add(new PropriedadeResumo(
                    ps.getNome(),
                    ps.getPreco(),
                    ps.getPrecoConstrucao(),
                    ps.getCasas(),
                    ps.isHotel(),
                    ps.getPrecoConstrucao() <= 0
            ));
        }
        return Collections.unmodifiableList(out);
    }

    /**
     * Tenta comprar a propriedade onde o jogador da vez está parado.
     */
    public boolean comprarPropriedadeAtual() {
        boolean ok = model.comprarPropriedadeAtualDaVez();
        if (ok) addLog(getNomeJogadorDaVez() + " comprou \"" + (getPropriedadeAtualVM()!=null?getPropriedadeAtualVM().nome:"propriedade") + "\".");
        else addLog("Compra não realizada.");
        notificarListeners();
        return ok;
    }

    /**
     * Tenta construir (casa/hotel) na propriedade atual do jogador da vez.
     */
    public boolean construirNaPropriedadeAtual() {
        boolean ok = model.construirNaPropriedadeAtualDaVez();
        if (ok) addLog(getNomeJogadorDaVez() + " construiu em \"" + (getPropriedadeAtualVM()!=null?getPropriedadeAtualVM().nome:"propriedade") + "\".");
        else addLog("Construção não permitida agora.");
        notificarListeners();
        return ok;
    }

    /**
     * Tenta vender uma propriedade (pelo nome) de volta ao banco.
     */
    public boolean venderPropriedade(String nome) {
        boolean ok = model.venderPropriedadePorNome(nome);
        if (ok) addLog(getNomeJogadorDaVez() + " vendeu \"" + nome + "\" ao banco.");
        else addLog("Venda não realizada.");
        notificarListeners();
        return ok;
    }

    // ===================== Persistência (save/load em arquivo texto) =====================

    /**
     * Salva o estado atual do jogo em arquivo texto.
     *
     * Regra para "JOGADOR_ATUAL" no arquivo:
     * - Se podeRolar == true  -> grava o jogador atual.
     * - Se podeRolar == false -> grava o PRÓXIMO jogador.
     *
     * Assim, quando carregar, sempre estará no início de um turno.
     */
    public boolean salvarJogoEmArquivo(String caminho) {
        if (caminho == null || caminho.trim().isEmpty()) return false;

        try {
            // 1) Exporta o estado normalmente
            java.util.List<String> linhas = model.exportarEstadoComoTexto();

            // 2) Descobre o índice do jogador atual
            java.util.List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
            ModelFacade.PlayerSnapshot daVez = model.getJogadorDaVezSnapshot();

            if (!snaps.isEmpty() && daVez != null) {
                int idxAtual = 0;
                for (int i = 0; i < snaps.size(); i++) {
                    if (snaps.get(i).getNome().equals(daVez.getNome())) {
                        idxAtual = i;
                        break;
                    }
                }

                // 3) Define qual índice será gravado no arquivo
                int idxParaGravar = idxAtual;
                if (!podeRolar) {
                    idxParaGravar = (idxAtual + 1) % snaps.size();
                }

                // 4) Atualiza a linha "JOGADOR_ATUAL;..."
                for (int i = 0; i < linhas.size(); i++) {
                    String linha = linhas.get(i);
                    if (linha != null && linha.startsWith("JOGADOR_ATUAL;")) {
                        linhas.set(i, "JOGADOR_ATUAL;" + idxParaGravar);
                        break;
                    }
                }
            }

            // 5) Escreve o arquivo
            java.nio.file.Path path = java.nio.file.Paths.get(caminho);
            java.nio.file.Files.write(
                    path,
                    linhas,
                    java.nio.charset.StandardCharsets.UTF_8
            );

            addLog("Jogo salvo em " + caminho);
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            addLog("Falha ao salvar o jogo: " + e.getMessage());
            return false;
        }
    }

    /**
     * Carrega o estado do jogo a partir de um arquivo texto gerado por salvarJogoEmArquivo.
     * Após o load, o jogo volta sempre no início de turno do jogador correto.
     */
    public boolean carregarJogoDeArquivo(String caminho) {
        if (caminho == null || caminho.trim().isEmpty()) return false;

        try {
            java.nio.file.Path path = java.nio.file.Paths.get(caminho);
            java.util.List<String> linhas = java.nio.file.Files.readAllLines(
                    path, java.nio.charset.StandardCharsets.UTF_8
            );

            // 1) Pede para o Model reconstituir o estado
            model.importarEstadoDeTexto(linhas);

            // 2) Reseta estado de UI / fluxo para início de turno
            podeRolar = true;
            ultimoLancamento[0] = 0;
            ultimoLancamento[1] = 0;
            ultimaCasaNome = null;
            ultimaCasaEhPropriedade = false;
            mostrarSorteReves = false;
            caminhoCartaSorteReves = null;
            encerradoForcado = false;

            // 3) Reconstrói mapeamento de pinos a partir da ordem dos jogadores
            pinPorNome.clear();
            java.util.List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
            for (int i = 0; i < snaps.size(); i++) {
                String nome = snaps.get(i).getNome();
                pinPorNome.put(nome, i % 6);
            }
            reconstruirPinsNaOrdemAtual();

            // 4) Ajusta log inicial
            clearLog();
            addLog("Jogo carregado de " + caminho);
            addLog("Vez de: " + getNomeJogadorDaVez());

            notificarListeners();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            addLog("Falha ao carregar o jogo: " + e.getMessage());
            notificarListeners();
            return false;
        }
    }

    // ===================== Ranking / Encerramento =====================

    /**
     * Estrutura simples para ranking final por saldo.
     */
    public static final class RankingItem {
        public final String nome;
        public final int saldo;
        public RankingItem(String nome, int saldo) { this.nome = nome; this.saldo = saldo; }
    }

    /**
     * Retorna o ranking de jogadores ordenado por saldo (maior para menor).
     */
    public List<RankingItem> getRankingPorSaldo() {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        List<RankingItem> list = new ArrayList<>();
        for (ModelFacade.PlayerSnapshot s : snaps) list.add(new RankingItem(s.getNome(), s.getSaldo()));
        list.sort((a,b) -> Integer.compare(b.saldo, a.saldo));
        return list;
    }
}
