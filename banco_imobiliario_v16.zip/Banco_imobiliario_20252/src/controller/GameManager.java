package controller;

import model.ModelFacade;

import java.util.*;

/**
 * GameManager (Singleton)
 * UI só conversa com este cara. Nada de Model na View.
 */
public final class GameManager implements GameObservable {

    // ===================== Singleton =====================
    private static final GameManager INSTANCE = new GameManager();
    public static GameManager getInstance() { return INSTANCE; }
    private GameManager() {}

    private final ModelFacade model = new ModelFacade();

    // ===================== Listeners (UI) =====================
    private final List<GameListener> listeners = new ArrayList<>();
    public void addGameListener(GameListener l) {
        if (l == null) return;
        synchronized (listeners) {
            if (!listeners.contains(l)) listeners.add(l);
        }
    }
    public void removeGameListener(GameListener l) {
        if (l == null) return;
        synchronized (listeners) { listeners.remove(l); }
    }
    private void notificarListeners() {
        List<GameListener> snap;
        synchronized (listeners) { snap = new ArrayList<>(listeners); }
        for (GameListener l : snap) {
            try { l.onGameStateChanged(); } catch (Exception ignored) {}
        }
    }
    /** Permite que a View force um refresh/repaint. */
    public void refreshUI() { notificarListeners(); }

    // ===================== Info por índice de ordem =====================
    public int getPosicaoDoJogadorPorIndice(int idx) {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        if (idx < 0 || idx >= snaps.size()) return 0;
        return snaps.get(idx).getPosicao();
    }
    public String getNomeJogadorPorIndice(int idx) {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        if (idx < 0 || idx >= snaps.size()) return "—";
        return snaps.get(idx).getNome();
    }
    public int getSaldoDoJogadorPorIndice(int idx) {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        if (idx < 0 || idx >= snaps.size()) return 0;
        return snaps.get(idx).getSaldo();
    }

    // ===================== Estado de UI / Fluxo =====================
    private boolean podeRolar = true;
    private int[] ultimoLancamento = {0, 0};
    private String ultimaCasaNome = null;
    private boolean ultimaCasaEhPropriedade = false;
    private boolean encerradoForcado = false;

    // ===================== Peões (pins) =====================
    private final Map<String, Integer> pinPorNome = new HashMap<>();
    private int[] pinIdPorJogador = new int[0];

    // ===================== Sorte/Revés (exibição) =====================
    private boolean mostrarSorteReves = false;
    private String caminhoCartaSorteReves = null;

    // ===================== LOG DE ATIVIDADES (para PainelLog) =====================
    private final List<String> activityLog = new ArrayList<>();
    private void addLog(String msg) {
        if (msg == null || msg.isEmpty()) return;
        activityLog.add(msg);
        notificarListeners();
    }
    public String getLogText() {
        if (activityLog.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String s : activityLog) sb.append(s).append("\n");
        return sb.toString();
    }
    /** Apaga o log (usado ao trocar de turno). */
    private void clearLog() {
        activityLog.clear();
        notificarListeners();
    }

    // ===================== DTOs expostos à View =====================
    /** VM da propriedade onde o jogador DA VEZ está parado. */
    public static final class PropriedadeVM {
        public final String nome;
        public final int preco;
        public final int precoConstrucao;
        public final int casas;
        public final boolean hotel;
        public final String donoNome;   // null = Banco
        public final Integer donoPinId; // null = Banco
        public final boolean companhia;

        public PropriedadeVM(String nome, int preco, int precoConstrucao,
                             int casas, boolean hotel,
                             String donoNome, Integer donoPinId,
                             boolean companhia) {
            this.nome = nome;
            this.preco = preco;
            this.precoConstrucao = precoConstrucao;
            this.casas = casas;
            this.hotel = hotel;
            this.donoNome = donoNome;
            this.donoPinId = donoPinId;
            this.companhia = companhia;
        }
    }

    /** Resumo de propriedade do JOGADOR DA VEZ (para listar e vender). */
    public static final class PropriedadeResumo {
        public final String nome;
        public final int preco;
        public final int precoConstrucao;
        public final int casas;
        public final boolean hotel;
        public final boolean companhia;

        public PropriedadeResumo(String nome, int preco, int precoConstrucao,
                                 int casas, boolean hotel, boolean companhia) {
            this.nome = nome;
            this.preco = preco;
            this.precoConstrucao = precoConstrucao;
            this.casas = casas;
            this.hotel = hotel;
            this.companhia = companhia;
        }
    }

    // ============================================================
    // Setup / Nova Partida
    // ============================================================
    public void iniciarNovaPartida(int qtdJogadores) {
        if (qtdJogadores < 2) qtdJogadores = 2;
        if (qtdJogadores > 6) qtdJogadores = 6;

        model.reset();
        for (int i = 1; i <= qtdJogadores; i++) model.adicionarJogador("Jogador " + i);
        if (qtdJogadores > 1) model.embaralharOrdemJogadores();

        podeRolar = true;
        ultimoLancamento[0] = ultimoLancamento[1] = 0;
        ultimaCasaNome = null;
        ultimaCasaEhPropriedade = false;

        mostrarSorteReves = false;
        caminhoCartaSorteReves = null;

        pinPorNome.clear();
        for (int i = 1; i <= qtdJogadores; i++) pinPorNome.put("Jogador " + i, (i - 1) % 6);

        clearLog();
        addLog("Nova partida iniciada com " + qtdJogadores + " jogadores.");
        addLog("Vez de: " + getNomeJogadorDaVez());

        reconstruirPinsNaOrdemAtual();
        notificarListeners();
    }

    public void definirPinsPorJogador(int[] pinIds) {
        if (pinIds == null) return;
        int n = getNumeroJogadores();
        if (pinIds.length != n) return;

        pinPorNome.clear();
        for (int i = 1; i <= n; i++) pinPorNome.put("Jogador " + i, pinIds[i - 1]);
        reconstruirPinsNaOrdemAtual();
        notificarListeners();
    }

    private void reconstruirPinsNaOrdemAtual() {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        pinIdPorJogador = new int[snaps.size()];
        for (int i = 0; i < snaps.size(); i++) {
            String nome = snaps.get(i).getNome();
            Integer pin = pinPorNome.get(nome);
            pinIdPorJogador[i] = (pin != null) ? pin : (i % 6);
        }
    }

    // ============================================================
    // Consultas para a View
    // ============================================================
    public int getNumeroJogadores() { return model.getJogadoresSnapshot().size(); }
    public String getNomeJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getNome() : "—";
    }
    public int getSaldoJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getSaldo() : 0;
    }
    public int getPosicaoJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getPosicao() : 0;
    }
    public int getQtdPropriedadesJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getQtdProps() : 0;
    }

    public boolean podeRolarDados() { return podeRolar; }
    public int[] getUltimoLancamento() { return ultimoLancamento.clone(); }
    public String getUltimaCasaNome() { return ultimaCasaNome; }
    public boolean isUltimaCasaPropriedade() { return ultimaCasaEhPropriedade; }

    public int getPinIdDoJogador(int idx) {
        if (idx < 0 || idx >= pinIdPorJogador.length) return idx % 6;
        return pinIdPorJogador[idx];
    }
    public int getPinIdDoJogadorDaVez() {
        String nome = getNomeJogadorDaVez();
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        for (int i = 0; i < snaps.size(); i++) {
            if (snaps.get(i).getNome().equals(nome)) return getPinIdDoJogador(i);
        }
        return 0;
    }

    // ===================== Propriedade atual (para PainelCarta/ações) =====================
    public PropriedadeVM getPropriedadeAtualVM() {
        ModelFacade.PropriedadeInfo info = model.getPropriedadeAtualInfo();
        if (info == null) return null;

        Integer donoPin = null;
        if (info.getDonoNome() != null) {
            Integer p = pinPorNome.get(info.getDonoNome());
            if (p != null) donoPin = p;
        }

        return new PropriedadeVM(
                info.getNome(),
                info.getPreco(),
                info.getPrecoConstrucao(),
                info.getCasas(),
                info.isHotel(),
                info.getDonoNome(),
                donoPin,
                info.isCompanhia()
        );
    }

    // ===================== Sorte/Revés (exibição) =====================
    public boolean temCartaSorteReves() { return mostrarSorteReves && caminhoCartaSorteReves != null; }
    public String getImagemCartaSorteRevesPath() { return caminhoCartaSorteReves; }
    public void limparCartaSorteReves() {
        mostrarSorteReves = false;
        caminhoCartaSorteReves = null;
        model.limparCartaSorteReves();
        notificarListeners();
    }

    public boolean jogadorDaVezEstaPreso() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null && s.isPreso());
    }

    // ===================== Ações principais (turno) =====================
    public int[] rolarDados() {
        if (!podeRolar) return getUltimoLancamento();

        int[] d = model.lancarDados();
        ultimoLancamento = d.clone();

        // ---- Se estiver preso, tenta usar carta "Sair da prisão" primeiro ----
        if (jogadorDaVezEstaPreso()) {
            boolean usouCarta = model.usarCartaSairLivreDaVez();
            if (usouCarta) {
                addLog(getNomeJogadorDaVez() + " usou a carta 'Sair da prisão'.");
                // Cai direto no fluxo normal abaixo (não está mais preso)
            } else {
                boolean saiu = model.tentarSairDaPrisaoComDadosDaVez(d[0], d[1]);
                if (saiu) {
                    addLog(getNomeJogadorDaVez() + " saiu da prisão (" + d[0] + "+" + d[1] + ").");
                    ModelFacade.MovementResult mr = model.deslocarJogadorDaVez(d[0] + d[1]);
                    model.processarCasaAtualDaVez();
                    aplicarMovementResult(mr);
                } else {
                    addLog(getNomeJogadorDaVez() + " tentou sair da prisão (" + d[0] + "+" + d[1] + "), mas não conseguiu.");
                    aplicarMovementResult(null);
                }
                podeRolar = false;
                notificarListeners();
                return getUltimoLancamento();
            }
        }

        // ---- Fluxo normal (não está preso, ou acabou de sair com a carta) ----
        ModelFacade.MovementResult mr = model.jogarDadosDaVez(d[0], d[1]);
        addLog(getNomeJogadorDaVez() + " rolou " + d[0] + "+" + d[1] + " e parou em " + mr.getNomeEspaco() + " (" + mr.getTipoNome() + ").");
        model.processarCasaAtualDaVez();
        aplicarMovementResult(mr);

        boolean dupla = (d[0] == d[1]);
        boolean foiParaPrisao = jogadorDaVezEstaPreso()
                || (mr != null && "VA_PARA_PRISAO".equals(mr.getTipoNome()));

        if (foiParaPrisao) addLog(getNomeJogadorDaVez() + " foi para a PRISÃO.");
        if (dupla && !foiParaPrisao) addLog("Dupla! " + getNomeJogadorDaVez() + " pode rolar novamente.");

        podeRolar = (!foiParaPrisao) && dupla; // só joga de novo se dupla e não foi preso
        notificarListeners();
        return getUltimoLancamento();
    }

    public int[] rolarDadosForcado(int d1, int d2) {
        if (!podeRolar) return getUltimoLancamento();
        if (d1 < 1 || d1 > 6 || d2 < 1 || d2 > 6) return getUltimoLancamento();

        ultimoLancamento = new int[]{d1, d2};

        // ---- Se estiver preso, tenta usar carta "Sair da prisão" primeiro ----
        if (jogadorDaVezEstaPreso()) {
            boolean usouCarta = model.usarCartaSairLivreDaVez();
            if (usouCarta) {
                addLog(getNomeJogadorDaVez() + " usou a carta 'Sair da prisão'.");
                // Cai no fluxo normal abaixo
            } else {
                boolean saiu = model.tentarSairDaPrisaoComDadosDaVez(d1, d2);
                if (saiu) {
                    addLog(getNomeJogadorDaVez() + " saiu da prisão (" + d1 + "+" + d2 + ").");
                    ModelFacade.MovementResult mr = model.deslocarJogadorDaVez(d1 + d2);
                    model.processarCasaAtualDaVez();
                    aplicarMovementResult(mr);
                } else {
                    addLog(getNomeJogadorDaVez() + " tentou sair da prisão (" + d1 + "+" + d2 + "), mas não conseguiu.");
                    aplicarMovementResult(null);
                }
                podeRolar = false;
                notificarListeners();
                return getUltimoLancamento();
            }
        }

        // ---- Fluxo normal (não está preso, ou acabou de sair com a carta) ----
        ModelFacade.MovementResult mr = model.jogarDadosDaVez(d1, d2);
        addLog(getNomeJogadorDaVez() + " rolou " + d1 + "+" + d2 + " e parou em " + mr.getNomeEspaco() + " (" + mr.getTipoNome() + ").");
        model.processarCasaAtualDaVez();
        aplicarMovementResult(mr);

        boolean dupla = (d1 == d2);
        boolean foiParaPrisao = jogadorDaVezEstaPreso()
                || (mr != null && "VA_PARA_PRISAO".equals(mr.getTipoNome()));

        if (foiParaPrisao) addLog(getNomeJogadorDaVez() + " foi para a PRISÃO.");
        if (dupla && !foiParaPrisao) addLog("Dupla! " + getNomeJogadorDaVez() + " pode rolar novamente.");

        podeRolar = (!foiParaPrisao) && dupla;
        notificarListeners();
        return getUltimoLancamento();
    }

    private void aplicarMovementResult(ModelFacade.MovementResult mr) {
        if (mr != null) {
            ultimaCasaNome = mr.getNomeEspaco();
            ultimaCasaEhPropriedade = mr.isPropriedade();

            if (model.temCartaSorteRevesAtiva()) {
                caminhoCartaSorteReves = model.getUltimaCartaImagemPath();
                mostrarSorteReves = (caminhoCartaSorteReves != null);
                if (mostrarSorteReves) addLog("Carta Sorte/Revés revelada.");
            } else {
                mostrarSorteReves = false;
                caminhoCartaSorteReves = null;
            }
        } else {
            mostrarSorteReves = false;
            caminhoCartaSorteReves = null;
        }
    }

    public void encerrarTurno() {
        String atual = getNomeJogadorDaVez();
        model.finalizarTurno();

        podeRolar = true;
        ultimoLancamento[0] = ultimoLancamento[1] = 0;
        ultimaCasaNome = null;
        ultimaCasaEhPropriedade = false;

        mostrarSorteReves = false;
        caminhoCartaSorteReves = null;

        clearLog(); // APAGA o log ao trocar de turno (seu pedido)
        addLog("Vez de: " + getNomeJogadorDaVez());

        reconstruirPinsNaOrdemAtual();
        notificarListeners();
    }

    // ===================== Encerramento de jogo =====================
    /** Força o encerramento do jogo agora (abre tela final via listener da janela). */
    public void encerrarJogoAgora() {
        this.encerradoForcado = true;
        notificarListeners();
    }

    /** True se o jogo acabou por falência/eliminação OU por forçamento. */
    public boolean jogoEncerrado() {
        return encerradoForcado || model.jogoEncerrado();
    }

    // ============================================================
    // Delegates (View chama só estes métodos)
    // ============================================================
    public List<PropriedadeResumo> getPropriedadesDoJogadorDaVezVM() {
        List<ModelFacade.PropriedadeSnapshot> src = model.getPropriedadesDoJogadorDaVez();
        List<PropriedadeResumo> out = new ArrayList<>();
        for (ModelFacade.PropriedadeSnapshot ps : src) {
            out.add(new PropriedadeResumo(
                    ps.getNome(),
                    ps.getPreco(),
                    ps.getPrecoConstrucao(),
                    ps.getCasas(),
                    ps.isHotel(),
                    ps.getPrecoConstrucao() <= 0
            ));
        }
        return Collections.unmodifiableList(out);
    }

    public boolean comprarPropriedadeAtual() {
        boolean ok = model.comprarPropriedadeAtualDaVez();
        if (ok) addLog(getNomeJogadorDaVez() + " comprou \"" + (getPropriedadeAtualVM()!=null?getPropriedadeAtualVM().nome:"propriedade") + "\".");
        else addLog("Compra não realizada.");
        notificarListeners();
        return ok;
    }

    public boolean construirNaPropriedadeAtual() {
        boolean ok = model.construirNaPropriedadeAtualDaVez();
        if (ok) addLog(getNomeJogadorDaVez() + " construiu em \"" + (getPropriedadeAtualVM()!=null?getPropriedadeAtualVM().nome:"propriedade") + "\".");
        else addLog("Construção não permitida agora.");
        notificarListeners();
        return ok;
    }

    public boolean venderPropriedade(String nome) {
        boolean ok = model.venderPropriedadePorNome(nome);
        if (ok) addLog(getNomeJogadorDaVez() + " vendeu \"" + nome + "\" ao banco.");
        else addLog("Venda não realizada.");
        notificarListeners();
        return ok;
    }

    // ===================== Persistência (save/load em arquivo texto) =====================

    /**
     * Salva o estado atual do jogo em um arquivo texto (.txt).
     *
     * Regra para definir quem será o "jogador da vez" no save:
     * - Se ainda pode rolar dados (podeRolar == true), grava o jogador atual.
     * - Se já NÃO pode rolar (podeRolar == false), grava o PRÓXIMO jogador.
     *
     * Assim, todo save representa sempre o início de turno de alguém.
     */
    public boolean salvarJogoEmArquivo(String caminho) {
        if (caminho == null || caminho.trim().isEmpty()) return false;

        try {
            // 1) Exporta o estado normalmente
            java.util.List<String> linhas = model.exportarEstadoComoTexto();

            // 2) Descobre o índice do jogador atual dentro da lista de snapshots
            java.util.List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
            ModelFacade.PlayerSnapshot daVez = model.getJogadorDaVezSnapshot();

            if (!snaps.isEmpty() && daVez != null) {
                int idxAtual = 0;
                for (int i = 0; i < snaps.size(); i++) {
                    if (snaps.get(i).getNome().equals(daVez.getNome())) {
                        idxAtual = i;
                        break;
                    }
                }

                // 3) Decide quem será o "jogador da vez" gravado no arquivo
                int idxParaGravar = idxAtual;
                if (!podeRolar) {
                    // já jogou os dados -> próximo jogador é o da vez no save
                    idxParaGravar = (idxAtual + 1) % snaps.size();
                }

                // 4) Sobrescreve a linha "JOGADOR_ATUAL;..."
                for (int i = 0; i < linhas.size(); i++) {
                    String linha = linhas.get(i);
                    if (linha != null && linha.startsWith("JOGADOR_ATUAL;")) {
                        linhas.set(i, "JOGADOR_ATUAL;" + idxParaGravar);
                        break;
                    }
                }
            }

            // 5) Escreve no arquivo
            java.nio.file.Path path = java.nio.file.Paths.get(caminho);
            java.nio.file.Files.write(
                    path,
                    linhas,
                    java.nio.charset.StandardCharsets.UTF_8
            );

            addLog("Jogo salvo em " + caminho);
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            addLog("Falha ao salvar o jogo: " + e.getMessage());
            return false;
        }
    }

    /**
     * Carrega o estado do jogo a partir de um arquivo texto (.txt).
     * Assume que o arquivo foi gerado por salvarJogoEmArquivo.
     */
    public boolean carregarJogoDeArquivo(String caminho) {
        if (caminho == null || caminho.trim().isEmpty()) return false;

        try {
            java.nio.file.Path path = java.nio.file.Paths.get(caminho);
            java.util.List<String> linhas = java.nio.file.Files.readAllLines(
                    path, java.nio.charset.StandardCharsets.UTF_8
            );

            // 1) Delega ao Model a reconstituição do estado
            model.importarEstadoDeTexto(linhas);

            // 2) Reseta estado de UI / fluxo para "início de turno" do jogador da vez do arquivo
            podeRolar = true;                            // sempre começo de turno
            ultimoLancamento[0] = 0;
            ultimoLancamento[1] = 0;
            ultimaCasaNome = null;
            ultimaCasaEhPropriedade = false;
            mostrarSorteReves = false;
            caminhoCartaSorteReves = null;
            encerradoForcado = false;

            // 3) Reconstrói mapeamento de peões (pins) a partir da ordem de jogadores
            pinPorNome.clear();
            java.util.List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
            for (int i = 0; i < snaps.size(); i++) {
                String nome = snaps.get(i).getNome();
                // se você tiver uma lógica própria de distribuição de pins, aplica aqui;
                // por enquanto mantemos um mapeamento simples índice % 6
                pinPorNome.put(nome, i % 6);
            }
            reconstruirPinsNaOrdemAtual();

            // 4) Log bonitinho
            clearLog();
            addLog("Jogo carregado de " + caminho);
            addLog("Vez de: " + getNomeJogadorDaVez());

            notificarListeners();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            addLog("Falha ao carregar o jogo: " + e.getMessage());
            notificarListeners();
            return false;
        }
    }

    // ===================== Ranking / Encerramento =====================
    public static final class RankingItem {
        public final String nome;
        public final int saldo;
        public RankingItem(String nome, int saldo) { this.nome = nome; this.saldo = saldo; }
    }

    /** Retorna ranking por saldo (desc). */
    public List<RankingItem> getRankingPorSaldo() {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        List<RankingItem> list = new ArrayList<>();
        for (ModelFacade.PlayerSnapshot s : snaps) list.add(new RankingItem(s.getNome(), s.getSaldo()));
        list.sort((a,b) -> Integer.compare(b.saldo, a.saldo));
        return list;
    }
}
