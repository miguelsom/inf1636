package view;

import javax.swing.*;

import controller.GameListener;
import controller.GameManager;

import java.awt.*;

/**
 * Painel da Carta (simples e direto).
 *
 * Regras de exibição:
 * - Se houver carta de Sorte/Revés ativa, ela tem prioridade.
 * - Caso contrário, se a última casa for propriedade (terreno/companhia),
 *   mostra a carta/imagem da propriedade + rodapé com informações.
 * - Senão, mostra "Sem carta".
 *
 * Diferença em relação ao original:
 * - Em vez de JLabel com ImageIcon, usamos um componente interno (CartaView)
 *   que desenha a imagem via Java2D (Graphics2D.drawImage), como o professor pede.
 */
public class PainelCarta extends JPanel implements GameListener {

    private static final long serialVersionUID = 1L;

    /** Fachada de estado/controlador acessada pela View. */
    private final GameManager game;

    /** Título da área: "Sorte/Revés" ou o nome da propriedade. */
    private final JLabel lblTitulo;
    /** Área central da carta (desenhada via Java2D). */
    private final CartaView cartaView;

    /** Rodapé com texto descritivo para propriedades. */
    private final JPanel rodape;
    private final JLabel lblLinhaTipoDono;  // "Tipo: Terreno|Companhia | Dono: ..."
    private final JLabel lblLinhaCustos;    // "Preço: ... | Construção: ... | Casas: ... (Hotel)"

    public PainelCarta() {
        super(new BorderLayout(6, 6));
        this.game = GameManager.getInstance();
        this.game.addGameListener(this);

        setOpaque(true);
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        setPreferredSize(new Dimension(300, 360));

        // Cabeçalho
        lblTitulo = new JLabel("Carta", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 14));
        add(lblTitulo, BorderLayout.NORTH);

        // Área central: agora é um componente customizado que desenha imagem/texto
        cartaView = new CartaView();
        add(cartaView, BorderLayout.CENTER);

        // Rodapé textual (propriedades)
        rodape = new JPanel(new GridLayout(2, 1, 0, 2));
        rodape.setOpaque(false);

        lblLinhaTipoDono = new JLabel(" ");
        lblLinhaCustos   = new JLabel(" ");
        lblLinhaTipoDono.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblLinhaCustos.setFont(new Font("SansSerif", Font.PLAIN, 12));

        rodape.add(lblLinhaTipoDono);
        rodape.add(lblLinhaCustos);
        add(rodape, BorderLayout.SOUTH);

        atualizarConteudo();
    }

    // =====================================================================
    // Atualização de conteúdo (mesma lógica do teu código original)
    // =====================================================================

    private void atualizarConteudo() {
        // 1) Sorte/Revés tem prioridade
        if (game.temCartaSorteReves()) {
            lblTitulo.setText("Sorte / Revés");
            aplicarImagemSorteReves(game.getImagemCartaSorteRevesPath());
            rodape.setVisible(false);
            return;
        }

        // 2) Propriedade (terreno/companhia) usando a VM da GameManager
        if (game.isUltimaCasaPropriedade()) {
            final String nome = game.getUltimaCasaNome();
            lblTitulo.setText((nome != null && !nome.isEmpty()) ? nome : "Propriedade");

            GameManager.PropriedadeVM vm = game.getPropriedadeAtualVM();
            final boolean ehCompanhia = (vm != null && vm.companhia);

            final String caminhoImg = ehCompanhia
                    ? "imagem/companhias/" + nome + ".png"
                    : "imagem/territorios/" + nome + ".png";

            aplicarImagemPropriedade(caminhoImg);

            if (vm != null) {
                final String tipo = ehCompanhia ? "Companhia" : "Terreno";
                final String dono = (vm.donoNome == null ? "Banco" : vm.donoNome);
                lblLinhaTipoDono.setText("Tipo: " + tipo + "  |  Dono: " + dono);

                final String custoCompra = "Preço: R$ " + vm.preco;
                final String custoConstr = (vm.precoConstrucao > 0 ? " | Construção: R$ " + vm.precoConstrucao : "");
                final String construcoes = ehCompanhia ? "" : (" | Casas: " + vm.casas + (vm.hotel ? " (Hotel)" : ""));
                lblLinhaCustos.setText(custoCompra + custoConstr + construcoes);

                rodape.setVisible(true);
            } else {
                rodape.setVisible(false);
            }
            return;
        }

        // 3) Nada para mostrar
        lblTitulo.setText("Carta");
        cartaView.setConteudo(null, "Sem carta");
        rodape.setVisible(false);
    }

    // =====================================================================
    // Utilitários de imagem (agora jogam a imagem para o CartaView)
    // =====================================================================

    private void aplicarImagemSorteReves(String caminho) {
        if (caminho == null) {
            cartaView.setConteudo(null, "Imagem não encontrada");
            return;
        }
        ImageIcon ic = new ImageIcon(caminho);
        if (ic.getIconWidth() <= 0 || ic.getIconHeight() <= 0) {
            cartaView.setConteudo(null, "Imagem não encontrada");
            return;
        }
        cartaView.setConteudo(ic.getImage(), null);
    }

    private void aplicarImagemPropriedade(String caminho) {
        if (caminho == null) {
            cartaView.setConteudo(null, "Imagem não encontrada");
            return;
        }
        ImageIcon ic = new ImageIcon(caminho);
        if (ic.getIconWidth() <= 0 || ic.getIconHeight() <= 0) {
            cartaView.setConteudo(null, "Imagem não encontrada");
            return;
        }
        cartaView.setConteudo(ic.getImage(), null);
    }

    // =====================================================================
    // Listener do jogo
    // =====================================================================

    @Override
    public void onGameStateChanged() {
        atualizarConteudo();
    }

    // =====================================================================
    // Componente interno para desenhar a carta em Java2D
    // =====================================================================

    /**
     * Área central onde a carta é desenhada.
     * - Se tiver imagem, desenha a imagem escalada.
     * - Senão, mostra um texto simples (ex: "Sem carta" ou "Imagem não encontrada").
     */
    private static class CartaView extends JComponent {

        private static final long serialVersionUID = 1L;

        private Image imagem;
        private String texto;

        public CartaView() {
            setOpaque(false);
        }

        public void setConteudo(Image img, String textoFallback) {
            this.imagem = img;
            this.texto = textoFallback;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();
            try {
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                // Fundo leve só pra destacar a carta
                g2.setColor(new Color(245, 245, 245));
                g2.fillRoundRect(0, 0, w - 1, h - 1, 12, 12);
                g2.setColor(Color.LIGHT_GRAY);
                g2.drawRoundRect(0, 0, w - 1, h - 1, 12, 12);

                if (imagem != null) {
                    int imgW = imagem.getWidth(null);
                    int imgH = imagem.getHeight(null);
                    if (imgW > 0 && imgH > 0) {
                        int margem = 8;
                        int availW = w - 2 * margem;
                        int availH = h - 2 * margem;

                        double escala = Math.min(
                                (double) availW / imgW,
                                (double) availH / imgH
                        );
                        int drawW = (int) (imgW * escala);
                        int drawH = (int) (imgH * escala);

                        int x = (w - drawW) / 2;
                        int y = (h - drawH) / 2;
                        g2.drawImage(imagem, x, y, drawW, drawH, null);
                        return;
                    }
                }

                // Se não tiver imagem, desenha texto simples no centro
                String msg = (texto != null ? texto : "Sem carta");
                g2.setColor(Color.DARK_GRAY);
                g2.setFont(getFont().deriveFont(Font.PLAIN, 12f));
                FontMetrics fm = g2.getFontMetrics();
                int textW = fm.stringWidth(msg);
                int textH = fm.getAscent();
                int tx = (w - textW) / 2;
                int ty = (h + textH) / 2 - 4;
                g2.drawString(msg, tx, ty);

            } finally {
                g2.dispose();
            }
        }
    }
}
