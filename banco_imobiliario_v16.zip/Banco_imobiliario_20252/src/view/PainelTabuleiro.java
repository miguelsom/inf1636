package view;

import controller.GameManager;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PainelTabuleiro extends JPanel implements controller.GameListener {

    private static final long serialVersionUID = 1L;

    // Tamanho "base" da arte (referência de proporção)
    private static final int ORIG_W = 700, ORIG_H = 700;

    // Parâmetros de deslocamento e passo (em px da arte base)
    private static final int OFF_RIGHT_PX  = 80;
    private static int OFF_BOTTOM_PX = 80;
    private static final int OFF_LEFT_PX   = 80;
    private static final int OFF_TOP_PX    = 80;
    private static final int STEP_X_PX     = 56;
    private static final int STEP_Y_PX     = 56;

    // Tamanho dos pinos
    private static final int PIN_W = 28, PIN_H = 28, PIN_OFFSET_Y = 28;

    private final GameManager gm = GameManager.getInstance();

    private final ImageIcon iconTabuleiro = new ImageIcon("imagem/tabuleiro.png");
    private final Image imgTabuleiro = iconTabuleiro.getImage();

    // pinos pin0..pin5
    private final List<Image> imagensPinoPorId = new ArrayList<>(6);

    // posições dos jogadores (snapshot)
    private int[] ultimasPosicoes;

    // animação
    private Timer animTimer;
    private int idxJogAnim = -1;
    private int casaAnim = 0;
    private int destinoAnim = 0;

    // centros das 40 casas
    private final Point[] centrosCasas = new Point[40];

    public PainelTabuleiro() {
        gm.addGameListener(this);
        setDoubleBuffered(true);
        setOpaque(true);
        setBackground(new Color(235, 235, 235));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // 1) Desenha o tabuleiro mantendo proporção
        Rectangle area = desenharTabuleiroMantendoProporcao(
                g2, imgTabuleiro, iconTabuleiro, getWidth(), getHeight()
        );

        // 2) Recalcula os centros das casas com base nessa área
        recalcularCentrosCasas(area);

        // 3) Garante pinos e posições
        int n = gm.getNumeroJogadores();
        carregarPinosSeNecessario();
        sincronizarUltimasPosicoes(n);

        // 4) Desenha cada jogador
        boolean animando = (animTimer != null && animTimer.isRunning());
        for (int i = 0; i < n; i++) {
            int pos = animando && i == idxJogAnim ? casaAnim : ultimasPosicoes[i];
            int idx = ((pos % 40) + 40) % 40;
            Point centro = centrosCasas[idx];
            if (centro == null) continue;

            int pinId = gm.getPinIdDoJogador(i) % 6;
            Image imgPin = imagemDoPino(pinId);
            if (imgPin == null) continue;

            Point off = deslocamentoSutilPorJogador(i);
            int x = centro.x + off.x - PIN_W / 2;
            int y = centro.y + off.y - PIN_OFFSET_Y;
            g2.drawImage(imgPin, x, y, PIN_W, PIN_H, this);
        }
    }

    // ====================== Listener ======================

    @Override
    public void onGameStateChanged() {
        int n = gm.getNumeroJogadores();
        carregarPinosSeNecessario();
        sincronizarUltimasPosicoes(n);

        int idx = -1, de = -1, para = -1;
        for (int i = 0; i < n; i++) {
            int posAtual = gm.getPosicaoDoJogadorPorIndice(i);
            if (posAtual != ultimasPosicoes[i]) {
                idx = i;
                de = ultimasPosicoes[i];
                para = posAtual;
                break;
            }
        }

        if (idx == -1) { // ninguém moveu
            repaint();
            return;
        }

        iniciarAnimacao(idx, de, para);
    }

    // ====================== Animação ======================

    private void iniciarAnimacao(int idxJogador, int origem, int destino) {
        if (animTimer != null && animTimer.isRunning()) animTimer.stop();

        idxJogAnim = idxJogador;
        casaAnim = origem;
        destinoAnim = destino;

        // se por algum motivo não andou, só atualiza e redesenha
        if (origem == destino) {
            ultimasPosicoes[idxJogador] = destino;
            repaint();
            return;
        }

        animTimer = new Timer(90, e -> {
            if (casaAnim == destinoAnim) {
                ultimasPosicoes[idxJogAnim] = destinoAnim;
                animTimer.stop();
                repaint();
                return;
            }
            casaAnim = (casaAnim + 1) % 40;
            repaint();
        });
        animTimer.start();
    }

    // ====================== Geometria das casas ======================

    private void recalcularCentrosCasas(Rectangle area) {
        if (area.width <= 0 || area.height <= 0) return;

        double s = Math.min(area.width / (double) ORIG_W,
                            area.height / (double) ORIG_H);

        int drawW = (int) Math.round(ORIG_W * s);
        int drawH = (int) Math.round(ORIG_H * s);
        int drawX = area.x + (area.width  - drawW) / 2;
        int drawY = area.y + (area.height - drawH) / 2;

        double offR = OFF_RIGHT_PX  * s;
        double offB = OFF_BOTTOM_PX * s;
        double offL = OFF_LEFT_PX   * s;
        double offT = OFF_TOP_PX    * s;
        double stepX = STEP_X_PX    * s;
        double stepY = STEP_Y_PX    * s;

        double right  = drawX + drawW;
        double bottom = drawY + drawH;
        double left   = drawX;
        double top    = drawY;

        double cxBR = right  - offR, cyBR = bottom - offB; // 0
        double cxBL = left   + offL, cyBL = bottom - offB; // 10
        double cxTL = left   + offL, cyTL = top    + offT; // 20
        double cxTR = right  - offR, cyTR = top    + offT; // 30

        centrosCasas[0] = ponto(cxBR, cyBR);
        for (int i = 1; i <= 9; i++) {
            centrosCasas[i] = ponto(right - offR - (i * stepX), cyBR);
        }

        centrosCasas[10] = ponto(cxBL, cyBL);
        for (int i = 1; i <= 9; i++) {
            centrosCasas[10 + i] = ponto(cxBL, bottom - offB - (i * stepY));
        }

        centrosCasas[20] = ponto(cxTL, cyTL);
        for (int i = 1; i <= 9; i++) {
            centrosCasas[20 + i] = ponto(left + offL + (i * stepX), cyTL);
        }

        centrosCasas[30] = ponto(cxTR, cyTR);
        for (int i = 1; i <= 9; i++) {
            centrosCasas[30 + i] = ponto(cxTR, top + offT + (i * stepY));
        }
    }

    private static Point ponto(double x, double y) {
        return new Point((int) Math.round(x), (int) Math.round(y));
    }

    private static Rectangle desenharTabuleiroMantendoProporcao(Graphics2D g2,
                                                                Image img,
                                                                ImageIcon icon,
                                                                int panelW,
                                                                int panelH) {
        int iw = (icon != null ? icon.getIconWidth() : -1);
        int ih = (icon != null ? icon.getIconHeight() : -1);
        if (iw <= 0 || ih <= 0) {
            iw = img.getWidth(null);
            ih = img.getHeight(null);
        }
        if (iw <= 0 || ih <= 0) return new Rectangle(0, 0, panelW, panelH);

        double s = Math.min(panelW / (double) iw, panelH / (double) ih);
        int w = (int) Math.round(iw * s);
        int h = (int) Math.round(ih * s);
        int x = (panelW - w) / 2;
        int y = (panelH - h) / 2;

        g2.drawImage(img, x, y, w, h, null);
        return new Rectangle(x, y, w, h);
    }

    // ====================== Pinos / estado ======================

    private void carregarPinosSeNecessario() {
        if (!imagensPinoPorId.isEmpty()) return;
        for (int pinId = 0; pinId < 6; pinId++) {
            ImageIcon ic = new ImageIcon("imagem/pinos/pin" + pinId + ".png");
            Image pin = (ic.getIconWidth() > 0 ? ic.getImage() : null);
            if (pin != null) {
                pin = pin.getScaledInstance(PIN_W, PIN_H, Image.SCALE_SMOOTH);
            }
            imagensPinoPorId.add(pin);
        }
    }

    private Image imagemDoPino(int pinId) {
        if (pinId < 0 || pinId >= imagensPinoPorId.size()) return null;
        return imagensPinoPorId.get(pinId);
    }

    private void sincronizarUltimasPosicoes(int n) {
        if (ultimasPosicoes == null || ultimasPosicoes.length != n) {
            ultimasPosicoes = new int[n];
            for (int i = 0; i < n; i++) {
                ultimasPosicoes[i] = gm.getPosicaoDoJogadorPorIndice(i);
            }
        }
    }

    private static Point deslocamentoSutilPorJogador(int idx) {
        int dx = (idx % 3 == 0) ? 0 : 1;
        int dy = (idx / 3 == 0) ? 0 : 1;
        return new Point(dx, dy);
    }
}
