package view;

import controller.GameManager;

import javax.swing.*;
import java.awt.*;

public class JanelaUnica extends JFrame {

    private final GameManager game = GameManager.getInstance();
    private boolean endDialogShown = false;

    private void onSalvarJogo() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Salvar jogo em arquivo (.txt)");
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        java.io.File file = chooser.getSelectedFile();
        if (file == null) return;

        String path = file.getAbsolutePath();
        if (!path.toLowerCase().endsWith(".txt")) {
            path = path + ".txt";
        }

        // Só tenta salvar, sem popup
        game.salvarJogoEmArquivo(path);
    }

    public JanelaUnica() {
        super("Banco Imobiliário — Iteração 2");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        // CENTER: Tabuleiro
        PainelTabuleiro painelTabuleiro = new PainelTabuleiro();
        painelTabuleiro.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        add(painelTabuleiro, BorderLayout.CENTER);

        // WEST: coluna com botão salvar, carta e dados
        JPanel colunaEsquerda = new JPanel(new BorderLayout(6, 6));
        colunaEsquerda.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));

        JPanel painelTopoEsquerdo = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        JButton botaoSalvar = new JButton("Salvar partida");
        botaoSalvar.addActionListener(e -> onSalvarJogo());
        painelTopoEsquerdo.add(botaoSalvar);
        colunaEsquerda.add(painelTopoEsquerdo, BorderLayout.NORTH);

        PainelCarta painelCarta = new PainelCarta();
        colunaEsquerda.add(painelCarta, BorderLayout.CENTER);

        PainelDados painelDados = new PainelDados();
        colunaEsquerda.add(painelDados, BorderLayout.SOUTH);

        colunaEsquerda.setPreferredSize(new Dimension(300, 600));
        add(colunaEsquerda, BorderLayout.WEST);

        // SOUTH: log
        PainelLog painelLog = new PainelLog();
        painelLog.setPreferredSize(new Dimension(200, 140));
        add(painelLog, BorderLayout.SOUTH);

        // Listener global (classe anônima, não lambda)
        game.addGameListener(new controller.GameListener() {
            @Override
            public void onGameStateChanged() {
                repaint();
                if (!endDialogShown && game.jogoEncerrado()) {
                    endDialogShown = true;
                    EndGameDialog dlg = new EndGameDialog(JanelaUnica.this, game.getRankingPorSaldo());
                    dlg.setVisible(true);
                }
            }
        });

        setSize(1200, 820);
    }
}
