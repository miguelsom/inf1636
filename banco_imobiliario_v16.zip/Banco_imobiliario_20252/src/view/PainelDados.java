package view;

import controller.GameListener;
import controller.GameManager;

import javax.swing.*;
import java.awt.*;

/**
 * Painel dos Dados (versão simples).
 *
 * - Mostra 2 dados.
 * - Botões: Rolar, Demais ações, Encerrar turno, Encerrar partida.
 * - Atalho 'T' para testar dados (definir manualmente 1..6).
 * - Faixa no topo mostrando o jogador da vez, cor do pino e saldo.
 *
 * Regras de habilitação:
 * - Se game.podeRolarDados() == true:
 *      -> só "Rolar dados" (Demais ações / Encerrar turno desabilitados).
 * - Se game.podeRolarDados() == false:
 *      -> "Demais ações" e "Encerrar turno" habilitados.
 * - "Encerrar partida" sempre habilitado.
 */
public class PainelDados extends JPanel implements GameListener {

    private static final long serialVersionUID = 1L;

    private final GameManager game = GameManager.getInstance();

    private final DadoView dado1View;
    private final DadoView dado2View;

    private final JButton btnRolar;
    private final JButton btnDemaisAcoes;
    private final JButton btnEncerrarTurno;
    private final JButton btnEncerrarPartida;
    private final JLabel  lblInfo;

    // Faixa do jogador da vez
    private final JPanel faixaJogador;
    private final JLabel lblJogador;
    private final JLabel lblSaldo;

    public PainelDados() {
        setOpaque(false);
        setLayout(new BorderLayout(4, 4));
        setPreferredSize(new Dimension(280, 210));

        // ===== TOPO: faixa do jogador da vez (cor + nome + saldo) =====
        faixaJogador = new JPanel(new GridLayout(2, 1, 0, 0));
        lblJogador = new JLabel("Jogador da vez: —", SwingConstants.CENTER);
        lblSaldo   = new JLabel("Saldo: R$ 0",      SwingConstants.CENTER);
        faixaJogador.add(lblJogador);
        faixaJogador.add(lblSaldo);
        add(faixaJogador, BorderLayout.NORTH);

        // ===== CENTRO: dados =====
        JPanel painelDados = new JPanel(new GridLayout(1, 2, 6, 6));
        painelDados.setOpaque(false);

        dado1View = new DadoView();
        dado2View = new DadoView();
        painelDados.add(dado1View);
        painelDados.add(dado2View);

        add(painelDados, BorderLayout.CENTER);

        // ===== SUL: botões + info =====
        JPanel painelSul = new JPanel(new BorderLayout(4, 4));
        painelSul.setOpaque(false);

        JPanel painelBotoes = new JPanel(new GridLayout(2, 2, 4, 4));
        painelBotoes.setOpaque(false);

        btnRolar = new JButton("Rolar dados");
        btnRolar.addActionListener(e -> game.rolarDados());
        painelBotoes.add(btnRolar);

        btnDemaisAcoes = new JButton("Demais ações");
        btnDemaisAcoes.addActionListener(e -> abrirDialogoDemaisAcoes());
        painelBotoes.add(btnDemaisAcoes);

        btnEncerrarTurno = new JButton("Encerrar turno");
        btnEncerrarTurno.addActionListener(e -> game.encerrarTurno());
        painelBotoes.add(btnEncerrarTurno);

        btnEncerrarPartida = new JButton("Encerrar partida");
        btnEncerrarPartida.addActionListener(e -> game.encerrarJogoAgora());
        painelBotoes.add(btnEncerrarPartida);

        painelSul.add(painelBotoes, BorderLayout.CENTER);

        lblInfo = new JLabel("Rolar dados é a primeira ação. Use 'T' para teste.", SwingConstants.LEFT);
        painelSul.add(lblInfo, BorderLayout.SOUTH);

        add(painelSul, BorderLayout.SOUTH);

        // Atalho 'T' para testar dados
        registrarAtalhoTeste();

        // Registrar listener e atualizar UI inicial
        game.addGameListener(this);
        atualizarDosDados();
    }

    // ---------------------- Demais ações ----------------------
    private void abrirDialogoDemaisAcoes() {
        Window parent = SwingUtilities.getWindowAncestor(this);
        DialogoDemaisAcoes dlg = new DialogoDemaisAcoes(parent);
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }

    // ---------------------- Atalho 'T' (teste de dados) ----------------------
    private void registrarAtalhoTeste() {
        InputMap im = getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = getActionMap();

        im.put(KeyStroke.getKeyStroke('T'), "testeDados");
        im.put(KeyStroke.getKeyStroke('t'), "testeDados");

        am.put("testeDados", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                abrirDialogoTesteDados();
            }
        });
    }

    private void abrirDialogoTesteDados() {
        Window parent = SwingUtilities.getWindowAncestor(this);

        JDialog dlg;
        if (parent instanceof Frame) {
            dlg = new JDialog((Frame) parent, "Teste de dados", true);
        } else if (parent instanceof Dialog) {
            dlg = new JDialog((Dialog) parent, "Teste de dados", true);
        } else {
            dlg = new JDialog((Frame) null, "Teste de dados", true);
        }

        dlg.setLayout(new BorderLayout(8, 8));

        JPanel centro = new JPanel(new GridLayout(2, 2, 6, 6));
        centro.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        centro.add(new JLabel("Dado 1:", SwingConstants.RIGHT));
        JComboBox<Integer> combo1 = new JComboBox<>();
        centro.add(combo1);

        centro.add(new JLabel("Dado 2:", SwingConstants.RIGHT));
        JComboBox<Integer> combo2 = new JComboBox<>();
        centro.add(combo2);

        for (int i = 1; i <= 6; i++) {
            combo1.addItem(i);
            combo2.addItem(i);
        }

        dlg.add(centro, BorderLayout.CENTER);

        JPanel sul = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 4));
        JButton btnAplicar = new JButton("Aplicar");
        JButton btnCancelar = new JButton("Cancelar");
        sul.add(btnCancelar);
        sul.add(btnAplicar);
        dlg.add(sul, BorderLayout.SOUTH);

        btnCancelar.addActionListener(e -> dlg.dispose());
        btnAplicar.addActionListener(e -> {
            Integer v1 = (Integer) combo1.getSelectedItem();
            Integer v2 = (Integer) combo2.getSelectedItem();
            if (v1 != null && v2 != null) {
                game.rolarDadosForcado(v1, v2);
            }
            dlg.dispose();
        });

        dlg.pack();
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }

    // ---------------------- GameListener ----------------------
    @Override
    public void onGameStateChanged() {
        atualizarDosDados();
    }

    private void atualizarDosDados() {
        // Atualiza os dados
        int[] ult = game.getUltimoLancamento();
        if (ult != null && ult.length == 2) {
            dado1View.setValor(ult[0]);
            dado2View.setValor(ult[1]);
        } else {
            dado1View.setValor(0);
            dado2View.setValor(0);
        }

        // Faixa do jogador da vez (nome + cor + saldo)
        String nome = game.getNomeJogadorDaVez();
        lblJogador.setText("Jogador da vez: " + nome);
        lblSaldo.setText("Saldo: R$ " + game.getSaldoJogadorDaVez());
        int pinId = game.getPinIdDoJogadorDaVez();
        faixaJogador.setBackground(corDoPin(pinId));
        faixaJogador.setOpaque(true);

        // Habilitação de botões
        boolean podeRolar = game.podeRolarDados();

        btnRolar.setEnabled(podeRolar);
        btnDemaisAcoes.setEnabled(!podeRolar);
        btnEncerrarTurno.setEnabled(!podeRolar);
        btnEncerrarPartida.setEnabled(true);

        if (podeRolar) {
            lblInfo.setText("Rolar dados é obrigatório. Use 'T' para teste.");
        } else {
            lblInfo.setText("Você pode usar Demais ações ou Encerrar turno.");
        }

        repaint();
    }

    // Mapeia id do pin -> cor simples
    private Color corDoPin(int id) {
        switch (id) {
            case 0: return new Color(220, 60, 60);   // Vermelho
        case 1: return new Color(60, 90, 200);   // Azul
            case 2: return new Color(240, 140, 40);  // Laranja
            case 3: return new Color(230, 210, 60);  // Amarelo
            case 4: return new Color(150, 90, 190);  // Roxo
            case 5: return new Color(140, 140, 140); // Cinza
            default: return Color.LIGHT_GRAY;
        }
    }

    // ---------------------- DadoView (desenho simples) ----------------------
    private static class DadoView extends JComponent {

        private static final long serialVersionUID = 1L;

        private static final String PATH_BASE = "imagem/dados/die_face_";
        private static final String EXT       = ".png";

        private final Image[] faces = new Image[7]; // 1..6
        private int valor = 0; // 0 = nenhum

        public DadoView() {
            setPreferredSize(new Dimension(60, 60));
            setOpaque(false);
            carregarImagens();
        }

        private void carregarImagens() {
            for (int i = 1; i <= 6; i++) {
                try {
                    ImageIcon ic = new ImageIcon(PATH_BASE + i + EXT);
                    faces[i] = ic.getImage();
                } catch (Exception e) {
                    e.printStackTrace();
                    faces[i] = null;
                }
            }
        }

        public void setValor(int v) {
            if (v < 1 || v > 6) {
                this.valor = 0;
            } else {
                this.valor = v;
            }
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();
            try {
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                // Fundo do dado
                g2.setColor(new Color(250, 250, 250));
                g2.fillRoundRect(2, 2, w - 4, h - 4, 12, 12);
                g2.setColor(Color.GRAY);
                g2.drawRoundRect(2, 2, w - 4, h - 4, 12, 12);

                if (valor >= 1 && valor <= 6 && faces[valor] != null) {
                    Image img = faces[valor];
                    int imgW = img.getWidth(null);
                    int imgH = img.getHeight(null);
                    if (imgW > 0 && imgH > 0) {
                        int availW = w - 10;
                        int availH = h - 10;
                        double scale = Math.min(
                                (double) availW / imgW,
                                (double) availH / imgH
                        );
                        int drawW = (int) (imgW * scale);
                        int drawH = (int) (imgH * scale);
                        int x = 2 + (w - 4 - drawW) / 2;
                        int y = 2 + (h - 4 - drawH) / 2;
                        g2.drawImage(img, x, y, drawW, drawH, null);
                    }
                } else {
                    g2.setColor(Color.DARK_GRAY);
                    g2.setFont(getFont().deriveFont(Font.BOLD, 14f));
                    String s = "-";
                    FontMetrics fm = g2.getFontMetrics();
                    int textW = fm.stringWidth(s);
                    int textH = fm.getAscent();
                    int x = (w - textW) / 2;
                    int y = (h + textH) / 2 - 3;
                    g2.drawString(s, x, y);
                }

            } finally {
                g2.dispose();
            }
        }
    }
}
