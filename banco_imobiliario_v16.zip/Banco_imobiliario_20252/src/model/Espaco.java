package model;

/**
 * Representa um espaço genérico do tabuleiro.
 * 
 * Cada {@code Espaco} possui um nome exibível e um {@link Tipo}
 * que determina o seu comportamento no jogo.
 * 
 */
abstract class Espaco {

    /**
     * Tipos possíveis de espaços do tabuleiro.
     */
    enum Tipo {
        /** Casa inicial/partida. */
        PARTIDA,
        /** Propriedade negociável (terreno/companhia). */
        PROPRIEDADE,
        /** Cartas de sorte/revés (tipo unificado). */
        SORTE_OU_REVES,
        /** Prisão (apenas visita ao cair exatamente). */
        PRISAO,
        /** Vai direto para a prisão. */
        VA_PARA_PRISAO,
        /** Parada livre, sem efeitos. */
        PARADA_LIVRE,
        /** Ganhos diversos (sem efeito nesta iteração). */
        LUCROS_DIVIDENDOS,
        /** Cobrança de impostos (sem efeito nesta iteração). */
        IMPOSTO
    }

    private final String nome;
    private final Tipo tipo;

    /**
     * Cria um espaço genérico do tabuleiro.
     *
     * @param nome nome exibível do espaço
     * @param tipo tipo do espaço
     */
    Espaco(String nome, Tipo tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }

    /**
     * @return o nome exibível do espaço
     */
    String getNome() { return nome; }

    /**
     * @return o {@link Tipo} deste espaço
     */
    Tipo getTipo() { return tipo; }
}
