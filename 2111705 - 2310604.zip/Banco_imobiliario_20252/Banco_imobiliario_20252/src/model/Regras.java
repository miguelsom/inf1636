package model;

/**
 * Conjunto de parâmetros e constantes de regras do jogo (1ª iteração).
 * 
 * Classe utilitária não instanciável que centraliza os valores usados
 * pelo modelo para evitar “números mágicos”.
 * 
 */
final class Regras {

    // ===== Economia =====

    /** Saldo inicial atribuído a cada jogador. */
    static final int SALDO_INICIAL = 1500;

    /** Bônus recebido ao cruzar a casa de Partida. */
    static final int BONUS_PARTIDA = 200;

    // ===== Prisão =====

    /**
     * Quantidade máxima de tentativas na prisão antes de sair compulsoriamente.
     * Na 3ª tentativa, o jogador paga multa e sai.
     */
    static final int TURNOS_MAX_PRISAO = 3;

    /** Multa cobrada para sair da prisão na 3ª tentativa. */
    static final int MULTA_SAIDA_PRISAO = 50;

    // ===== Falência =====

    /**
     * Valor mínimo de saldo para o jogador continuar ativo.
     * Saldos inferiores a este valor significam eliminação.
     */
    static final int VALOR_MINIMO_ATIVO = 1;

    private Regras() { }
}
