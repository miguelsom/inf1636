package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Model Facade
 * 
 * Expõe operações de alto nível para o controlador:
 * gerenciamento de jogadores/turnos, rolagem/movimento,
 * efeitos de casas, compra/construção/venda de propriedades
 * e regras de prisão/falência.
 * 
 */
public class ModelFacade {

    // ======================
    // ====== DTOs ==========
    // ======================

    /**
     * Visão imutável do estado de um jogador para a UI.
     */
    public static final class PlayerSnapshot {
        private final String nome;
        private final int saldo;
        private final int posicao;
        private final boolean preso;
        private final int qtdProps;

        /**
         * @param nome     nome do jogador
         * @param saldo    saldo atual em moeda do jogo
         * @param posicao  índice da posição no tabuleiro
         * @param preso    indica se está preso
         * @param qtdProps quantidade de propriedades possuídas
         */
        public PlayerSnapshot(String nome, int saldo, int posicao, boolean preso, int qtdProps) {
            this.nome = nome; this.saldo = saldo; this.posicao = posicao; this.preso = preso; this.qtdProps = qtdProps;
        }

        /** @return nome do jogador */
        public String getNome() { return nome; }
        /** @return saldo atual */
        public int getSaldo() { return saldo; }
        /** @return posição no tabuleiro */
        public int getPosicao() { return posicao; }
        /** @return {@code true} se o jogador está preso */
        public boolean isPreso() { return preso; }
        /** @return quantidade de propriedades */
        public int getQtdProps() { return qtdProps; }
    }

    /**
     * Resultado de um deslocamento no tabuleiro.
     */
    public static final class MovementResult {
        private final int novaPosicao;
        private final String nomeCasa;
        private final Espaco.Tipo tipo;

        /**
         * @param novaPosicao índice da nova posição
         * @param nomeCasa    nome do espaço/casa de destino
         * @param tipo        tipo do espaço de destino
         */
        public MovementResult(int novaPosicao, String nomeCasa, Espaco.Tipo tipo) {
            this.novaPosicao = novaPosicao; this.nomeCasa = nomeCasa; this.tipo = tipo;
        }

        /** @return nova posição após o movimento */
        public int getNovaPosicao() { return novaPosicao; }
        /** @return nome da casa/espaco de destino */
        public String getNomeCasa() { return nomeCasa; }
        /**
         * Alias compatível com controladores existentes.
         * @return nome da casa/espaço
         */
        public String getNomeEspaco() { return nomeCasa; }
        /** @return tipo do espaço de destino */
        public Espaco.Tipo getTipo() { return tipo; }
    }

    /**
     * Visão imutável de uma propriedade para listagens/menus.
     */
    public static final class PropriedadeSnapshot {
        private final String nome;
        private final int casas;
        private final boolean hotel;
        private final int preco;
        private final int precoConstrucao;

        /**
         * @param nome             nome da propriedade
         * @param casas            quantidade de casas construídas
         * @param hotel            se há hotel construído
         * @param preco            custo de compra
         * @param precoConstrucao  custo por construção (casa/hotel)
         */
        public PropriedadeSnapshot(String nome, int casas, boolean hotel, int preco, int precoConstrucao) {
            this.nome = nome; this.casas = casas; this.hotel = hotel; this.preco = preco; this.precoConstrucao = precoConstrucao;
        }

        /** @return nome */
        public String getNome() { return nome; }
        /** @return nº de casas */
        public int getCasas() { return casas; }
        /** @return {@code true} se há hotel */
        public boolean isHotel() { return hotel; }
        /** @return preço de compra */
        public int getPreco() { return preco; }
        /** @return preço de construção (casa/hotel) */
        public int getPrecoConstrucao() { return precoConstrucao; }
    }

    // ==========================
    // ===== Estado interno =====
    // ==========================

    private final Tabuleiro tabuleiro = new Tabuleiro();
    private final List<Jogador> jogadores = new ArrayList<>();
    private int indiceJogadorAtual = 0;

    // ======================
    // ====== Setup =========
    // ======================

    /**
     * Limpa o estado do jogo (remove todos os jogadores e reseta a vez).
     */
    public void reset() {
        jogadores.clear();
        indiceJogadorAtual = 0;
    }

    /**
     * Adiciona um novo jogador com saldo inicial definido em {@link Regras#SALDO_INICIAL}.
     * @param nome nome do jogador
     */
    public void adicionarJogador(String nome) {
        jogadores.add(new Jogador(nome, Regras.SALDO_INICIAL));
    }

    // =========================
    // ======= Consultas =======
    // =========================

    private Jogador jogadorDaVez() {
        return jogadores.get(indiceJogadorAtual);
    }

    /**
     * @return um {@link PlayerSnapshot} do jogador da vez.
     */
    public PlayerSnapshot getJogadorDaVezSnapshot() {
        Jogador j = jogadorDaVez();
        return new PlayerSnapshot(j.getNome(), j.getSaldo(), j.getPosicao(), j.isPreso(), j.getPropriedades().size());
    }

    /**
     * @return snapshots imutáveis de todos os jogadores.
     */
    public List<PlayerSnapshot> getJogadoresSnapshot() {
        List<PlayerSnapshot> out = new ArrayList<>();
        for (Jogador j : jogadores)
            out.add(new PlayerSnapshot(j.getNome(), j.getSaldo(), j.getPosicao(), j.isPreso(), j.getPropriedades().size()));
        return Collections.unmodifiableList(out);
    }

    /**
     * @return {@code true} se restar 0 ou 1 jogador ativo (jogo encerrado).
     */
    public boolean jogoEncerrado() {
        int vivos = 0;
        for (Jogador j : jogadores) if (j.estaAtivo()) vivos++;
        return vivos <= 1;
    }

    // =================================
    // ===== Dados / Movimento ==========
    // =================================

    /**
     * Rola dois dados.
     * @return vetor de tamanho 2 com os valores dos dados
     */
    public int[] lancarDados() {
        return Dado.rolarDois();
    }

    /**
     * Desloca o jogador da vez pelo número de {@code passos}.
     * Aplica o bônus de passagem na partida se cruzar o início.
     *
     * @param passos quantidade de casas a avançar (pode ser > tamanho do tabuleiro)
     * @return {@link MovementResult} com a nova posição e metadados do espaço
     */
    public MovementResult deslocarJogadorDaVez(int passos) {
        Jogador j = jogadorDaVez();
        int posAnterior = j.getPosicao(), tamanho = tabuleiro.tamanho();
        int soma = posAnterior + passos, novaPos = soma % tamanho;
        if (soma >= tamanho) j.creditar(Regras.BONUS_PARTIDA); // cruzou a partida
        j.setPosicao(novaPos);
        Espaco e = tabuleiro.getEspaco(novaPos);
        return new MovementResult(novaPos, e.getNome(), e.getTipo());
    }

    // =========================
    // ========= Prisão ========
    // =========================

    /**
     * Usa (se houver) a carta "Sair da Prisão" do jogador da vez.
     * @return {@code true} se a carta existia e o jogador foi solto
     */
    public boolean usarCartaSairLivreDaVez() {
        Jogador j = jogadorDaVez();
        if (j.consumirCartaSaidaLivreSeDisponivel()) { j.sairDaPrisao(); return true; }
        return false;
    }

    /**
     * Tenta sair da prisão rolando dados informados.
     * <ul>
     *   <li>Se for dupla, sai imediatamente.</li>
     *   <li>Se atingir {@link Regras#TURNOS_MAX_PRISAO}, paga {@link Regras#MULTA_SAIDA_PRISAO} e sai.</li>
     *   <li>Caso contrário, permanece preso e incrementa o contador de turnos.</li>
     * </ul>
     *
     * @param d1 valor do primeiro dado
     * @param d2 valor do segundo dado
     * @return {@code true} se saiu da prisão após esta tentativa
     */
    public boolean tentarSairDaPrisaoComDadosDaVez(int d1, int d2) {
        Jogador j = jogadorDaVez(); if (!j.isPreso()) return true;
        if (d1 == d2) { j.sairDaPrisao(); return true; }
        j.incrementarTurnoPrisao();
        if (j.getTurnosNaPrisao() >= Regras.TURNOS_MAX_PRISAO) {
            j.debitar(Regras.MULTA_SAIDA_PRISAO);
            j.sairDaPrisao();
            return true;
        }
        return false;
    }
    
    public void concederCartaSairLivreJogadorDaVez() {
        Jogador j = jogadorDaVez();
        if (j != null) {
            j.ganharCartaSaidaLivre();
        }
    }

    // ==================================
    // ===== Efeitos da casa atual ======
    // ==================================

    /**
     * Processa o efeito do espaço onde o jogador da vez está.
     * Implementa ida direta à prisão e regras de aluguel simplificadas.
     * Companhias (preço de construção ≤ 0) não constroem e cobram aluguel-base.
     * Terrenos, nesta iteração, cobram somente se houver ao menos uma casa ou hotel.
     */
    public void processarCasaAtualDaVez() {
        Jogador j = jogadorDaVez();
        Espaco e = tabuleiro.getEspaco(j.getPosicao());

        switch (e.getTipo()) {
            case VA_PARA_PRISAO:
                j.enviarParaPrisao(tabuleiro.getIndicePrisao());
                break;

            case PROPRIEDADE: {
                Propriedade p = (Propriedade) e;
                Jogador dono = p.getDono();
                if (dono != null && dono != j) {
                    final boolean ehCompanhia = p.getPrecoConstrucao() <= 0; // companhias não constroem
                    if (ehCompanhia) {
                        int aluguel = p.calcularAluguel(); // aluguel-base
                        j.debitar(aluguel);
                        dono.creditar(aluguel);
                    } else {
                        // terrenos: cobra apenas com ≥1 casa ou hotel
                        if (p.getCasas() > 0 || p.isHotel()) {
                            int aluguel = p.calcularAluguel();
                            j.debitar(aluguel);
                            dono.creditar(aluguel);
                        }
                    }
                }
                break;
            }

            case SORTE_OU_REVES:
            case LUCROS_DIVIDENDOS:
            case PARADA_LIVRE:
            case IMPOSTO:
            case PRISAO:
            case PARTIDA:
            default:
                // Sem efeitos nesta iteração.
                break;
        }
    }

    // =====================================
    // === Ações na propriedade do turno ===
    // =====================================

    /**
     * Tenta comprar a propriedade atual do jogador da vez.
     * @return {@code true} se a compra foi realizada
     */
    public boolean comprarPropriedadeAtualDaVez() {
        Jogador j = jogadorDaVez();
        Espaco e = tabuleiro.getEspaco(j.getPosicao());
        if (!(e instanceof Propriedade)) return false;

        Propriedade p = (Propriedade) e;
        if (p.getDono() != null) return false;
        if (j.getSaldo() < p.getPreco()) return false;

        j.debitar(p.getPreco());
        p.setDono(j);
        j.adicionarPropriedade(p);
        return true;
    }

    /**
     * Constrói (casa/hotel) na propriedade onde o jogador da vez está.
     * Bloqueia construção em companhias (preço de construção ≤ 0).
     *
     * @return {@code true} se a construção foi efetuada
     */
    public boolean construirNaPropriedadeAtualDaVez() {
        Jogador j = jogadorDaVez();
        Espaco e = tabuleiro.getEspaco(j.getPosicao());
        if (!(e instanceof Propriedade)) return false;

        Propriedade p = (Propriedade) e;
        if (p.getDono() != j) return false;
        if (p.isHotel()) return false;
        if (p.getPrecoConstrucao() <= 0) return false; // companhia

        if (j.getSaldo() < p.getPrecoConstrucao()) return false;

        j.debitar(p.getPrecoConstrucao());
        p.construirCasaOuHotel();
        return true;
    }

    // ==============================
    // ========= Vendas =============
    // ==============================

    /**
     * Lista propriedades do jogador da vez em formato de snapshot.
     * @return lista imutável de {@link PropriedadeSnapshot}
     */
    public List<PropriedadeSnapshot> getPropriedadesDoJogadorDaVez() {
        Jogador j = jogadorDaVez();
        List<PropriedadeSnapshot> out = new ArrayList<>();
        for (Propriedade p : j.getPropriedades())
            out.add(new PropriedadeSnapshot(p.getNome(), p.getCasas(), p.isHotel(), p.getPreco(), p.getPrecoConstrucao()));
        return out;
    }

    /**
     * Vende a propriedade (por nome) do jogador da vez de volta ao banco.
     * Remove a propriedade do jogador se a venda ocorrer.
     *
     * @param nome nome exato da propriedade
     * @return {@code true} se a venda foi realizada
     */
    public boolean venderPropriedadePorNome(String nome) {
        Jogador j = jogadorDaVez();
        Propriedade p = tabuleiro.encontrarPropriedadePorNome(nome);
        if (p == null || p.getDono() != j) return false;
        boolean ok = p.venderDeVoltaAoBanco(j);
        if (ok) j.removerPropriedade(p);
        return ok;
    }

    // ====================================
    // ==== Falência / avanço de turno ====
    // ====================================

    /**
     * Remove jogadores falidos, devolvendo propriedades ao banco e
     * ajustando o índice do jogador da vez quando necessário.
     */
    private void removerFalidos() {
        if (jogadores.isEmpty()) return;
        for (int i = jogadores.size() - 1; i >= 0; i--) {
            Jogador j = jogadores.get(i);
            if (!j.estaAtivo()) {
                for (Propriedade p : j.limparPropriedades()) p.resetarParaBanco();
                jogadores.remove(i);
                if (i < indiceJogadorAtual) indiceJogadorAtual--;
            }
        }
        if (indiceJogadorAtual < 0 && !jogadores.isEmpty()) indiceJogadorAtual = 0;
        if (indiceJogadorAtual >= jogadores.size() && !jogadores.isEmpty()) indiceJogadorAtual = 0;
    }

    /**
     * Finaliza o turno atual, resolve falências e passa a vez.
     */
    public void finalizarTurno() {
        removerFalidos();
        if (jogadores.isEmpty()) return;
        indiceJogadorAtual = (indiceJogadorAtual + 1) % jogadores.size();
    }
}
