package view;

import java.util.List;
import java.util.Scanner;
import model.ModelFacade.PlayerSnapshot;


public class VisaoConsole {

    public static int perguntarQuantidadeJogadores(Scanner in) {
        while (true) {
            System.out.print("Quantos jogadores? (2–6): ");
            String s = in.nextLine().trim();
            try {
                int n = Integer.parseInt(s);
                if (n >= 2 && n <= 6) return n;
            } catch (NumberFormatException ignored) {}
            System.out.println("Valor inválido. Tente novamente.");
        }
    }

    public static int perguntarQtdJogadores(Scanner in) {
        return perguntarQuantidadeJogadores(in);
    }

    public static String perguntarNomeJogador(Scanner in, int idx) {
        while (true) {
            System.out.print("Nome do jogador " + idx + ": ");
            String nome = in.nextLine().trim();
            if (!nome.isEmpty()) return nome;
            System.out.println("Nome não pode ser vazio.");
        }
    }

    public static int perguntarNumero(Scanner in, String mensagem) {
        while (true) {
            System.out.print(mensagem);
            String s = in.nextLine().trim();
            try { return Integer.parseInt(s); }
            catch (NumberFormatException e) { System.out.println("Entrada inválida."); }
        }
    }

    public static String perguntarTexto(Scanner in, String mensagem) {
        System.out.print(mensagem);
        return in.nextLine();
    }

    public static boolean confirmar(Scanner in, String msg) {
        System.out.print(msg);
        String s = in.nextLine().trim().toLowerCase();
        return s.startsWith("s");
    }

    public static void aguardarEnter(Scanner in, String msg) {
        System.out.print(msg);
        in.nextLine();
    }

    public static void mostrarCabecalhoTurno(PlayerSnapshot ps) {
        System.out.println("\n============================");
        System.out.println("Vez de: " + ps.getNome()
                + " | Saldo: $" + ps.getSaldo()
                + " | Posição: " + ps.getPosicao()
                + (ps.isPreso() ? " | (Preso)" : ""));
        System.out.println("============================");
    }

    /** Exibe a rolagem de dois dados. */
    public static void mostrarRolagem(int d1, int d2) {
        System.out.println("Dados: " + d1 + " + " + d2 + " = " + (d1 + d2));
    }

    /**
     * Mostra o movimento segundo a assinatura usada no seu ControladorJogo:
     * nome do jogador, posição e nome do espaço.
     */
    public static void mostrarMovimento(String nomeJogador, int posicao, String nomeEspaco) {
        System.out.println(nomeJogador + " moveu para a posição " + posicao + " (" + nomeEspaco + ")");
    }

    /** Alias mantido (versões anteriores usavam esta forma). */
    public static void mostrarMovimento(String nomeCasa, String tipo) {
        System.out.println("Parou em: " + nomeCasa + "  [" + tipo + "]");
    }

    /** Mensagem informativa simples. */
    public static void mostrarInfo(String msg) { System.out.println(msg); }

    // ==========================
    // Prisão
    // ==========================

    /** Menu quando o jogador está preso. */
    public static int menuPrisao(Scanner in) {
        System.out.println("Você está na prisão. Escolha:");
        System.out.println("1) Usar carta 'Sair Livre'");
        System.out.println("2) Tentar sair com dupla");
        System.out.println("3) Aguardar próximo turno");
        while (true) {
            System.out.print("Opção: ");
            String s = in.nextLine().trim();
            if ("1".equals(s) || "2".equals(s) || "3".equals(s)) return Integer.parseInt(s);
            System.out.println("Opção inválida.");
        }
    }

    /** Feedback de falha na tentativa de sair com dupla. */
    public static void mostrarFalhaPrisao() {
        System.out.println("Você não conseguiu sair da prisão desta vez.");
    }

    /** Feedback de sucesso ao sair da prisão. */
    public static void mostrarSaidaPrisao() {
        System.out.println("Você saiu da prisão!");
    }

    // ==========================
    // Encerramento
    // ==========================

    /** Resumo final do jogo. */
    public static void mostrarEncerramento(List<PlayerSnapshot> snaps) {
        System.out.println("\n=== FIM DE JOGO ===");
        for (PlayerSnapshot ps : snaps) {
            System.out.println(ps.getNome() + " | Saldo: $" + ps.getSaldo());
        }
        System.out.println("===================");
    }
}
