import controller.ControladorJogo;
import model.ModelFacade;

/**
 * Ponto de entrada do jogo (console).
 * Mantém a mesma estrutura de pacotes do projeto.
 */
public class Main {
    public static void main(String[] args) {
        ModelFacade facade = new ModelFacade();
        ControladorJogo controlador = new ControladorJogo(facade);
        controlador.iniciarJogo();
    }
}
