package controller;

import model.ModelFacade;
import model.ModelFacade.PropriedadeSnapshot;
import java.util.List;

public class ControladorAcoes {

    private final ModelFacade facade;

    public ControladorAcoes(ModelFacade facade) {
        this.facade = facade;
    }

    public void processarCasaAtual() {
        facade.processarCasaAtualDaVez();
    }

    public boolean tentarComprarAtual() {
        return facade.comprarPropriedadeAtualDaVez();
    }

    public boolean construirNaAtual() {
        return facade.construirNaPropriedadeAtualDaVez();
    }

    public List<PropriedadeSnapshot> listarPropriedadesJogadorDaVez() {
        return facade.getPropriedadesDoJogadorDaVez();
    }

    public boolean venderPropriedadePorNome(String nome) {
        return facade.venderPropriedadePorNome(nome);
    }
}
