package view;

import javax.swing.*;

/**
 * Ponto de entrada da interface gráfica do jogo.
 *
 * Responsável apenas por iniciar a aplicação Swing
 * e abrir a janela inicial de configuração.
 */
public class MainGUI {

    /**
     * Método principal da aplicação.
     *
     * Cria e exibe a JanelaInicial na Event Dispatch Thread (EDT).
     *
     * @param args argumentos de linha de comando (não usados)
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JanelaInicial janelaInicial = new JanelaInicial();
            janelaInicial.setVisible(true);
        });
    }
}
