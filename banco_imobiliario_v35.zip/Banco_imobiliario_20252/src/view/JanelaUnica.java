package view;

import controller.GameManager;

import javax.swing.*;
import java.awt.*;

public class JanelaUnica extends JFrame {

    private final GameManager game = GameManager.getInstance();
    private boolean endDialogShown = false;

    private final JButton botaoSalvar;

    private String ultimoJogadorDaVez;
    private boolean salvamentoBloqueadoNesteTurno;

    private void onSalvarJogo() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Salvar jogo em arquivo (.txt)");
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        java.io.File file = chooser.getSelectedFile();
        if (file == null) return;

        String path = file.getAbsolutePath();
        if (!path.toLowerCase().endsWith(".txt")) {
            path = path + ".txt";
        }

        game.salvarJogoEmArquivo(path);
        salvamentoBloqueadoNesteTurno = true;
        atualizarBotaoSalvar();
    }

    private void atualizarBotaoSalvar() {
        if (game.jogoEncerrado()) {
            botaoSalvar.setEnabled(false);
            return;
        }

        String nomeAtual = game.getNomeJogadorDaVez();
        if (nomeAtual == null || nomeAtual.isEmpty()) {
            botaoSalvar.setEnabled(false);
            return;
        }

        if (ultimoJogadorDaVez == null || !ultimoJogadorDaVez.equals(nomeAtual)) {
            ultimoJogadorDaVez = nomeAtual;
            salvamentoBloqueadoNesteTurno = false;
        }

        boolean podeRolar = game.podeRolarDados();

        if (!podeRolar) {
            salvamentoBloqueadoNesteTurno = true;
        }

        boolean podeSalvar = podeRolar && !salvamentoBloqueadoNesteTurno;
        botaoSalvar.setEnabled(podeSalvar);
    }

    public JanelaUnica() {
        super("Banco Imobiliário — Iteração 2");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        PainelTabuleiro painelTabuleiro = new PainelTabuleiro();
        painelTabuleiro.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        add(painelTabuleiro, BorderLayout.CENTER);

        JPanel colunaEsquerda = new JPanel(new BorderLayout(6, 6));
        colunaEsquerda.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));

        JPanel painelTopoEsquerdo = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        botaoSalvar = new JButton("Salvar partida");
        botaoSalvar.addActionListener(e -> onSalvarJogo());
        painelTopoEsquerdo.add(botaoSalvar);
        colunaEsquerda.add(painelTopoEsquerdo, BorderLayout.NORTH);

        PainelCarta painelCarta = new PainelCarta();
        colunaEsquerda.add(painelCarta, BorderLayout.CENTER);

        PainelDados painelDados = new PainelDados();
        colunaEsquerda.add(painelDados, BorderLayout.SOUTH);

        colunaEsquerda.setPreferredSize(new Dimension(300, 600));
        add(colunaEsquerda, BorderLayout.WEST);

        PainelLog painelLog = new PainelLog();
        painelLog.setPreferredSize(new Dimension(200, 140));
        add(painelLog, BorderLayout.SOUTH);

        game.addGameListener(new controller.GameListener() {
            @Override
            public void onGameStateChanged() {
                repaint();
                atualizarBotaoSalvar();
                if (!endDialogShown && game.jogoEncerrado()) {
                    endDialogShown = true;
                    EndGameDialog dlg = new EndGameDialog(JanelaUnica.this, game.getRankingPorSaldo());
                    dlg.setVisible(true);
                }
            }
        });

        atualizarBotaoSalvar();

        setSize(1200, 820);
    }
}
