package view;

import controller.GameManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.HashSet;
import java.util.Set;

@SuppressWarnings("unchecked")
/**
 * Janela inicial do jogo.
 *
 * Permite:
 * - escolher a quantidade de jogadores
 * - atribuir um pino diferente para cada jogador
 * - iniciar uma nova partida
 * - carregar uma partida salva de arquivo
 */
public class JanelaInicial extends JFrame {

    private final JComboBox<Integer> comboQuantidade;
    private final JPanel painelSelecaoPinos;
    private JTextField[] camposNomeJogador;

    // Combos para escolher pinos e labels "Jogador X"
    private JComboBox<PinItem>[] combosDePinos;
    private JLabel[] labelsJogador;

    // Mensagem de erro/aviso simples no rodapé
    private final JLabel lblMensagem;

    // Opções fixas de pinos (id e rótulo)
    private static final PinItem[] OPCOES_PINO = {
            new PinItem(0, "Vermelho (0)"),
            new PinItem(1, "Azul (1)"),
            new PinItem(2, "Laranja (2)"),
            new PinItem(3, "Amarelo (3)"),
            new PinItem(4, "Roxo (4)"),
            new PinItem(5, "Cinza (5)")
    };

    /**
     * Cria a tela inicial com seleção de quantidade de jogadores
     * e escolha de pinos por jogador.
     */
    public JanelaInicial() {
        super("Banco Imobiliário — Nova Partida");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));
        setResizable(false);

        // Topo: seleção de quantidade de jogadores
        JPanel topo = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        topo.add(new JLabel("Quantidade de jogadores:"));
        comboQuantidade = new JComboBox<>(new Integer[]{2, 3, 4, 5, 6});
        comboQuantidade.setSelectedItem(2);
        comboQuantidade.addActionListener(e -> atualizarVisibilidadeLinhas());
        topo.add(comboQuantidade);
        add(topo, BorderLayout.NORTH);

        // Centro: painel que contém as linhas de seleção de pinos
        painelSelecaoPinos = new JPanel();
        painelSelecaoPinos.setBorder(BorderFactory.createTitledBorder("Seleção de pinos"));
        add(painelSelecaoPinos, BorderLayout.CENTER);

        // Rodapé: mensagem de feedback + botões de ação
        JPanel sul = new JPanel(new BorderLayout(4, 4));
        lblMensagem = new JLabel(" ", SwingConstants.LEFT);
        sul.add(lblMensagem, BorderLayout.NORTH);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        JButton botaoCarregar = new JButton("Carregar jogo...");
        botaoCarregar.addActionListener(this::onClickCarregar);
        botoes.add(botaoCarregar);

        JButton botaoIniciar = new JButton("Iniciar partida");
        botaoIniciar.addActionListener(this::onClickIniciar);
        botoes.add(botaoIniciar);

        sul.add(botoes, BorderLayout.SOUTH);
        add(sul, BorderLayout.SOUTH);

        // Cria as 6 linhas de seleção (fixas) e controla visibilidade por quantidade
        criarLinhasFixasDePinos();
        atualizarVisibilidadeLinhas();

        pack();
        setSize(520, 400);
        setLocationRelativeTo(null);
    }

    /**
     * Cria 6 linhas fixas de seleção de pinos
     * (Jogador 1 a Jogador 6) com combobox de cores.
     */
    private void criarLinhasFixasDePinos() {
        painelSelecaoPinos.setLayout(new GridLayout(6, 3, 4, 4));
        combosDePinos = new JComboBox[6];
        labelsJogador = new JLabel[6];
        camposNomeJogador = new JTextField[6];

        for (int i = 0; i < 6; i++) {
            JLabel lbl = new JLabel("Jogador " + (i + 1) + ":");
            labelsJogador[i] = lbl;
            painelSelecaoPinos.add(lbl);

            JTextField txtNome = new JTextField("Jogador " + (i + 1));
            camposNomeJogador[i] = txtNome;
            painelSelecaoPinos.add(txtNome);

            JComboBox<PinItem> comboPin = new JComboBox<>(OPCOES_PINO);
            comboPin.setSelectedIndex(i % OPCOES_PINO.length);
            combosDePinos[i] = comboPin;
            painelSelecaoPinos.add(comboPin);
        }
    }


    /**
     * Lê a quantidade de jogadores selecionada, garantindo limite entre 2 e 6.
     */
    private int getQtdJogadoresSelecionados() {
        Integer qtd = (Integer) comboQuantidade.getSelectedItem();
        if (qtd == null || qtd < 2) return 2;
        if (qtd > 6) return 6;
        return qtd;
    }

    /**
     * Mostra/esconde as linhas de seleção de pinos
     * de acordo com a quantidade de jogadores escolhida.
     */
    private void atualizarVisibilidadeLinhas() {
        int qtd = getQtdJogadoresSelecionados();
        for (int i = 0; i < 6; i++) {
            boolean visivel = i < qtd;
            labelsJogador[i].setVisible(visivel);
            combosDePinos[i].setVisible(visivel);
            if (camposNomeJogador != null) {
                camposNomeJogador[i].setVisible(visivel);
            }
        }
        lblMensagem.setText(" ");
    }


    /**
     * Ação do botão "Carregar jogo...".
     * Abre um JFileChooser, delega o carregamento ao GameManager
     * e, em caso de sucesso, abre a janela principal.
     */
    private void onClickCarregar(ActionEvent e) {
        lblMensagem.setText(" ");
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Selecione o arquivo de jogo salvo (.txt)");
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

        java.io.File file = chooser.getSelectedFile();
        if (file == null) {
            lblMensagem.setText("Arquivo inválido.");
            return;
        }

        boolean ok = GameManager.getInstance().carregarJogoDeArquivo(file.getAbsolutePath());
        if (!ok) {
            lblMensagem.setText("Erro ao carregar.");
            return;
        }

        JanelaUnica janelaPrincipal = new JanelaUnica();
        janelaPrincipal.setVisible(true);
        dispose();
    }

    /**
     * Ação do botão "Iniciar partida".
     * Valida a configuração de pinos (sem repetição),
     * inicia nova partida no GameManager e abre a janela principal.
     */
    private void onClickIniciar(ActionEvent e) {
        lblMensagem.setText(" ");
        int qtd = getQtdJogadoresSelecionados();

        int[] pinIds = new int[qtd];
        String[] nomes = new String[qtd];
        Set<Integer> usados = new HashSet<>();

        for (int i = 0; i < qtd; i++) {
            // Pino
            PinItem item = (PinItem) combosDePinos[i].getSelectedItem();
            if (item == null) {
                lblMensagem.setText("Configuração inválida.");
                return;
            }
            if (!usados.add(item.id)) {
                lblMensagem.setText("Pinos repetidos.");
                return;
            }
            pinIds[i] = item.id;

            // Nome
            String texto = camposNomeJogador[i].getText();
            if (texto == null || texto.trim().isEmpty()) {
                texto = "Jogador " + (i + 1);
            }
            nomes[i] = texto.trim();
        }

        GameManager gm = GameManager.getInstance();
        gm.iniciarNovaPartida(qtd, nomes);
        gm.definirPinsPorJogador(nomes, pinIds);

        JanelaUnica janelaPrincipal = new JanelaUnica();
        janelaPrincipal.setVisible(true);
        dispose();
    }


    /**
     * Item de combobox que representa um pino:
     * id usado pelo jogo e rótulo de exibição.
     */
    private static final class PinItem {
        final int id;
        final String label;

        PinItem(int id, String label) {
            this.id = id;
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }
}
