package view;

import controller.GameManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Diálogo final exibido quando o jogo termina.
 * Mostra o ranking dos jogadores e encerra a aplicação ao fechar.
 */
public class EndGameDialog extends JDialog {

    /**
     * Cria o diálogo de fim de jogo com o ranking final.
     *
     * @param owner   janela dona do diálogo
     * @param ranking lista ordenada de jogadores e seus saldos
     */
    public EndGameDialog(Window owner, List<GameManager.RankingItem> ranking) {
        super(owner, "Jogo Encerrado", ModalityType.APPLICATION_MODAL);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        JLabel titulo = new JLabel("Resultado Final", SwingConstants.CENTER);
        add(titulo, BorderLayout.NORTH);

        JPanel centro = new JPanel();
        int linhas = Math.max(ranking.size() + 1, 2);
        centro.setLayout(new GridLayout(linhas, 3, 4, 4));

        centro.add(new JLabel("Posição"));
        centro.add(new JLabel("Jogador"));
        centro.add(new JLabel("Saldo (R$)"));

        int pos = 1;
        for (GameManager.RankingItem it : ranking) {
            centro.add(new JLabel(pos + "º"));
            centro.add(new JLabel(it.nome));
            centro.add(new JLabel(String.valueOf(it.saldo)));
            pos++;
        }

        add(centro, BorderLayout.CENTER);

        JButton fechar = new JButton("Fechar");
        fechar.addActionListener(e -> System.exit(0));

        JPanel sul = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        sul.add(fechar);
        add(sul, BorderLayout.SOUTH);

        // Encerra automaticamente após alguns segundos
        Timer t = new Timer(10_000, e -> System.exit(0));
        t.start();

        setSize(350, 200);
    }
}
