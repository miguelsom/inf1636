package view;

import javax.swing.*;
import java.awt.*;

import controller.GameListener;
import controller.GameManager;

/**
 * Painel de status e ações rápidas do turno.
 *
 * Exibe informações básicas do jogador da vez (nome, posição e quantidade
 * de propriedades) e oferece dois botões centrais de fluxo:
 * - "Rolar Dados": rola os dados se ainda não tiver rolado no turno.
 * - "Encerrar Turno": passa a vez para o próximo jogador.
 *
 * Toda a lógica é delegada ao GameManager; o painel apenas lê estado
 * e dispara comandos simples.
 */
public class PainelStatus extends JPanel implements GameListener {

    private static final long serialVersionUID = 1L;

    /** Fachada de controle do jogo usada pela interface. */
    private final GameManager game;

    /** Rótulos com as informações do jogador da vez. */
    private final JLabel lblJogador;
    private final JLabel lblPosicao;
    private final JLabel lblProps;

    /** Botão para rolar os dados e botão para encerrar o turno. */
    private final JButton btnRolar;
    private final JButton btnEncerrar;

    /**
     * Cria o painel de status, registra-se como listener do jogo
     * e monta os componentes de texto e ação.
     */
    public PainelStatus() {
        super(new BorderLayout(8, 8));
        setOpaque(true);
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        this.game = GameManager.getInstance();
        this.game.addGameListener(this);

        // Título
        JLabel titulo = new JLabel("Mais Ações", SwingConstants.LEFT);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 14));
        add(titulo, BorderLayout.NORTH);

        // Centro com infos (sem saldo)
        JPanel centro = new JPanel(new GridLayout(3, 1, 4, 4));
        centro.setOpaque(false);

        lblJogador = linha("Jogador da vez: —");
        lblPosicao = linha("Posição: —");
        lblProps   = linha("Propriedades: —");

        centro.add(lblJogador);
        centro.add(lblPosicao);
        centro.add(lblProps);
        add(centro, BorderLayout.CENTER);

        // Rodapé com botões
        JPanel rodape = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rodape.setOpaque(false);

        btnRolar = new JButton("Rolar Dados");
        btnEncerrar = new JButton("Encerrar Turno");

        // Rola os dados apenas se o GameManager indicar que é permitido
        btnRolar.addActionListener(e -> {
            if (game.podeRolarDados()) game.rolarDados();
            atualizarBotoes();
        });

        // Finaliza o turno e passa para o próximo jogador
        btnEncerrar.addActionListener(e -> {
            game.encerrarTurno();
            atualizarBotoes();
        });

        rodape.add(btnRolar);
        rodape.add(btnEncerrar);
        add(rodape, BorderLayout.SOUTH);

        // Primeira carga de dados de tela
        refresh();
        atualizarBotoes();
    }

    /**
     * Cria um JLabel básico para linha de informação textual.
     */
    private static JLabel linha(String txt) {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("SansSerif", Font.PLAIN, 12));
        return l;
    }

    /**
     * Atualiza os textos exibidos, sempre lendo diretamente do GameManager
     * (sem manter cache local de estado).
     */
    private void refresh() {
        String nome = game.getNomeJogadorDaVez();
        lblJogador.setText("Jogador da vez: " + nome);

        lblPosicao.setText("Posição: " + game.getPosicaoJogadorDaVez());
        lblProps.setText("Propriedades: " + game.getQtdPropriedadesJogadorDaVez());
    }

    /**
     * Liga e desliga os botões de acordo com o fluxo do turno
     * e com o fato do jogo já ter sido encerrado ou não.
     */
    private void atualizarBotoes() {
        boolean pode = game.podeRolarDados();
        boolean terminou = game.jogoEncerrado();
        btnRolar.setEnabled(pode && !terminou);
        btnEncerrar.setEnabled(!pode && !terminou);
    }

    /**
     * Chamado toda vez que o estado do jogo muda.
     * Atualiza textos e estado dos botões na Event Dispatch Thread.
     */
    @Override
    public void onGameStateChanged() {
        SwingUtilities.invokeLater(() -> {
            refresh();
            atualizarBotoes();
        });
    }
}
