package view;

import javax.swing.*;

import controller.GameListener;
import controller.GameManager;

import java.awt.*;

/**
 * Painel que exibe a carta atual do jogo.
 *
 * Mostra, nesta ordem de prioridade:
 * 1) Carta de Sorte/Revés ativa (se existir);
 * 2) Carta da propriedade onde o jogador da vez está parado;
 * 3) Mensagem "Sem carta", caso não haja nada para exibir.
 */
public class PainelCarta extends JPanel implements GameListener {

    private static final long serialVersionUID = 1L;

    /** Acesso ao estado do jogo. */
    private final GameManager game;

    /** Título da área: nome da carta ou da propriedade. */
    private final JLabel lblTitulo;
    /** Área central onde a imagem da carta é desenhada. */
    private final CartaView cartaView;

    /** Rodapé com informações da propriedade. */
    private final JPanel rodape;
    private final JLabel lblLinhaTipoDono;
    private final JLabel lblLinhaCustos;

    public PainelCarta() {
        super(new BorderLayout(6, 6));
        this.game = GameManager.getInstance();
        this.game.addGameListener(this);

        setOpaque(true);
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        setPreferredSize(new Dimension(300, 360));

        // Cabeçalho
        lblTitulo = new JLabel("Carta", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 14));
        add(lblTitulo, BorderLayout.NORTH);

        // Área central (desenho da carta via Java2D)
        cartaView = new CartaView();
        add(cartaView, BorderLayout.CENTER);

        // Rodapé textual (dados da propriedade)
        rodape = new JPanel(new GridLayout(2, 1, 0, 2));
        rodape.setOpaque(false);

        lblLinhaTipoDono = new JLabel(" ");
        lblLinhaCustos   = new JLabel(" ");
        lblLinhaTipoDono.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblLinhaCustos.setFont(new Font("SansSerif", Font.PLAIN, 12));

        rodape.add(lblLinhaTipoDono);
        rodape.add(lblLinhaCustos);
        add(rodape, BorderLayout.SOUTH);

        atualizarConteudo();
    }

    /**
     * Atualiza o conteúdo exibido, seguindo a ordem de prioridade:
     * Sorte/Revés > Propriedade > Sem carta.
     */
    private void atualizarConteudo() {
        // 1) Sorte/Revés tem prioridade
        if (game.temCartaSorteReves()) {
            lblTitulo.setText("Sorte / Revés");
            aplicarImagemSorteReves(game.getImagemCartaSorteRevesPath());
            rodape.setVisible(false);
            return;
        }

        // 2) Propriedade (terreno/companhia)
        if (game.isUltimaCasaPropriedade()) {
            final String nome = game.getUltimaCasaNome();
            lblTitulo.setText((nome != null && !nome.isEmpty()) ? nome : "Propriedade");

            GameManager.PropriedadeVM vm = game.getPropriedadeAtualVM();
            final boolean ehCompanhia = (vm != null && vm.companhia);

            final String caminhoImg = ehCompanhia
                    ? "imagem/companhias/" + nome + ".png"
                    : "imagem/territorios/" + nome + ".png";

            aplicarImagemPropriedade(caminhoImg);

            if (vm != null) {
                final String tipo = ehCompanhia ? "Companhia" : "Terreno";
                final String dono = (vm.donoNome == null ? "Banco" : vm.donoNome);
                lblLinhaTipoDono.setText("Tipo: " + tipo + "  |  Dono: " + dono);

                final String custoCompra = "Preço: R$ " + vm.preco;
                final String custoConstr = (vm.precoConstrucao > 0 ? " | Construção: R$ " + vm.precoConstrucao : "");
                final String construcoes = ehCompanhia ? "" : (" | Casas: " + vm.casas + (vm.hotel ? " (Hotel)" : ""));
                lblLinhaCustos.setText(custoCompra + custoConstr + construcoes);

                rodape.setVisible(true);
            } else {
                rodape.setVisible(false);
            }
            return;
        }

        // 3) Nada para mostrar
        lblTitulo.setText("Carta");
        cartaView.setConteudo(null, "Sem carta");
        rodape.setVisible(false);
    }

    /**
     * Carrega imagem de Sorte/Revés (se existir) e repassa para o componente de desenho.
     */
    private void aplicarImagemSorteReves(String caminho) {
        if (caminho == null) {
            cartaView.setConteudo(null, "Imagem não encontrada");
            return;
        }
        ImageIcon ic = new ImageIcon(caminho);
        if (ic.getIconWidth() <= 0 || ic.getIconHeight() <= 0) {
            cartaView.setConteudo(null, "Imagem não encontrada");
            return;
        }
        cartaView.setConteudo(ic.getImage(), null);
    }

    /**
     * Carrega imagem de propriedade (se existir) e repassa para o componente de desenho.
     */
    private void aplicarImagemPropriedade(String caminho) {
        if (caminho == null) {
            cartaView.setConteudo(null, "Imagem não encontrada");
            return;
        }
        ImageIcon ic = new ImageIcon(caminho);
        if (ic.getIconWidth() <= 0 || ic.getIconHeight() <= 0) {
            cartaView.setConteudo(null, "Imagem não encontrada");
            return;
        }
        cartaView.setConteudo(ic.getImage(), null);
    }

    @Override
    public void onGameStateChanged() {
        atualizarConteudo();
    }

    /**
     * Componente interno que desenha a carta.
     * Se houver imagem, desenha a imagem centralizada e escalada.
     * Caso contrário, mostra uma mensagem de texto.
     */
    private static class CartaView extends JComponent {

        private static final long serialVersionUID = 1L;

        private Image imagem;
        private String texto;

        CartaView() {
            setOpaque(false);
        }

        /**
         * Define a imagem e/ou texto a ser exibido na área central.
         *
         * @param img            imagem da carta (pode ser null)
         * @param textoFallback  mensagem a exibir quando não há imagem
         */
        void setConteudo(Image img, String textoFallback) {
            this.imagem = img;
            this.texto = textoFallback;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();
            try {
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                // Fundo simples para destacar a carta
                g2.setColor(new Color(245, 245, 245));
                g2.fillRoundRect(0, 0, w - 1, h - 1, 12, 12);
                g2.setColor(Color.LIGHT_GRAY);
                g2.drawRoundRect(0, 0, w - 1, h - 1, 12, 12);

                // Desenha imagem, se existir
                if (imagem != null) {
                    int imgW = imagem.getWidth(null);
                    int imgH = imagem.getHeight(null);
                    if (imgW > 0 && imgH > 0) {
                        int margem = 8;
                        int availW = w - 2 * margem;
                        int availH = h - 2 * margem;

                        double escala = Math.min(
                                (double) availW / imgW,
                                (double) availH / imgH
                        );
                        int drawW = (int) (imgW * escala);
                        int drawH = (int) (imgH * escala);

                        int x = (w - drawW) / 2;
                        int y = (h - drawH) / 2;
                        g2.drawImage(imagem, x, y, drawW, drawH, null);
                        return;
                    }
                }

                // Sem imagem: mostra texto centralizado
                String msg = (texto != null ? texto : "Sem carta");
                g2.setColor(Color.DARK_GRAY);
                g2.setFont(getFont().deriveFont(Font.PLAIN, 12f));
                FontMetrics fm = g2.getFontMetrics();
                int textW = fm.stringWidth(msg);
                int textH = fm.getAscent();
                int tx = (w - textW) / 2;
                int ty = (h + textH) / 2 - 4;
                g2.drawString(msg, tx, ty);

            } finally {
                g2.dispose();
            }
        }
    }
}
