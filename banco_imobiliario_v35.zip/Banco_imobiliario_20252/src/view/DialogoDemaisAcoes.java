package view;

import controller.GameManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Diálogo modal para ações extras do jogador da vez:
 * comprar ou construir na propriedade atual e vender propriedades próprias.
 */
public class DialogoDemaisAcoes extends JDialog {

    private final GameManager gm = GameManager.getInstance();

    // Propriedade atual (onde o jogador da vez está parado)
    private JLabel lblNome, lblDono, lblPreco, lblConstr;
    private JButton btnComprar, btnConstruir;

    // Lista de propriedades do jogador da vez (para venda)
    private JComboBox<String> comboPropriedades;
    private JButton btnVender;

    // Mensagem no rodapé (feedback simples)
    private JLabel lblMensagem;

    /**
     * Cria o diálogo modal de "Demais Ações" vinculado a uma janela pai.
     *
     * @param owner janela que será o dono do diálogo
     */
    public DialogoDemaisAcoes(Window owner) {
        super(owner, "Demais Ações", ModalityType.APPLICATION_MODAL);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        add(criarPainelPropriedadeAtual(), BorderLayout.NORTH);
        add(criarPainelMinhasPropriedades(), BorderLayout.CENTER);
        add(criarRodape(), BorderLayout.SOUTH);

        carregarDados();
        setSize(500, 260);
    }

    /**
     * Cria o painel superior com informações da propriedade atual
     * e botões de "Comprar" e "Construir".
     */
    private JPanel criarPainelPropriedadeAtual() {
        JPanel painel = new JPanel(new BorderLayout(4, 4));
        painel.setBorder(BorderFactory.createTitledBorder("Propriedade atual"));

        JPanel linhas = new JPanel(new GridLayout(4, 1));
        lblNome   = new JLabel("Nome: —");
        lblDono   = new JLabel("Dono: —");
        lblPreco  = new JLabel("Preço: —");
        lblConstr = new JLabel("Construções: —");
        linhas.add(lblNome);
        linhas.add(lblDono);
        linhas.add(lblPreco);
        linhas.add(lblConstr);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnComprar   = new JButton("Comprar");
        btnConstruir = new JButton("Construir");

        // Tenta comprar a propriedade atual
        btnComprar.addActionListener(e -> {
            lblMensagem.setText(" ");
            if (!gm.comprarPropriedadeAtual()) {
                Toolkit.getDefaultToolkit().beep();
                lblMensagem.setText("Não foi possível comprar.");
            }
            gm.refreshUI();
            carregarDados();
        });

        // Tenta construir na propriedade atual
        btnConstruir.addActionListener(e -> {
            lblMensagem.setText(" ");
            if (!gm.construirNaPropriedadeAtual()) {
                Toolkit.getDefaultToolkit().beep();
                lblMensagem.setText("Não é possível construir agora.");
            }
            gm.refreshUI();
            carregarDados();
        });

        botoes.add(btnComprar);
        botoes.add(btnConstruir);

        painel.add(linhas, BorderLayout.CENTER);
        painel.add(botoes, BorderLayout.SOUTH);
        return painel;
    }

    /**
     * Cria o painel central com a lista de propriedades do jogador da vez
     * e o botão para vender a selecionada.
     */
    private JPanel criarPainelMinhasPropriedades() {
        JPanel painel = new JPanel(new BorderLayout(4, 4));
        painel.setBorder(BorderFactory.createTitledBorder("Minhas propriedades"));

        JPanel linha = new JPanel(new BorderLayout(4, 4));
        linha.add(new JLabel("Selecione para vender:"), BorderLayout.WEST);

        comboPropriedades = new JComboBox<>();
        linha.add(comboPropriedades, BorderLayout.CENTER);

        btnVender = new JButton("Vender selecionada");
        // Tenta vender a propriedade escolhida no combo
        btnVender.addActionListener(e -> {
            lblMensagem.setText(" ");
            String nome = (String) comboPropriedades.getSelectedItem();
            if (nome == null || nome.equals("Nenhuma propriedade")) {
                Toolkit.getDefaultToolkit().beep();
                lblMensagem.setText("Nenhuma propriedade selecionada.");
                return;
            }
            if (!gm.venderPropriedade(nome)) {
                Toolkit.getDefaultToolkit().beep();
                lblMensagem.setText("Não foi possível vender.");
            }
            gm.refreshUI();
            carregarDados();
        });
        linha.add(btnVender, BorderLayout.EAST);

        painel.add(linha, BorderLayout.CENTER);
        return painel;
    }

    /**
     * Cria o rodapé com a mensagem de feedback e o botão "Fechar".
     */
    private JPanel criarRodape() {
        JPanel p = new JPanel(new BorderLayout(4, 4));

        lblMensagem = new JLabel(" ");
        p.add(lblMensagem, BorderLayout.CENTER);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton fechar = new JButton("Fechar");
        fechar.addActionListener(e -> dispose());
        botoes.add(fechar);

        p.add(botoes, BorderLayout.EAST);
        return p;
    }

    /**
     * Atualiza o conteúdo da tela com base no estado atual do GameManager:
     * - Dados da propriedade onde o jogador está.
     * - Lista de propriedades do jogador da vez.
     * - Habilita ou desabilita botões conforme o contexto.
     */
    private void carregarDados() {
        // Propriedade atual
        GameManager.PropriedadeVM vm = gm.getPropriedadeAtualVM();
        if (vm == null) {
            lblNome.setText("Nome: —");
            lblDono.setText("Dono: —");
            lblPreco.setText("Preço: —");
            lblConstr.setText("Construções: —");
            btnComprar.setEnabled(false);
            btnConstruir.setEnabled(false);
        } else {
            lblNome.setText("Nome: " + vm.nome);
            lblDono.setText("Dono: " + (vm.donoNome == null ? "Banco" : vm.donoNome));

            String preco = "Preço: R$ " + vm.preco;
            if (vm.companhia) {
                preco += " (companhia)";
                lblConstr.setText("Construções: — (companhia)");
            } else {
                preco += " | Construção: R$ " + vm.precoConstrucao;
                lblConstr.setText("Construções: casas=" + vm.casas + (vm.hotel ? " + hotel" : ""));
            }
            lblPreco.setText(preco);

            boolean podeComprar   = (vm.donoNome == null);
            boolean podeConstruir = !vm.companhia &&
                    vm.donoNome != null &&
                    vm.donoNome.equals(gm.getNomeJogadorDaVez());

            btnComprar.setEnabled(podeComprar);
            btnConstruir.setEnabled(podeConstruir);
        }

        // Minhas propriedades (jogador da vez)
        comboPropriedades.removeAllItems();
        List<GameManager.PropriedadeResumo> props = gm.getPropriedadesDoJogadorDaVezVM();
        for (GameManager.PropriedadeResumo ps : props) {
            comboPropriedades.addItem(ps.nome);
        }

        if (comboPropriedades.getItemCount() == 0) {
            comboPropriedades.addItem("Nenhuma propriedade");
            comboPropriedades.setEnabled(false);
            btnVender.setEnabled(false);
        } else {
            comboPropriedades.setEnabled(true);
            btnVender.setEnabled(true);
        }
    }
}
