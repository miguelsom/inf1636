package model;

/**
 * Centraliza as constantes de regra do jogo
 * (valores de dinheiro, prisão, falência, etc.).
 *
 * Classe utilitária: não deve ser instanciada.
 */
final class Regras {

    // ===== Economia =====

    /** Dinheiro inicial de cada jogador no início da partida. */
    static final int SALDO_INICIAL = 4000; //4000

    /** Valor recebido ao passar ou cair na casa de Partida. */
    static final int BONUS_PARTIDA = 200;

    // ===== Prisão =====

    /**
     * Número máximo de turnos tentando sair da prisão.
     * No 3º turno, o jogador paga a multa e é obrigado a sair.
     */
    static final int TURNOS_MAX_PRISAO = 3;

    /** Multa paga ao sair da prisão na 3ª tentativa. */
    static final int MULTA_SAIDA_PRISAO = 200;

    // ===== Falência =====

    /**
     * Saldo mínimo para o jogador continuar ativo no jogo.
     * Se o saldo for menor que este valor, o jogador é eliminado.
     */
    static final int VALOR_MINIMO_ATIVO = 1;

    /** Valor recebido na casa de lucros e dividendos. */
    public static final int LUCROS_DIVIDENDOS_VALOR = 200;

    /** Valor pago na casa de imposto de renda. */
    public static final int IMPOSTO_RENDA_VALOR = 200;

    /** Construtor privado para impedir criação de instâncias. */
    private Regras() { }
}
