package controller;

/**
 * Interface do "observado" no padrão Observer para o jogo.
 *
 * Qualquer classe que implementa GameObservable:
 * - Permite registrar {@link GameListener}s interessados em mudanças de estado.
 * - Fica responsável por chamar os listeners quando algo relevante acontecer
 *   (por exemplo, rolar dados, mudar de turno, comprar, vender, etc.).
 *
 * No projeto, o {@link GameManager} implementa esta interface.
 */
public interface GameObservable {

    /**
     * Registra um listener para ser notificado quando o estado do jogo mudar.
     *
     * @param l instância que implementa GameListener
     */
    void addGameListener(GameListener l);

    /**
     * Remove um listener previamente registrado.
     *
     * @param l listener que não deve mais receber notificações
     */
    void removeGameListener(GameListener l);
}
