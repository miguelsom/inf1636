package controller;

/**
 * Interface para objetos que querem ser avisados
 * sempre que o estado do jogo mudar.
 *
 * Usado pela camada de View:
 * o GameManager chama esse listener após cada ação
 * relevante (rolar dados, mover pinos, trocar jogador, etc.).
 */
public interface GameListener {

    /**
     * Método principal de notificação.
     * Chamado pelo GameManager quando o estado do jogo muda.
     *
     * Implementações novas podem sobrescrever apenas este método.
     */
    default void onGameStateChanged() {
        onStateChanged();
    }

    /**
     * Nome alternativo (legado) para o mesmo evento.
     * Mantido apenas por compatibilidade com versões antigas.
     *
     * Pode ser ignorado em códigos novos.
     */
    default void onStateChanged() {
        // implementação padrão vazia
    }
}
