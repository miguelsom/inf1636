package model;

import static org.junit.Assert.*;
import java.util.List;
import org.junit.*;

/**
 * Compra e Construção (1ª iteração)
 * - Compra debita e registra.
 * - Construção só em visita subsequente; não-dono/companhia não constroem.
 * - Compra falha sem saldo.
 * - 4 casas → hotel; após hotel, bloqueia.
 */
public class Iteracao1_CompraEConstrucaoTest {

    private ModelFacade facade;

    @Before
    public void setup() {
        facade = new ModelFacade();
        facade.reset();
        facade.adicionarJogador("A");
        facade.adicionarJogador("B");
    }

    // Funções Auxiliares
    private void moverAte(String nome) {
        int guard = 0;
        while (guard++ < 200) {
            ModelFacade.MovementResult mv = facade.deslocarJogadorDaVez(1);
            if (mv.getNomeEspaco().equalsIgnoreCase(nome)) break;
        }
    }
    private void endTurn()   { facade.finalizarTurno(); }
    private int saldoDaVez() { return facade.getJogadorDaVezSnapshot().getSaldo(); }

    @Test
    public void compraTerreno() {
        // Compra simples: debita 100 (Leblon) e adiciona ao inventário
        moverAte("Leblon");
        assertTrue(facade.comprarPropriedadeAtualDaVez());
        assertEquals(Regras.SALDO_INICIAL - 100, saldoDaVez());

        List<ModelFacade.PropriedadeSnapshot> props = facade.getPropriedadesDoJogadorDaVez();
        assertEquals(1, props.size());
        assertEquals("Leblon", props.get(0).getNome());
    }

    @Test
    public void construirRegrasBasicas() {
        // Construir só em visita subsequente (debita 50)
        moverAte("Leblon");
        assertTrue(facade.comprarPropriedadeAtualDaVez());
        endTurn(); endTurn(); moverAte("Leblon");
        int saldoAntes = saldoDaVez();
        assertTrue(facade.construirNaPropriedadeAtualDaVez());
        assertEquals(saldoAntes - 50, saldoDaVez());

        // Companhia não constrói
        endTurn(); endTurn(); moverAte("Companhia Ferroviária");
        assertFalse(facade.construirNaPropriedadeAtualDaVez());

        // Não-dono não constrói
        endTurn(); moverAte("Leblon");
        assertFalse(facade.construirNaPropriedadeAtualDaVez());
    }

    @Test
    public void naoCompraSeSaldoInsuficiente() {
        // Drena saldo com prisão (3ª tentativa paga multa) até ficar < 140; tenta comprar Av. Europa e falha
        final int PRECO_AV_EUROPA = 140;
        int guard = 0;
        while (facade.getJogadorDaVezSnapshot().getSaldo() >= PRECO_AV_EUROPA && guard++ < 200) {
            moverAte("VÁ PARA A PRISÃO");
            facade.processarCasaAtualDaVez();
            assertTrue(facade.getJogadorDaVezSnapshot().isPreso());
            assertFalse(facade.tentarSairDaPrisaoComDadosDaVez(1, 2));
            assertFalse(facade.tentarSairDaPrisaoComDadosDaVez(2, 3));
            assertTrue(facade.tentarSairDaPrisaoComDadosDaVez(3, 5));
            assertFalse(facade.getJogadorDaVezSnapshot().isPreso());
        }

        moverAte("Av. Europa");
        int saldoAntes = saldoDaVez();
        boolean comprou = facade.comprarPropriedadeAtualDaVez();
        assertFalse(comprou);
        assertEquals(saldoAntes, saldoDaVez());
    }

    @Test
    public void promoveHotel_e_bloqueiaDepois() {
        // 4 casas → hotel; depois não permite construir mais
        moverAte("Leblon");
        assertTrue(facade.comprarPropriedadeAtualDaVez());

        for (int i = 0; i < 4; i++) {
            endTurn(); endTurn(); moverAte("Leblon");
            assertTrue(facade.construirNaPropriedadeAtualDaVez());
        }

        endTurn(); endTurn(); moverAte("Leblon");
        assertTrue(facade.construirNaPropriedadeAtualDaVez()); // hotel

        endTurn(); endTurn(); moverAte("Leblon");
        assertFalse(facade.construirNaPropriedadeAtualDaVez());
    }
}
