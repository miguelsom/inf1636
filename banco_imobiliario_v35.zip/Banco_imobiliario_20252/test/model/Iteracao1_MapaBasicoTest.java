package model;

import static org.junit.Assert.*;
import org.junit.*;

/**
 * Mapa básico (1ª iteração):
 * - Alcance de "Sorte ou Revés" e posição válida (0..39).
 * - 40 passos retornam à mesma posição.
 * - "VÁ PARA A PRISÃO" é alcançável caminhando; MovementResult coerente.
 */
public class Iteracao1_MapaBasicoTest {

    private ModelFacade facade;

    @Before
    public void setup() {
        facade = new ModelFacade();
        facade.reset();
        facade.adicionarJogador("A");
        facade.adicionarJogador("B");
    }

    // Funções Auxiliares
    private void moverAte(String nome) {
        int guard = 0;
        while (guard++ < 200) {
            ModelFacade.MovementResult mv = facade.deslocarJogadorDaVez(1);
            if (mv.getNomeEspaco().equalsIgnoreCase(nome)) break;
        }
    }

    @Test
    public void mapaSanidadeBasica() {
        // Garante que a casa existe e a posição final está na faixa
        moverAte("Sorte ou Revés");
        int pos = facade.getJogadorDaVezSnapshot().getPosicao();
        assertTrue(pos >= 0 && pos < 40);
    }

    @Test
    public void cicloCompletoRetornaAMesmaPosicao() {
        // 40 passos devem voltar ao mesmo índice
        int pos0 = facade.getJogadorDaVezSnapshot().getPosicao();
        ModelFacade.MovementResult mv = facade.deslocarJogadorDaVez(40);
        int pos1 = facade.getJogadorDaVezSnapshot().getPosicao();

        assertEquals(pos0, pos1);
        assertEquals(pos1, mv.getNovaPosicao());
    }

    @Test
    public void casasChaveExistem_semNomeDiretoNoSnapshot() {
        // Começa na Partida (posição 0)
        assertEquals(0, facade.getJogadorDaVezSnapshot().getPosicao());

        // Caminha até encontrar 'VÁ PARA A PRISÃO' e checa coerência de posição
        int guard = 0;
        while (guard++ < 60) {
            ModelFacade.MovementResult mv = facade.deslocarJogadorDaVez(1);
            if ("VÁ PARA A PRISÃO".equalsIgnoreCase(mv.getNomeEspaco())) {
                assertEquals(mv.getNovaPosicao(), facade.getJogadorDaVezSnapshot().getPosicao());
                return;
            }
        }
        fail("Não foi possível alcançar 'VÁ PARA A PRISÃO' em 60 passos");
    }
}
