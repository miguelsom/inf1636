package controller;

/**
 * Listener para mudanças no estado do jogo.
 *
 * Racional:
 * - Views/painéis podem implementar este listener para serem notificados
 *   sempre que o estado do jogo for alterado (rolagem, movimento, troca de vez,
 *   cartas exibidas, etc).
 * - Para evitar incompatibilidades de nomenclatura entre versões,
 *   expomos dois nomes equivalentes:
 *     - onGameStateChanged()
 *     - onStateChanged()
 *   Ambos têm a mesma semântica; sobrescreva qualquer um deles.
 */
public interface GameListener {

    /**
     * Disparado quando o estado do jogo muda.
     * Implementação default delega para onStateChanged() para manter
     * compatibilidade com implementações antigas.
     */
    default void onGameStateChanged() {
        onStateChanged();
    }

    /**
     * Pode ser sobrescrito por Views que já adotavam este nome.
     * Implementação padrão é vazia.
     */
    default void onStateChanged() {
        // implementação default intencionalmente vazia
    }
}
