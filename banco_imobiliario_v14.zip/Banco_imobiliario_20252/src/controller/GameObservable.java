package controller;

/**
 * Interface do "observado" no padrão Observer.
 * Quem implementa esta interface permite o registro de GameListeners
 * interessados em mudanças de estado do jogo.
 */
public interface GameObservable {

    void addGameListener(GameListener l);

    void removeGameListener(GameListener l);
}
