package model;

import java.util.List;

/**
 * Representa uma carta de Sorte/Revés e seu efeito de jogo.
 * Cada carta tem um id (1..30) compatível com as imagens "chance<id>.png".
 */
class CartaSorteReves {

    public enum Tipo { SORTE, REVES }

    /** Tipo genérico de efeito. Mantemos simples e cobremos 100% das cartas enviadas. */
    public enum Efeito {
        RECEBER,            // Receba X
        PAGAR,              // Pague X
        RECEBER_DE_CADA,    // Receba X de cada jogador
        IR_PARA_PRISAO,     // Vá para a prisão
        AVANCAR_PARTIDA,    // Vá ao ponto de partida e receba bônus de partida
        CARTA_SAIDA_LIVRE   // Ganhe "Saída Livre da Prisão"
    }

    private final int id;          // 1..30 (para casar com a imagem)
    private final Tipo tipo;
    private final Efeito efeito;
    private final int valor;       // usado por RECEBER/PAGAR/RECEBER_DE_CADA
    private final String descricaoCurta; // opcional, para logs/debug

    public CartaSorteReves(int id, Tipo tipo, Efeito efeito, int valor, String descricaoCurta) {
        this.id = id;
        this.tipo = tipo;
        this.efeito = efeito;
        this.valor = valor;
        this.descricaoCurta = descricaoCurta;
    }

    public int getId() { return id; }
    public Tipo getTipo() { return tipo; }
    public Efeito getEfeito() { return efeito; }
    public int getValor() { return valor; }
    public String getDescricaoCurta() { return descricaoCurta; }

    /** Caminho da imagem compatível com o seu projeto. */
    public String getImagemPath() {
        return "imagem/sorteReves/chance" + id + ".png";
    }

    /**
     * Aplica o efeito da carta ao jogador atual e, se necessário, aos demais.
     * Regras baseadas nas cartas enviadas por você.
     */
    public void aplicar(Jogador atual, List<Jogador> todos, Tabuleiro tabuleiro) {
        switch (efeito) {
            case RECEBER:
                atual.creditar(valor);
                break;

            case PAGAR:
                atual.debitar(valor);
                break;

            case RECEBER_DE_CADA:
                for (Jogador j : todos) {
                    if (j != atual && j.estaAtivo()) {
                        j.debitar(valor);
                        atual.creditar(valor);
                    }
                }
                break;

            case IR_PARA_PRISAO:
                atual.enviarParaPrisao(tabuleiro.getIndicePrisao());
                break;

            case AVANCAR_PARTIDA:
                // Vai para a partida e ganha o bônus (sem “dar a volta”; é efeito direto).
                int partida = tabuleiro.getIndicePartida();
                atual.setPosicao(partida);
                atual.creditar(Regras.BONUS_PARTIDA);
                break;

            case CARTA_SAIDA_LIVRE:
                atual.ganharCartaSaidaLivre();
                break;
        }
    }
}
