package view;

import javax.swing.*;
import java.awt.*;

import controller.GameListener;
import controller.GameManager;

/**
 * Janela principal em tela única.
 *
 * Layout (BorderLayout):
 * - CENTER: Tabuleiro
 * - WEST:   Coluna com (botão salvar, Carta em cima, Dados embaixo)
 * - SOUTH:  PainelLog
 *
 * Sem acesso ao Model: tudo via GameManager.
 */
public class JanelaUnica extends JFrame {

    private static final long serialVersionUID = 1L;

    private final GameManager game = GameManager.getInstance();
    private boolean endDialogShown = false; // evita abrir múltiplas vezes

    /**
     * Configura a barra de menu com a opção de salvar o jogo.
     */
    private void configurarMenuSalvar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menuJogo = new JMenu("Jogo");
        JMenuItem itemSalvar = new JMenuItem("Salvar jogo...");
        itemSalvar.addActionListener(e -> onSalvarJogo());
        menuJogo.add(itemSalvar);
        menuBar.add(menuJogo);
        setJMenuBar(menuBar);
    }

    /**
     * Handler do item de menu / botão "Salvar jogo...".
     * Abre um JFileChooser e delega o salvamento ao GameManager.
     */
    private void onSalvarJogo() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Salvar jogo em arquivo (.txt)");
        int result = chooser.showSaveDialog(this);
        if (result != JFileChooser.APPROVE_OPTION) {
            return;
        }

        java.io.File file = chooser.getSelectedFile();
        if (file == null) {
            return;
        }

        String path = file.getAbsolutePath();
        if (!path.toLowerCase().endsWith(".txt")) {
            path = path + ".txt";
            file = new java.io.File(path);
        }

        boolean ok = game.salvarJogoEmArquivo(path);
        if (!ok) {
            JOptionPane.showMessageDialog(
                    this,
                    "Não foi possível salvar o jogo.",
                    "Erro ao salvar",
                    JOptionPane.ERROR_MESSAGE
            );
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Jogo salvo em:\n" + path,
                    "Jogo salvo",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    public JanelaUnica() {
        super("Banco Imobiliário — Iteração 2");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));
        getContentPane().setBackground(Color.WHITE);
        configurarMenuSalvar();

        // ====== CENTER: Tabuleiro ======
        PainelTabuleiro painelTabuleiro = new PainelTabuleiro();
        painelTabuleiro.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        add(painelTabuleiro, BorderLayout.CENTER);

        // ====== WEST: Coluna (botão salvar, Carta em cima, Dados embaixo) ======
        JPanel colunaEsquerda = new JPanel(new BorderLayout(6, 6));
        colunaEsquerda.setOpaque(false);
        colunaEsquerda.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));

        // Topo da coluna: botão de salvar partida
        JPanel painelTopoEsquerdo = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        JButton botaoSalvar = new JButton("Salvar partida");
        botaoSalvar.addActionListener(e -> onSalvarJogo());
        painelTopoEsquerdo.add(botaoSalvar);
        colunaEsquerda.add(painelTopoEsquerdo, BorderLayout.NORTH);

        // Centro: carta
        PainelCarta painelCarta = new PainelCarta();
        colunaEsquerda.add(painelCarta, BorderLayout.CENTER);

        // Baixo: dados
        PainelDados painelDados = new PainelDados();
        colunaEsquerda.add(painelDados, BorderLayout.SOUTH);

        colunaEsquerda.setPreferredSize(new Dimension(300, 600));
        add(colunaEsquerda, BorderLayout.WEST);

        // ====== SOUTH: LOG da rodada ======
        PainelLog painelLog = new PainelLog();
        painelLog.setPreferredSize(new Dimension(200, 140));
        add(painelLog, BorderLayout.SOUTH);

        // Listener global de mudanças de estado de jogo
        game.addGameListener(new GameListener() {
            @Override
            public void onGameStateChanged() {
                // Os painéis já se atualizam sozinhos como GameListener,
                // aqui só garantimos um repaint geral e tratamos fim de jogo.
                repaint();

                if (!endDialogShown && game.jogoEncerrado()) {
                    endDialogShown = true;
                    SwingUtilities.invokeLater(() -> {
                        EndGameDialog dlg = new EndGameDialog(
                                JanelaUnica.this,
                                game.getRankingPorSaldo()
                        );
                        dlg.setVisible(true);
                    });
                }
            }
        });

        setSize(1200, 820); // um pouco mais alto para caber o log
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JanelaUnica janela = new JanelaUnica();
            janela.setVisible(true);
        });
    }
}
