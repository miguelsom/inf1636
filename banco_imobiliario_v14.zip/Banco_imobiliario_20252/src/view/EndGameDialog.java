package view;

import controller.GameManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/** Dialog simples exibindo ranking final por saldo com auto-encerramento silencioso. */
public class EndGameDialog extends JDialog {

    private final Timer autoKillTimer;

    public EndGameDialog(Window owner, List<GameManager.RankingItem> ranking) {
        super(owner, "Jogo Encerrado", ModalityType.APPLICATION_MODAL);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(10,10));
        root.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));

        JLabel titulo = new JLabel("Resultado Final", SwingConstants.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 16));
        root.add(titulo, BorderLayout.NORTH);

        String[] cols = {"Posição", "Jogador", "Saldo (R$)"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        int pos = 1;
        for (GameManager.RankingItem it : ranking) {
            model.addRow(new Object[]{pos + "º", it.nome, it.saldo});
            pos++;
        }

        JTable table = new JTable(model);
        table.setRowHeight(24);
        table.setFont(new Font("SansSerif", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));

        root.add(new JScrollPane(table), BorderLayout.CENTER);

        JButton fechar = new JButton("Fechar");
        fechar.addActionListener(e -> dispose());

        JPanel sul = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        sul.add(fechar);
        root.add(sul, BorderLayout.SOUTH);

        setContentPane(root);
        setSize(420, 360);
        setLocationRelativeTo(owner);

        // Auto-kill silencioso em 10 segundos (não repete e independe de fechar o diálogo)
        autoKillTimer = new Timer(10_000, e -> {
            try { ((Timer) e.getSource()).stop(); } catch (Exception ignored) {}
            System.exit(0);
        });
        autoKillTimer.setRepeats(false);
        autoKillTimer.start();
    }
}
