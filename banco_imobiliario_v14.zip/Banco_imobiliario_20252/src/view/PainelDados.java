package view;

import controller.GameListener;
import controller.GameManager;

import javax.swing.*;
import java.awt.*;

/**
 * Painel dos Dados.
 *
 * Mostra:
 * - Dois dados desenhados via Java2D.
 * - Botões: Rolar, Demais ações, Encerrar turno, Encerrar partida.
 * - Atalho 'T' para testar dados (definir manualmente 1..6).
 */
public class PainelDados extends JPanel implements GameListener {

    private static final long serialVersionUID = 1L;

    private final GameManager game = GameManager.getInstance();

    private final DadoView dado1View;
    private final DadoView dado2View;

    private final JButton btnRolar;
    private final JButton btnDemaisAcoes;
    private final JButton btnEncerrarTurno;
    private final JButton btnEncerrarPartida;
    private final JLabel  lblInfo;

    public PainelDados() {
        setOpaque(false);
        setLayout(new BorderLayout(4, 4));
        setPreferredSize(new Dimension(280, 190));

        // ====== CENTRO: dados ======
        JPanel painelDados = new JPanel(new GridLayout(1, 2, 6, 6));
        painelDados.setOpaque(false);

        dado1View = new DadoView();
        dado2View = new DadoView();
        painelDados.add(dado1View);
        painelDados.add(dado2View);

        add(painelDados, BorderLayout.CENTER);

        // ====== SUL: botões + info ======
        JPanel painelSul = new JPanel(new BorderLayout(4, 4));
        painelSul.setOpaque(false);

        // grade 2x2 pros botões (mais simples e ocupa pouco espaço)
        JPanel painelBotoes = new JPanel(new GridLayout(2, 2, 4, 4));
        painelBotoes.setOpaque(false);

        btnRolar = new JButton("Rolar dados");
        btnRolar.addActionListener(e -> game.rolarDados());
        painelBotoes.add(btnRolar);

        btnDemaisAcoes = new JButton("Demais ações");
        btnDemaisAcoes.addActionListener(e -> abrirDialogoDemaisAcoes());
        painelBotoes.add(btnDemaisAcoes);

        btnEncerrarTurno = new JButton("Encerrar turno");
        btnEncerrarTurno.addActionListener(e -> game.encerrarTurno());
        painelBotoes.add(btnEncerrarTurno);

        btnEncerrarPartida = new JButton("Encerrar partida");
        btnEncerrarPartida.addActionListener(e -> confirmarEncerrarPartida());
        painelBotoes.add(btnEncerrarPartida);

        painelSul.add(painelBotoes, BorderLayout.CENTER);

        lblInfo = new JLabel("Use 'T' para testar dados (1..6).");
        painelSul.add(lblInfo, BorderLayout.SOUTH);

        add(painelSul, BorderLayout.SOUTH);

        // ====== Atalho 'T' ======
        registrarAtalhoTeste();

        // ====== Observer ======
        game.addGameListener(this);
        atualizarDosDados();
    }

    // ---------------------- Demais ações ----------------------
    private void abrirDialogoDemaisAcoes() {
        Window parent = SwingUtilities.getWindowAncestor(this);
        DialogoDemaisAcoes dlg = new DialogoDemaisAcoes(parent);
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }

    // ---------------------- Encerrar partida ----------------------
    private void confirmarEncerrarPartida() {
        Window parent = SwingUtilities.getWindowAncestor(this);
        Component comp = (parent instanceof Component) ? (Component) parent : this;

        int op = JOptionPane.showConfirmDialog(
                comp,
                "Tem certeza que deseja encerrar a partida agora?",
                "Encerrar partida",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );
        if (op == JOptionPane.YES_OPTION) {
            game.encerrarJogoAgora();
        }
    }

    // ---------------------- Atalho 'T' (teste de dados) ----------------------
    private void registrarAtalhoTeste() {
        InputMap im = getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = getActionMap();

        im.put(KeyStroke.getKeyStroke('T'), "testeDados");
        im.put(KeyStroke.getKeyStroke('t'), "testeDados");

        am.put("testeDados", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                abrirDialogoTesteDados();
            }
        });
    }

    private void abrirDialogoTesteDados() {
        Window parent = SwingUtilities.getWindowAncestor(this);

        JDialog dlg;
        if (parent instanceof Frame) {
            dlg = new JDialog((Frame) parent, "Teste de dados", true);
        } else if (parent instanceof Dialog) {
            dlg = new JDialog((Dialog) parent, "Teste de dados", true);
        } else {
            dlg = new JDialog((Frame) null, "Teste de dados", true);
        }

        dlg.setLayout(new BorderLayout(8, 8));

        JPanel centro = new JPanel(new GridLayout(2, 2, 6, 6));
        centro.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        centro.add(new JLabel("Dado 1:", SwingConstants.RIGHT));
        JComboBox<Integer> combo1 = new JComboBox<>();
        centro.add(combo1);

        centro.add(new JLabel("Dado 2:", SwingConstants.RIGHT));
        JComboBox<Integer> combo2 = new JComboBox<>();
        centro.add(combo2);

        for (int i = 1; i <= 6; i++) {
            combo1.addItem(i);
            combo2.addItem(i);
        }

        dlg.add(centro, BorderLayout.CENTER);

        JPanel sul = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 4));
        JButton btnAplicar = new JButton("Aplicar");
        JButton btnCancelar = new JButton("Cancelar");
        sul.add(btnCancelar);
        sul.add(btnAplicar);
        dlg.add(sul, BorderLayout.SOUTH);

        btnCancelar.addActionListener(e -> dlg.dispose());
        btnAplicar.addActionListener(e -> {
            Integer v1 = (Integer) combo1.getSelectedItem();
            Integer v2 = (Integer) combo2.getSelectedItem();
            if (v1 != null && v2 != null) {
                game.rolarDadosForcado(v1, v2);
            }
            dlg.dispose();
        });

        dlg.pack();
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }

    // ---------------------- GameListener ----------------------
    @Override
    public void onGameStateChanged() {
        atualizarDosDados();
    }

    private void atualizarDosDados() {
        int[] ult = game.getUltimoLancamento();
        if (ult != null && ult.length == 2) {
            dado1View.setValor(ult[0]);
            dado2View.setValor(ult[1]);
        } else {
            dado1View.setValor(0);
            dado2View.setValor(0);
        }

        if (game.podeRolarDados()) {
            lblInfo.setText("Pode rolar os dados. Use 'T' para teste.");
            btnRolar.setEnabled(true);
        } else {
            lblInfo.setText("Aguardando ações / próximo turno. Use 'T' para teste.");
            btnRolar.setEnabled(false);
        }

        repaint();
    }

    // ---------------------- DadoView (Java2D) ----------------------
    private static class DadoView extends JComponent {

        private static final long serialVersionUID = 1L;

        private static final String PATH_BASE = "imagem/dados/die_face_";
        private static final String EXT       = ".png";

        private final Image[] faces = new Image[7]; // 1..6
        private int valor = 0; // 0 = nenhum

        public DadoView() {
            setPreferredSize(new Dimension(60, 60));
            setOpaque(false);
            carregarImagens();
        }

        private void carregarImagens() {
            for (int i = 1; i <= 6; i++) {
                try {
                    ImageIcon ic = new ImageIcon(PATH_BASE + i + EXT);
                    faces[i] = ic.getImage();
                } catch (Exception e) {
                    e.printStackTrace();
                    faces[i] = null;
                }
            }
        }

        public void setValor(int v) {
            if (v < 1 || v > 6) {
                this.valor = 0;
            } else {
                this.valor = v;
            }
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();
            try {
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                // Fundo do dado
                g2.setColor(new Color(250, 250, 250));
                g2.fillRoundRect(2, 2, w - 4, h - 4, 12, 12);
                g2.setColor(Color.GRAY);
                g2.drawRoundRect(2, 2, w - 4, h - 4, 12, 12);

                if (valor >= 1 && valor <= 6 && faces[valor] != null) {
                    Image img = faces[valor];
                    int imgW = img.getWidth(null);
                    int imgH = img.getHeight(null);
                    if (imgW > 0 && imgH > 0) {
                        int availW = w - 10;
                        int availH = h - 10;
                        double scale = Math.min(
                                (double) availW / imgW,
                                (double) availH / imgH
                        );
                        int drawW = (int) (imgW * scale);
                        int drawH = (int) (imgH * scale);
                        int x = 2 + (w - 4 - drawW) / 2;
                        int y = 2 + (h - 4 - drawH) / 2;
                        g2.drawImage(img, x, y, drawW, drawH, null);
                    }
                } else {
                    g2.setColor(Color.DARK_GRAY);
                    g2.setFont(getFont().deriveFont(Font.BOLD, 14f));
                    String s = "-";
                    FontMetrics fm = g2.getFontMetrics();
                    int textW = fm.stringWidth(s);
                    int textH = fm.getAscent();
                    int x = (w - textW) / 2;
                    int y = (h + textH) / 2 - 3;
                    g2.drawString(s, x, y);
                }

            } finally {
                g2.dispose();
            }
        }
    }
}
