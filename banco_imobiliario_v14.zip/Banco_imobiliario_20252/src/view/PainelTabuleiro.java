package view;

import javax.swing.*;

import controller.GameListener;
import controller.GameManager;

import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Painel do Tabuleiro.
 *
 * Lógica geral:
 * - O tabuleiro (PNG) é desenhado mantendo a proporção (sem distorção).
 * - As 40 casas são mapeadas por um modelo determinístico "start + step":
 *   partimos do centro de cada canto e avançamos por passos médios (X/Y)
 *   ao longo de cada lado. Isso evita mapear casa por casa manualmente.
 * - Os pinos são sempre carregados para os 6 ids (pin0..pin5) e o desenho
 *   usa o pinId real do jogador (fornecido pelo GameManager).
 * - Movimento é animado "casa a casa" para dar feedback visual do percurso.
 * - Quando dois pinos caem na mesma casa, aplicamos um deslocamento sutil
 *   de 1px por jogador para evitar sobreposição perfeita.
 *
 * Convenção de índices no tabuleiro (0..39):
 *   0  = canto INF direito (Partida)
 *   1  ..  9  = base (direita → esquerda)
 *   10 = canto INF esquerdo
 *   11 .. 19  = esquerda (baixo → cima)
 *   20 = canto SUP esquerdo
 *   21 .. 29  = topo (esquerda → direita)
 *   30 = canto SUP direito
 *   31 .. 39  = direita (cima → baixo)
 */
public class PainelTabuleiro extends JPanel implements GameListener {

    private static final long serialVersionUID = 1L;

    // Referência de proporção da arte (não precisa ser o tamanho real do arquivo)
    private static final int ORIG_W = 700, ORIG_H = 700;

    // Parâmetros do mapeamento "start + step" (em px da arte original)
    // Ideia: a partir do centro de cada canto, avançamos por passos médios ao longo do lado.
    private static final int OFF_RIGHT_PX  = 80;
    private static final int OFF_BOTTOM_PX = 80;
    private static final int OFF_LEFT_PX   = 80;
    private static final int OFF_TOP_PX    = 80;
    private static final int STEP_X_PX     = 56; // passo médio horizontal (base/topo)
    private static final int STEP_Y_PX     = 56; // passo médio vertical (esquerda/direita)

    // Desenho dos pinos
    private static final int PIN_W = 28, PIN_H = 28, PIN_OFFSET_Y = 28;

    // Facade p/ estado do jogo (somente via GameManager)
    private final GameManager gm = GameManager.getInstance();

    // Imagem do tabuleiro (mantemos ImageIcon p/ dimensões estáveis)
    private final ImageIcon iconTabuleiro = new ImageIcon("imagem/tabuleiro.png");
    private final Image imgTabuleiro = iconTabuleiro.getImage();

    // Cache de pinos indexados por pinId 0..5 (sempre 6 imagens)
    private final List<Image> imagensPinoPorId = new ArrayList<>(6);

    // Estado para animação
    private int[] ultimasPosicoes;    // snapshot da última posição conhecida de cada jogador
    private boolean animando = false; // indica se há uma animação em curso
    private int idxJogAnim = -1;      // índice do jogador animando
    private int casaAtualAnim = 0;    // casa que está sendo desenhada nesta "frame"
    private int destinoAnim = 0;      // casa final da animação
    private Timer timer;

    // Área real desenhada do tabuleiro + centros calculados das 40 casas
    private Rectangle areaDesenho = new Rectangle();
    private final Point[] centrosCasas = new Point[40];

    /** Constrói o painel e registra o listener de resize para recalcular centros. */
    public PainelTabuleiro() {
        gm.addGameListener(this);
        setDoubleBuffered(true);
        setOpaque(true);
        setBackground(new Color(235, 235, 235));

        // Recalcula os centros quando a área útil muda (resize, maximizar, etc.)
        addComponentListener(new ComponentAdapter() {
            @Override public void componentResized(ComponentEvent e) {
                recalcularCentrosCasas();
                repaint();
            }
        });
    }

    // ============================================================
    // Desenho principal
    // ============================================================

    /**
     * Desenha o tabuleiro proporcionalmente e, por cima, os pinos de cada jogador.
     *
     * Lógica:
     * - Primeiro desenhamos a imagem escalonada "com aspecto preservado".
     * - Se a área de desenho mudou, recalculamos os centros das casas (uma vez).
     * - Para cada jogador, desenhamos o pino na posição atual (ou na "casa" da animação),
     *   com um pequeno deslocamento fixo de 1px para evitar sobreposição total.
     *
     * @param g contexto gráfico fornecido pelo Swing.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        final Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Rectangle novaArea = desenharTabuleiroMantendoProporcao(g2, imgTabuleiro, iconTabuleiro, getWidth(), getHeight());
        if (!novaArea.equals(areaDesenho)) {
            areaDesenho = novaArea;
            recalcularCentrosCasas();
        }

        final int n = gm.getNumeroJogadores();
        carregarPinosSeNecessario();     // garante pin0..pin5 carregados
        sincronizarUltimasPosicoes(n);   // sincroniza cache de posições

        for (int i = 0; i < n; i++) {
            int pos = (animando && i == idxJogAnim) ? casaAtualAnim : ultimasPosicoes[i];
            int idx = ((pos % 40) + 40) % 40;
            Point centro = centrosCasas[idx];

            // pinId real do jogador (não confundir com índice do laço)
            int pinId = gm.getPinIdDoJogador(i) % 6;
            Image imgPin = imagemDoPino(pinId);

            // deslocamento sutil de 1px (determinístico por jogador)
            Point off = deslocamentoSutilPorJogador(i);
            int x = centro.x + off.x - PIN_W / 2;
            int y = centro.y + off.y - PIN_OFFSET_Y;

            if (imgPin != null) {
                g2.drawImage(imgPin, x, y, PIN_W, PIN_H, this);
            }
        }
    }

    // ============================================================
    // Geometria: calcular centros das 40 casas (modelo "start + step")
    // ============================================================

    /**
     * Recalcula, uma única vez por mudança de área, os centros inteiros das 40 casas.
     *
     * Lógica:
     * - Calculamos a escala única (min dos eixos) e centralizamos a arte na tela.
     * - Definimos quatro pontos de referência (centros dos cantos), aplicando
     *   deslocamentos médios (OFF_*) já escalonados.
     * - A partir desses centros, avançamos por passos médios (STEP_*) ao longo dos lados.
     * - O resultado é determinístico e independe do histórico de jogadas.
     */
    private void recalcularCentrosCasas() {
        if (areaDesenho.width <= 0 || areaDesenho.height <= 0) return;

        double s = Math.min(areaDesenho.width / (double) ORIG_W,
                            areaDesenho.height / (double) ORIG_H);

        int drawW = (int) Math.round(ORIG_W * s);
        int drawH = (int) Math.round(ORIG_H * s);
        int drawX = areaDesenho.x + (areaDesenho.width  - drawW) / 2;
        int drawY = areaDesenho.y + (areaDesenho.height - drawH) / 2;

        double offR = OFF_RIGHT_PX  * s;
        double offB = OFF_BOTTOM_PX * s;
        double offL = OFF_LEFT_PX   * s;
        double offT = OFF_TOP_PX    * s;
        double stepX = STEP_X_PX    * s;
        double stepY = STEP_Y_PX    * s;

        double right  = drawX + drawW;
        double bottom = drawY + drawH;
        double left   = drawX;
        double top    = drawY;

        // centros dos 4 cantos
        double cxBR = right  - offR, cyBR = bottom - offB; // 0
        double cxBL = left   + offL, cyBL = bottom - offB; // 10
        double cxTL = left   + offL, cyTL = top    + offT; // 20
        double cxTR = right  - offR, cyTR = top    + offT; // 30

        centrosCasas[0] = ponto(cxBR, cyBR);
        for (int i = 1; i <= 9; i++) {
            centrosCasas[i] = ponto((right - offR - (i * stepX)), cyBR); // base (dir→esq)
        }
        centrosCasas[10] = ponto(cxBL, cyBL);
        for (int i = 1; i <= 9; i++) {
            centrosCasas[10 + i] = ponto(cxBL, (bottom - offB - (i * stepY))); // esquerda (baixo→cima)
        }
        centrosCasas[20] = ponto(cxTL, cyTL);
        for (int i = 1; i <= 9; i++) {
            centrosCasas[20 + i] = ponto((left + offL + (i * stepX)), cyTL); // topo (esq→dir)
        }
        centrosCasas[30] = ponto(cxTR, cyTR);
        for (int i = 1; i <= 9; i++) {
            centrosCasas[30 + i] = ponto(cxTR, (top + offT + (i * stepY))); // direita (cima→baixo)
        }
    }

    /** Converte coordenadas double para {@link Point} com arredondamento consistente. */
    private static Point ponto(double x, double y) {
        return new Point((int) Math.round(x), (int) Math.round(y));
    }

    // ============================================================
    // Utilitário: desenhar imagem mantendo proporção (sem esticar)
    // ============================================================

    /**
     * Desenha a imagem proporcionalmente (aspect ratio preservado) e retorna
     * o retângulo efetivamente ocupado por ela no painel.
     *
     * Racional:
     * - Usamos {@code ImageIcon} para obter dimensões válidas imediatamente.
     * - Escolhemos a menor escala entre largura/altura do painel vs. da imagem.
     * - Centralizamos o resultado e desenhamos com {@code Graphics2D#drawImage}.
     *
     * @param g2      contexto gráfico 2D
     * @param img     imagem a ser desenhada
     * @param icon    icon auxiliar para dimensões estáveis (pode ser {@code null})
     * @param panelW  largura disponível do painel
     * @param panelH  altura disponível do painel
     * @return retângulo (x,y,w,h) ocupado pela imagem já escalonada e centralizada
     */
    private static Rectangle desenharTabuleiroMantendoProporcao(Graphics2D g2,
                                                                Image img,
                                                                ImageIcon icon,
                                                                int panelW,
                                                                int panelH) {
        int iw = (icon != null ? icon.getIconWidth() : -1);
        int ih = (icon != null ? icon.getIconHeight() : -1);
        if (iw <= 0 || ih <= 0) { iw = img.getWidth(null); ih = img.getHeight(null); }
        if (iw <= 0 || ih <= 0) return new Rectangle(0, 0, panelW, panelH);

        double s = Math.min(panelW / (double) iw, panelH / (double) ih);
        int w = (int) Math.round(iw * s);
        int h = (int) Math.round(ih * s);
        int x = (panelW - w) / 2;
        int y = (panelH - h) / 2;

        g2.drawImage(img, x, y, w, h, null);
        return new Rectangle(x, y, w, h);
    }

    // ============================================================
    // Listener / Animação
    // ============================================================

    /**
     * Reage a mudanças de estado do jogo:
     * identifica qual jogador mudou de casa, inicia (ou finaliza) a animação
     * e redesenha o painel.
     */
    @Override
    public void onGameStateChanged() {
        int n = gm.getNumeroJogadores();
        carregarPinosSeNecessario();
        sincronizarUltimasPosicoes(n);

        int idx = -1, de = -1, para = -1;
        for (int i = 0; i < n; i++) {
            int p = gm.getPosicaoDoJogadorPorIndice(i);
            if (p != ultimasPosicoes[i]) { idx = i; de = ultimasPosicoes[i]; para = p; break; }
        }
        if (idx == -1) { repaint(); return; } // nenhuma mudança

        iniciarAnimacao(idx, de, para);
    }

    /**
     * Inicia a animação casa-a-casa do jogador indicado.
     *
     * Racional:
     * - A animação avança 1 casa por "tick" (Timer Swing) até alcançar o destino.
     * - Ao finalizar, consolida a posição do jogador e força um repaint final.
     *
     * @param idxJogador índice do jogador a ser animado (0..n-1)
     * @param origem     casa de partida
     * @param destino    casa final após o movimento
     */
    private void iniciarAnimacao(int idxJogador, int origem, int destino) {
        if (timer != null && timer.isRunning()) timer.stop();
        idxJogAnim = idxJogador;
        casaAtualAnim = origem;
        destinoAnim = destino;
        animando = true;

        timer = new Timer(90, e -> {
            if (casaAtualAnim == destinoAnim) {
                ultimasPosicoes[idxJogAnim] = destinoAnim;
                animando = false;
                ((Timer) e.getSource()).stop();
                repaint();
                return;
            }
            casaAtualAnim = (casaAtualAnim + 1) % 40;
            repaint();
        });
        timer.start();
    }

    // ============================================================
    // Pinos / Estado auxiliar
    // ============================================================

    /**
     * Garante que as 6 imagens de pinos (pin0..pin5) estejam carregadas e
     * dimensionadas para o desenho. Evita I/O em tempo de pintura.
     */
    private void carregarPinosSeNecessario() {
        if (!imagensPinoPorId.isEmpty()) return;
        for (int pinId = 0; pinId < 6; pinId++) {
            ImageIcon ic = new ImageIcon("imagem/pinos/pin" + pinId + ".png");
            Image pin = (ic.getIconWidth() > 0 ? ic.getImage() : new ImageIcon("imagem/pino_default.png").getImage());
            pin = pin.getScaledInstance(PIN_W, PIN_H, Image.SCALE_SMOOTH);
            imagensPinoPorId.add(pin);
        }
    }

    /**
     * Retorna a imagem do pino correspondente ao {@code pinId}.
     *
     * @param pinId identificador do pino (0..5)
     * @return imagem do pino já dimensionada, ou {@code null} se inválido
     */
    private Image imagemDoPino(int pinId) {
        if (pinId < 0 || pinId >= imagensPinoPorId.size()) return null;
        return imagensPinoPorId.get(pinId);
    }

    /**
     * Sincroniza o vetor de últimas posições com a quantidade de jogadores
     * atual reportada pelo {@link GameManager}.
     *
     * @param n número de jogadores no momento
     */
    private void sincronizarUltimasPosicoes(int n) {
        if (ultimasPosicoes != null && ultimasPosicoes.length == n) return;
        ultimasPosicoes = new int[n];
        for (int i = 0; i < n; i++) ultimasPosicoes[i] = gm.getPosicaoDoJogadorPorIndice(i);
    }

    /**
     * Deslocamento determinístico e sutil (1px) por jogador para evitar
     * sobreposição total quando múltiplos pinos estão na mesma casa.
     *
     * @param idx índice do jogador (0..n-1)
     * @return deslocamento (dx,dy) em pixels
     */
    private static Point deslocamentoSutilPorJogador(int idx) {
        int dx = (idx % 3 == 0) ? 0 : 1; // 0,1,1
        int dy = (idx / 3 == 0) ? 0 : 1; // 0,0,1
        return new Point(dx, dy);
    }
}
