package view;

import controller.GameListener;
import controller.GameManager;

import javax.swing.*;
import java.awt.*;

/**
 * Painel simples de LOG de atividades.
 * - Caixa de texto somente leitura dentro de um JScrollPane.
 * - Limpa automaticamente quando o turno troca (o GameManager já apaga).
 */
public class PainelLog extends JPanel implements GameListener {

    private static final long serialVersionUID = 1L;

    private final GameManager game = GameManager.getInstance();
    private final JTextArea txt;

    public PainelLog() {
        super(new BorderLayout(6, 6));
        setOpaque(true);
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));

        JLabel titulo = new JLabel("Log da Rodada", SwingConstants.LEFT);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 13));
        add(titulo, BorderLayout.NORTH);

        txt = new JTextArea();
        txt.setEditable(false);
        txt.setLineWrap(true);
        txt.setWrapStyleWord(true);
        txt.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

        JScrollPane sp = new JScrollPane(txt,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        add(sp, BorderLayout.CENTER);

        game.addGameListener(this);
        refresh();
    }

    private void refresh() {
        txt.setText(game.getLogText());
        txt.setCaretPosition(txt.getDocument().getLength()); // rola pro fim
    }

    @Override
    public void onGameStateChanged() {
        SwingUtilities.invokeLater(this::refresh);
    }
}
