package model;

import static org.junit.Assert.*;
import org.junit.*;

/**
 * Lançamento de dados (1ª iteração):
 * - Cada dado deve sair entre 1 e 6; soma entre 2 e 12.
 * - Rolar dados não move o jogador (mover é outra operação).
 */
public class Iteracao1_DadosTest {

    private ModelFacade facade;

    @Before
    public void setup() {
        facade = new ModelFacade();
        facade.reset();
        facade.adicionarJogador("A");
        facade.adicionarJogador("B");
    }

    @Test
    public void dadosFaixaValida() {
        // Verifica faixas válidas para os dois dados e para a soma
        for (int i = 0; i < 300; i++) {
            int[] d = facade.lancarDados();
            assertEquals(2, d.length);
            assertTrue("d1 fora da faixa", d[0] >= 1 && d[0] <= 6);
            assertTrue("d2 fora da faixa", d[1] >= 1 && d[1] <= 6);
            int soma = d[0] + d[1];
            assertTrue("soma fora da faixa", soma >= 2 && soma <= 12);
        }
    }

    @Test
    public void lancarDados_naoAlteraPosicao() {
        // Rolar dados não deve mudar a posição (apenas sorteia)
        int posAntes = facade.getJogadorDaVezSnapshot().getPosicao();
        facade.lancarDados();
        int posDepois = facade.getJogadorDaVezSnapshot().getPosicao();
        assertEquals(posAntes, posDepois);
    }
}
