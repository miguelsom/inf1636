package model;

import java.util.Random;

/**
 * Utilitários para rolagem de dados padrão (faces 1..6).
 * Classe utilitária não instanciável.
 */
final class Dado {
    private static final Random RNG = new Random();

    private Dado() { }

    /**
     * Rola um dado de seis faces.
     *
     * @return valor inteiro entre 1 e 6 (inclusive)
     */
    static int rolar() {
        return RNG.nextInt(6) + 1;
    }

    /**
     * Rola dois dados de seis faces.
     *
     * @return array de tamanho 2 com os resultados individuais, cada um em [1, 6]
     */
    static int[] rolarDois() {
        return new int[]{rolar(), rolar()};
    }
}
