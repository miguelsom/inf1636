package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Facade do Model.
 *
 * Regras novas implementadas aqui:
 * - Limite de construção por histórico de visitas do DONO à propriedade:
 *   total de construções permitidas (casas + hotel) = visitasDoDono - 1.
 *   Ex.: 1ª vez (compra) => 0; 2ª vez => 1; 3ª vez => 2; ...
 *
 * Observações de implementação:
 * - Não alteramos Propriedade.java nem a View.
 * - Controlamos visitas do dono via um Map local (por Propriedade).
 * - Ao comprar, inicializamos visitas = 1 (a compra aconteceu numa visita).
 * - Toda vez que o dono CAI na própria propriedade, incrementamos visitas.
 * - Ao vender, removemos o contador daquela propriedade.
 */
public class ModelFacade {

    // ===== DTOs (como estavam) =====
    public static final class PlayerSnapshot {
        private final String nome; private final int saldo; private final int posicao;
        private final boolean preso; private final int qtdProps;
        public PlayerSnapshot(String nome, int saldo, int posicao, boolean preso, int qtdProps) {
            this.nome = nome; this.saldo = saldo; this.posicao = posicao; this.preso = preso; this.qtdProps = qtdProps;
        }
        public String getNome() { return nome; }
        public int getSaldo() { return saldo; }
        public int getPosicao() { return posicao; }
        public boolean isPreso() { return preso; }
        public int getQtdProps() { return qtdProps; }
    }

    public static final class MovementResult {
        private final int novaPosicao; private final String nomeCasa; private final Espaco.Tipo tipo; private final boolean companhia;
        public MovementResult(int novaPosicao, String nomeCasa, Espaco.Tipo tipo, boolean companhia) {
            this.novaPosicao = novaPosicao; this.nomeCasa = nomeCasa; this.tipo = tipo; this.companhia = companhia;
        }
        public int getNovaPosicao() { return novaPosicao; }
        public String getNomeCasa() { return nomeCasa; }
        public String getNomeEspaco() { return nomeCasa; }
        public String getTipoNome() { return (tipo == null ? "" : tipo.name()); }
        public boolean isPropriedade() { return tipo == Espaco.Tipo.PROPRIEDADE; }
        public boolean isCompanhia() { return companhia; }
        public boolean isSorteOuReves() { return tipo == Espaco.Tipo.SORTE_OU_REVES; }
    }

    public static final class PropriedadeSnapshot {
        private final String nome; private final int casas; private final boolean hotel; private final int preco; private final int precoConstrucao;
        public PropriedadeSnapshot(String nome, int casas, boolean hotel, int preco, int precoConstrucao) {
            this.nome = nome; this.casas = casas; this.hotel = hotel; this.preco = preco; this.precoConstrucao = precoConstrucao;
        }
        public String getNome() { return nome; }
        public int getCasas() { return casas; }
        public boolean isHotel() { return hotel; }
        public int getPreco() { return preco; }
        public int getPrecoConstrucao() { return precoConstrucao; }
    }

    public static final class PropriedadeInfo {
        private final String nome; private final int preco; private final int precoConstrucao; private final int casas; private final boolean hotel; private final String donoNome; private final boolean companhia;
        public PropriedadeInfo(String nome, int preco, int precoConstrucao, int casas, boolean hotel, String donoNome, boolean companhia) {
            this.nome = nome; this.preco = preco; this.precoConstrucao = precoConstrucao; this.casas = casas; this.hotel = hotel; this.donoNome = donoNome; this.companhia = companhia;
        }
        public String getNome() { return nome; }
        public int getPreco() { return preco; }
        public int getPrecoConstrucao() { return precoConstrucao; }
        public int getCasas() { return casas; }
        public boolean isHotel() { return hotel; }
        public String getDonoNome() { return donoNome; }
        public boolean isCompanhia() { return companhia; }
    }

    // ===== Estado interno =====
    private final Tabuleiro tabuleiro = new Tabuleiro();
    private final List<Jogador> jogadores = new ArrayList<>();
    private int indiceJogadorAtual = 0;

    // Controle de visitas do dono por propriedade (ver regra no cabeçalho)
    private final HashMap<Propriedade, Integer> visitasDoDono = new HashMap<>();

    // ===== Baralho de Sorte/Revés + última carta exibida =====
    private final BaralhoSorteReves baralho = new BaralhoSorteReves();
    private String ultimaCartaImagemPath = null;
    private boolean cartaSorteRevesAtiva = false;

    // ===== Setup =====
    public void reset() {
        jogadores.clear();
        indiceJogadorAtual = 0;
        cartaSorteRevesAtiva = false;
        ultimaCartaImagemPath = null;
        visitasDoDono.clear();
    }
    public void adicionarJogador(String nome) { jogadores.add(new Jogador(nome, Regras.SALDO_INICIAL)); }

    // ===== Consultas =====
    private Jogador jogadorDaVez() { return jogadores.get(indiceJogadorAtual); }

    public PlayerSnapshot getJogadorDaVezSnapshot() {
        Jogador j = jogadorDaVez();
        return new PlayerSnapshot(j.getNome(), j.getSaldo(), j.getPosicao(), j.isPreso(), j.getPropriedades().size());
    }

    public List<PlayerSnapshot> getJogadoresSnapshot() {
        List<PlayerSnapshot> out = new ArrayList<>();
        for (Jogador j : jogadores) out.add(new PlayerSnapshot(j.getNome(), j.getSaldo(), j.getPosicao(), j.isPreso(), j.getPropriedades().size()));
        return Collections.unmodifiableList(out);
    }

    public PropriedadeInfo getPropriedadeAtualInfo() {
        Jogador j = jogadorDaVez();
        Espaco e = tabuleiro.getEspaco(j.getPosicao());
        if (!(e instanceof Propriedade)) return null;
        Propriedade p = (Propriedade) e;
        String donoNome = (p.getDono() != null ? p.getDono().getNome() : null);
        boolean companhia = p.getPrecoConstrucao() <= 0;
        return new PropriedadeInfo(p.getNome(), p.getPreco(), p.getPrecoConstrucao(), p.getCasas(), p.isHotel(), donoNome, companhia);
    }

    public boolean jogoEncerrado() {
        int vivos = 0;
        for (Jogador j : jogadores) if (j.estaAtivo()) vivos++;
        return vivos <= 1;
    }

    // ===== Utilitários de construção/visitas (regra nova) =====
    /** total de construções já feitas (0..5). Hotel conta +1. */
    private static int construcoesRealizadas(Propriedade p) {
        return p.getCasas() + (p.isHotel() ? 1 : 0);
    }

    /** visitas do dono registradas para a propriedade (min 0). */
    private int visitasDoDono(Propriedade p) {
        return visitasDoDono.getOrDefault(p, 0);
    }

    /** garante que, ao comprar, a propriedade comece com visitas = 1. */
    private void inicializarVisitaAoComprar(Propriedade p) {
        // compra acontece quando o jogador já "visitou" a casa nessa rodada
        visitasDoDono.put(p, 1);
    }

    /** incrementa visitas quando o dono cai na própria propriedade. */
    private void registrarVisitaSeDono(Jogador j, Propriedade p) {
        if (p.getDono() == j) {
            int v = visitasDoDono.getOrDefault(p, 0);
            // se por algum motivo não foi inicializado na compra, trate 0->1 como a primeira
            v = (v == 0) ? 1 : (v + 1);
            visitasDoDono.put(p, v);
        }
    }

    /** remove controle de visitas ao vender. */
    private void limparVisitas(Propriedade p) {
        visitasDoDono.remove(p);
    }

    /** retorna se é permitido construir MAIS UMA etapa agora, conforme a regra. */
    private boolean podeConstruirPeloHistorico(Propriedade p) {
        if (p.getPrecoConstrucao() <= 0) return false; // companhia não constrói
        int construcoes = construcoesRealizadas(p);
        int limiteTotalPermitido = visitasDoDono(p) - 1; // i-1
        return construcoes < limiteTotalPermitido; // pode avançar +1
    }

    // ===== Dados / Movimento =====
    public int[] lancarDados() { return Dado.rolarDois(); }

    public MovementResult deslocarJogadorDaVez(int passos) {
        Jogador j = jogadorDaVez();
        int posAnterior = j.getPosicao(), tamanho = tabuleiro.tamanho();
        int soma = posAnterior + passos, novaPos = soma % tamanho;
        if (soma >= tamanho) j.creditar(Regras.BONUS_PARTIDA);
        j.setPosicao(novaPos);
        Espaco e = tabuleiro.getEspaco(novaPos);
        boolean companhia = (e instanceof Propriedade) && ((Propriedade) e).getPrecoConstrucao() <= 0;
        return new MovementResult(novaPos, e.getNome(), e.getTipo(), companhia);
    }

    public MovementResult jogarDadosDaVez(int d1, int d2) {
        Jogador j = jogadorDaVez();

        if (d1 == d2) {
            j.registrarDupla();
            if (j.getDuplasSeguidas() >= 3) {
                j.enviarParaPrisao(tabuleiro.getIndicePrisao());
                j.resetarDuplas();
                cartaSorteRevesAtiva = false; ultimaCartaImagemPath = null;
                return new MovementResult(j.getPosicao(), "Prisao", Espaco.Tipo.PRISAO, false);
            }
        } else {
            j.resetarDuplas();
        }

        int passos = d1 + d2;
        int posAnterior = j.getPosicao();
        int tamanho = tabuleiro.tamanho();
        int soma = posAnterior + passos;
        int novaPos = soma % tamanho;
        if (soma >= tamanho) j.creditar(Regras.BONUS_PARTIDA);
        j.setPosicao(novaPos);

        Espaco e = tabuleiro.getEspaco(novaPos);
        boolean companhia = (e instanceof Propriedade) && ((Propriedade) e).getPrecoConstrucao() <= 0;

        cartaSorteRevesAtiva = false; ultimaCartaImagemPath = null;

        return new MovementResult(novaPos, e.getNome(), e.getTipo(), companhia);
    }

    // ===== Prisão =====
    public boolean usarCartaSairLivreDaVez() {
        Jogador j = jogadorDaVez();
        if (j.consumirCartaSaidaLivreSeDisponivel()) { j.sairDaPrisao(); return true; }
        return false;
    }

    public boolean tentarSairDaPrisaoComDadosDaVez(int d1, int d2) {
        Jogador j = jogadorDaVez(); if (!j.isPreso()) return true;
        if (d1 == d2) { j.sairDaPrisao(); return true; }
        j.incrementarTurnoPrisao();
        if (j.getTurnosNaPrisao() >= Regras.TURNOS_MAX_PRISAO) {
            j.debitar(Regras.MULTA_SAIDA_PRISAO); j.sairDaPrisao(); return true;
        }
        return false;
    }

    public void concederCartaSairLivreJogadorDaVez() {
        Jogador j = jogadorDaVez();
        if (j != null) j.ganharCartaSaidaLivre();
    }

    // ===== Efeitos da casa atual =====
    public void processarCasaAtualDaVez() {
        Jogador j = jogadorDaVez();
        Espaco e = tabuleiro.getEspaco(j.getPosicao());
        System.out.println("[DEBUG CASA] pos=" + j.getPosicao() + " tipo=" + e.getTipo());
        switch (e.getTipo()) {
            case VA_PARA_PRISAO:
                j.enviarParaPrisao(tabuleiro.getIndicePrisao());
                cartaSorteRevesAtiva = false; ultimaCartaImagemPath = null;
                break;

            case SORTE_OU_REVES: {
                CartaSorteReves carta = baralho.comprar();
                carta.aplicar(j, jogadores, tabuleiro);
                cartaSorteRevesAtiva = true;
                ultimaCartaImagemPath = carta.getImagemPath();
                break;
            }

            case PROPRIEDADE: {
                Propriedade p = (Propriedade) e;
                Jogador dono = p.getDono();

                // 1) Se tem dono e não é o jogador da vez, trata aluguel
                if (dono != null && dono != j) {
                    final boolean ehCompanhia = p.getPrecoConstrucao() <= 0;
                    if (ehCompanhia) {
                        int aluguel = p.calcularAluguel();
                        j.debitar(aluguel);
                        dono.creditar(aluguel);
                    } else {
                        if (p.getCasas() > 0 || p.isHotel()) {
                            int aluguel = p.calcularAluguel();
                            j.debitar(aluguel);
                            dono.creditar(aluguel);
                        }
                    }
                }

                // 2) Se o dono é o jogador da vez, registra visita para liberar futuras construções
                if (dono == j) {
                    registrarVisitaSeDono(j, p);
                }

                cartaSorteRevesAtiva = false; ultimaCartaImagemPath = null;
                break;
            }

            case LUCROS_DIVIDENDOS: {
                int antes = j.getSaldo();
                j.creditar(Regras.LUCROS_DIVIDENDOS_VALOR); // +200
                int delta = j.getSaldo() - antes;
                System.out.println("[DEBUG DIVIDENDOS] +" + Regras.LUCROS_DIVIDENDOS_VALOR + " (delta=" + delta + ")");
                cartaSorteRevesAtiva = false; ultimaCartaImagemPath = null;
                break;
            }

            case PARADA_LIVRE: {
                cartaSorteRevesAtiva = false; ultimaCartaImagemPath = null;
                break;
            }

            case IMPOSTO: {
                j.debitar(Regras.IMPOSTO_RENDA_VALOR);
                cartaSorteRevesAtiva = false; ultimaCartaImagemPath = null;
                break;
            }

            case PRISAO:
            case PARTIDA:
            default:
                cartaSorteRevesAtiva = false; ultimaCartaImagemPath = null;
                break;
        }
    }

    // ===== Propriedade / compras / construção / venda =====
    public boolean comprarPropriedadeAtualDaVez() {
        Jogador j = jogadorDaVez();
        Espaco e = tabuleiro.getEspaco(j.getPosicao());
        if (!(e instanceof Propriedade)) return false;
        Propriedade p = (Propriedade) e;
        if (p.getDono() != null) return false;
        if (j.getSaldo() < p.getPreco()) return false;

        j.debitar(p.getPreco());
        p.setDono(j);
        j.adicionarPropriedade(p);

        // inicia visitas = 1 (primeira visita foi a de compra)
        inicializarVisitaAoComprar(p);
        return true;
    }

    public boolean construirNaPropriedadeAtualDaVez() {
        Jogador j = jogadorDaVez();
        Espaco e = tabuleiro.getEspaco(j.getPosicao());
        if (!(e instanceof Propriedade)) return false;
        Propriedade p = (Propriedade) e;

        // Regras básicas
        if (p.getDono() != j) return false;
        if (p.isHotel()) return false; // já no topo
        if (p.getPrecoConstrucao() <= 0) return false; // companhia não constrói
        if (j.getSaldo() < p.getPrecoConstrucao()) return false;

        // Regra nova: limite por histórico de visitas
        if (!podeConstruirPeloHistorico(p)) return false;

        // Executa UMA etapa (uma casa OU a transição 4->hotel) por chamada
        j.debitar(p.getPrecoConstrucao());
        p.construirCasaOuHotel();
        return true;
    }

    public List<PropriedadeSnapshot> getPropriedadesDoJogadorDaVez() {
        Jogador j = jogadorDaVez();
        List<PropriedadeSnapshot> out = new ArrayList<>();
        for (Propriedade p : j.getPropriedades())
            out.add(new PropriedadeSnapshot(p.getNome(), p.getCasas(), p.isHotel(), p.getPreco(), p.getPrecoConstrucao()));
        return out;
    }

    public boolean venderPropriedadePorNome(String nome) {
        Jogador j = jogadorDaVez();
        Propriedade p = tabuleiro.encontrarPropriedadePorNome(nome);
        if (p == null || p.getDono() != j) return false;
        boolean ok = p.venderDeVoltaAoBanco(j);
        if (ok) {
            j.removerPropriedade(p);
            limparVisitas(p); // remove contador de visitas
        }
        return ok;
    }

    private void removerFalidos() {
        if (jogadores.isEmpty()) return;
        for (int i = jogadores.size() - 1; i >= 0; i--) {
            Jogador j = jogadores.get(i);
            if (!j.estaAtivo()) {
                for (Propriedade p : j.limparPropriedades()) {
                    p.resetarParaBanco();
                    limparVisitas(p);
                }
                jogadores.remove(i);
                if (i < indiceJogadorAtual) indiceJogadorAtual--;
            }
        }
        if (indiceJogadorAtual < 0 && !jogadores.isEmpty()) indiceJogadorAtual = 0;
        if (indiceJogadorAtual >= jogadores.size() && !jogadores.isEmpty()) indiceJogadorAtual = 0;
    }

    public void finalizarTurno() {
        jogadorDaVez().resetarDuplas();
        removerFalidos();
        if (jogadores.isEmpty()) return;
        indiceJogadorAtual = (indiceJogadorAtual + 1) % jogadores.size();
        cartaSorteRevesAtiva = false; ultimaCartaImagemPath = null;
    }

    public void embaralharOrdemJogadores() {
        if (jogadores.size() <= 1) return;
        java.util.Collections.shuffle(jogadores, new java.util.Random());
        indiceJogadorAtual = 0;
    }

    // ===== Integração com a UI (GameManager) =====
    public boolean temCartaSorteRevesAtiva() { return cartaSorteRevesAtiva && ultimaCartaImagemPath != null; }
    public String getUltimaCartaImagemPath() { return ultimaCartaImagemPath; }
    public void limparCartaSorteReves() { cartaSorteRevesAtiva = false; ultimaCartaImagemPath = null; }
}
