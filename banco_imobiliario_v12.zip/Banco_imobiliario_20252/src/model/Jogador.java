package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Representa o estado de um jogador: saldo, posição, status de prisão
 * e portfólio de propriedades.
 */
class Jogador {

    private final String nome;
    private int saldo;
    private int posicao;
    private boolean preso;
    private int turnosNaPrisao;
    private int cartasSaidaLivre;
    private int duplasSeguidas;

    private final List<Propriedade> propriedades = new ArrayList<>();

    /**
     * Cria um jogador.
     *
     * @param nome          nome do jogador
     * @param saldoInicial  saldo inicial definido pelas regras
     */
    Jogador(String nome, int saldoInicial) {
        this.nome = nome;
        this.saldo = saldoInicial;
        this.posicao = 0;
        this.preso = false;
        this.turnosNaPrisao = 0;
        this.cartasSaidaLivre = 0;
    }

    /** @return nome do jogador */
    String getNome() { return nome; }

    /** @return saldo atual do jogador */
    int getSaldo() { return saldo; }

    /** @return posição atual no tabuleiro */
    int getPosicao() { return posicao; }

    /** @return {@code true} se o jogador está preso */
    boolean isPreso() { return preso; }

    /** @return turnos acumulados na prisão */
    int getTurnosNaPrisao() { return turnosNaPrisao; }

    /**
     * @return lista imutável das propriedades do jogador
     */
    List<Propriedade> getPropriedades() {
        return Collections.unmodifiableList(propriedades);
    }

    /**
     * Credita um valor ao saldo.
     * @param valor valor a creditar (≥ 0)
     */
    void creditar(int valor) { saldo += valor; }

    /**
     * Debita um valor do saldo.
     * @param valor valor a debitar (≥ 0)
     */
    void debitar(int valor) { saldo -= valor; }

    /**
     * Atualiza a posição no tabuleiro.
     * @param nova índice da nova posição
     */
    void setPosicao(int nova) { posicao = nova; }

    /**
     * Adiciona uma propriedade ao portfólio.
     * @param p propriedade adquirida
     */
    void adicionarPropriedade(Propriedade p) { propriedades.add(p); }

    /**
     * Remove uma propriedade do portfólio.
     * @param p propriedade a remover
     */
    void removerPropriedade(Propriedade p) { propriedades.remove(p); }

    /**
     * Remove todas as propriedades e retorna a lista removida.
     * Útil para falência e devolução ao banco.
     *
     * @return cópia das propriedades removidas
     */
    List<Propriedade> limparPropriedades() {
        List<Propriedade> copia = new ArrayList<>(propriedades);
        propriedades.clear();
        return copia;
    }

    // ===== Prisão =====

    /**
     * Envia o jogador para a prisão e reseta o contador de turnos.
     * @param indicePrisao índice do espaço de prisão no tabuleiro
     */
    void enviarParaPrisao(int indicePrisao) {
        preso = true;
        posicao = indicePrisao;
        turnosNaPrisao = 0;
    }

    /**
     * Libera o jogador da prisão e reseta o contador de turnos.
     */
    void sairDaPrisao() {
        preso = false;
        turnosNaPrisao = 0;
    }

    /** Incrementa o número de turnos passados na prisão. */
    void incrementarTurnoPrisao() { turnosNaPrisao++; }

    /**
     * Consome uma carta "Sair da Prisão" se existir.
     * @return {@code true} se havia carta e ela foi consumida
     */
    boolean consumirCartaSaidaLivreSeDisponivel() {
        if (cartasSaidaLivre > 0) { cartasSaidaLivre--; return true; }
        return false;
    }

    /** Concede ao jogador uma carta "Sair da Prisão". */
    void ganharCartaSaidaLivre() { cartasSaidaLivre++; }

    /**
     * Indica se o jogador ainda está ativo no jogo segundo as regras.
     * @return {@code true} se {@code saldo >= Regras.VALOR_MINIMO_ATIVO}
     */
    boolean estaAtivo() { return saldo >= Regras.VALOR_MINIMO_ATIVO; }

    void registrarDupla() { duplasSeguidas++; }
    void resetarDuplas() { duplasSeguidas = 0; }
    int getDuplasSeguidas() { return duplasSeguidas; }

    @Override
    public String toString() {
        return nome + " - Saldo: $" + saldo + (preso ? " (Preso)" : "");
    }
}
