package view;

import javax.swing.*;
import java.awt.*;

import controller.GameListener;
import controller.GameManager;

/**
 * Janela principal em tela única.
 *
 * Layout (BorderLayout):
 * - CENTER: Tabuleiro
 * - WEST:   Coluna com (Carta em cima, Dados embaixo)
 * - SOUTH:  PainelLog (novo)
 *
 * Sem acesso ao Model: tudo via GameManager.
 */
public class JanelaUnica extends JFrame {

    private static final long serialVersionUID = 1L;

    private final GameManager game = GameManager.getInstance();
    private boolean endDialogShown = false; // evita abrir múltiplas vezes

    public JanelaUnica() {
        super("Banco Imobiliário — Iteração 2");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));
        getContentPane().setBackground(Color.WHITE);

        // ====== CENTER: Tabuleiro ======
        PainelTabuleiro painelTabuleiro = new PainelTabuleiro();
        painelTabuleiro.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        add(painelTabuleiro, BorderLayout.CENTER);

        // ====== WEST: Coluna (Carta em cima, Dados embaixo) ======
        JPanel colunaEsquerda = new JPanel(new BorderLayout(6, 6));
        colunaEsquerda.setOpaque(false);
        colunaEsquerda.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));

        PainelCarta painelCarta = new PainelCarta();
        colunaEsquerda.add(painelCarta, BorderLayout.CENTER);

        PainelDados painelDados = new PainelDados();
        colunaEsquerda.add(painelDados, BorderLayout.SOUTH);

        colunaEsquerda.setPreferredSize(new Dimension(300, 600));
        add(colunaEsquerda, BorderLayout.WEST);

        // ====== SOUTH: LOG da rodada (NOVO) ======
        PainelLog painelLog = new PainelLog();
        painelLog.setPreferredSize(new Dimension(200, 140));
        add(painelLog, BorderLayout.SOUTH);

        // Observa fim de jogo para abrir a tela de resultados
        game.addGameListener(new GameListener() {
            @Override public void onGameStateChanged() {
                if (!endDialogShown && game.jogoEncerrado()) {
                    endDialogShown = true;
                    SwingUtilities.invokeLater(() -> {
                        EndGameDialog dlg = new EndGameDialog(
                                JanelaUnica.this,
                                game.getRankingPorSaldo()
                        );
                        dlg.setVisible(true);
                    });
                }
            }
        });

        setSize(1200, 820); // um pouco mais alto para caber o log
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JanelaUnica janela = new JanelaUnica();
            janela.setVisible(true);
        });
    }
}
