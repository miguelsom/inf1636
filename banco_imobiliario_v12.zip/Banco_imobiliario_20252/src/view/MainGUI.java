package view;

import javax.swing.*;

/**
 * Ponto de entrada da interface gráfica.
 *
 * Racional:
 * - Inicializa a UI na Event Dispatch Thread (EDT), que é a prática correta
 *   para componentes Swing, evitando condições de corrida/paint fora da thread.
 * - Exibe apenas a janela inicial (onde o usuário escolhe nº de jogadores e peões).
 *
 * Observação:
 * - Toda a lógica de jogo fica em camadas próprias (GameManager/ModelFacade);
 *   aqui fazemos apenas o "bootstrap" visual.
 */
public class MainGUI {

    /**
     * Método principal da aplicação (GUI).
     *
     * Inicializa a janela inicial, que permite ao usuário escolher o número de jogadores
     * e as cores dos peões antes de iniciar o jogo.
     *
     * @param args argumentos de linha de comando (não utilizados)
     */
    public static void main(String[] args) {
        // Inicializa a interface gráfica na Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            // Cria e exibe a janela inicial
            JanelaInicial janelaInicial = new JanelaInicial();
            janelaInicial.setVisible(true);
        });
    }
}
