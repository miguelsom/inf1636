package view;

import javax.swing.*;

import controller.GameListener;
import controller.GameManager;

import java.awt.*;

/**
 * Painel da Carta (simples e direto).
 *
 * Racional:
 * - Exibe uma única "carta ativa" por vez, priorizando Sorte/Revés quando houver.
 * - Para propriedades (terreno/companhia), usa a "view model" exposta pelo GameManager,
 *   mantendo o encapsulamento do Model (nada além da Facade).
 * - O rodapé mostra informações úteis ao jogador (tipo, dono, custo e construções).
 *
 * Imagens:
 * - Sorte/Revés:   "imagem/sorteReves/chance<1..30>.png"  (fornecida pelo GameManager)
 * - Propriedades:  "imagem/territorios/<nome>.png"  (terrenos)
 *                  "imagem/companhias/<nome>.png"   (companhias)
 */
public class PainelCarta extends JPanel implements GameListener {

    private static final long serialVersionUID = 1L;

    /** Fachada de estado/controlador acessada pela View. */
    private final GameManager game;

    /** Título da área: "Sorte/Revés" ou o nome da propriedade. */
    private final JLabel lblTitulo;
    /** Área de imagem (carta renderizada). */
    private final JLabel lblImagem;

    /** Rodapé com texto descritivo para propriedades. */
    private final JPanel rodape;
    private final JLabel lblLinhaTipoDono;  // "Tipo: Terreno|Companhia | Dono: ..."
    private final JLabel lblLinhaCustos;    // "Preço: ... | Construção: ... | Casas: ... (Hotel)"

    /**
     * Constrói o painel, registra o listener e faz a primeira atualização.
     *
     * Lógica:
     * - Layout BorderLayout com espaçamentos simples.
     * - Título no NORTH, imagem no CENTER e rodapé textual no SOUTH (apenas p/ propriedades).
     */
    public PainelCarta() {
        super(new BorderLayout(6, 6));
        this.game = GameManager.getInstance();
        this.game.addGameListener(this);

        setOpaque(true);
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        setPreferredSize(new Dimension(300, 360));

        // Cabeçalho
        lblTitulo = new JLabel("Carta", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 14));
        add(lblTitulo, BorderLayout.NORTH);

        // Imagem central
        lblImagem = new JLabel("Sem carta", SwingConstants.CENTER);
        lblImagem.setVerticalAlignment(SwingConstants.CENTER);
        add(lblImagem, BorderLayout.CENTER);

        // Rodapé textual (apenas para propriedades)
        rodape = new JPanel(new GridLayout(2, 1, 0, 2));
        rodape.setOpaque(false);

        lblLinhaTipoDono = new JLabel(" ");
        lblLinhaCustos   = new JLabel(" ");
        lblLinhaTipoDono.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblLinhaCustos.setFont(new Font("SansSerif", Font.PLAIN, 12));

        rodape.add(lblLinhaTipoDono);
        rodape.add(lblLinhaCustos);
        add(rodape, BorderLayout.SOUTH);

        atualizarConteudo();
    }

    // =====================================================================
    // Atualização de conteúdo
    // =====================================================================

    /**
     * Atualiza o painel conforme a "carta ativa".
     *
     * Regras:
     * 1) Se houver carta de Sorte/Revés, ela tem prioridade de exibição.
     * 2) Caso contrário, se a última casa for propriedade (terreno/companhia),
     *    exibe a imagem correspondente e informações básicas (tipo/dono/custos).
     * 3) Se nada disso estiver ativo, mostra "Sem carta".
     */
    private void atualizarConteudo() {
        // 1) Sorte/Revés tem prioridade
        if (game.temCartaSorteReves()) {
            lblTitulo.setText("Sorte / Revés");
            aplicarImagem(lblImagem, game.getImagemCartaSorteRevesPath(), 260, 300);
            rodape.setVisible(false);
            return;
        }

        // 2) Propriedade (terreno/companhia) usando a VM da GameManager
        if (game.isUltimaCasaPropriedade()) {
            final String nome = game.getUltimaCasaNome();
            lblTitulo.setText((nome != null && !nome.isEmpty()) ? nome : "Propriedade");

            controller.GameManager.PropriedadeVM vm = game.getPropriedadeAtualVM();
            final boolean ehCompanhia = (vm != null && vm.companhia);

            final String caminhoImg = ehCompanhia
                    ? "imagem/companhias/" + nome + ".png"
                    : "imagem/territorios/" + nome + ".png";

            aplicarImagem(lblImagem, caminhoImg, 260, 300);

            if (vm != null) {
                final String tipo = ehCompanhia ? "Companhia" : "Terreno";
                final String dono = (vm.donoNome == null ? "Banco" : vm.donoNome);
                lblLinhaTipoDono.setText("Tipo: " + tipo + "  |  Dono: " + dono);

                final String custoCompra = "Preço: R$ " + vm.preco;
                final String custoConstr = (vm.precoConstrucao > 0 ? " | Construção: R$ " + vm.precoConstrucao : "");
                final String construcoes = ehCompanhia ? "" : (" | Casas: " + vm.casas + (vm.hotel ? " (Hotel)" : ""));
                lblLinhaCustos.setText(custoCompra + custoConstr + construcoes);

                rodape.setVisible(true);
            } else {
                // Sem view model, só a imagem
                rodape.setVisible(false);
            }
            return;
        }

        // 3) Nada para mostrar
        lblTitulo.setText("Carta");
        lblImagem.setIcon(null);
        lblImagem.setText("Sem carta");
        rodape.setVisible(false);
    }

    // =====================================================================
    // Utilitários de imagem
    // =====================================================================

    /**
     * Aplica um ícone escalado no {@link JLabel} alvo, preservando proporção.
     *
     * @param alvo label que receberá a imagem.
     * @param caminho caminho do arquivo PNG (pode ser {@code null}).
     * @param maxW largura máxima desejada (pixels).
     * @param maxH altura máxima desejada (pixels).
     */
    private void aplicarImagem(JLabel alvo, String caminho, int maxW, int maxH) {
        if (caminho == null) {
            alvo.setIcon(null);
            alvo.setText("Imagem não encontrada");
            return;
        }
        ImageIcon ic = new ImageIcon(caminho);
        if (ic.getIconWidth() <= 0 || ic.getIconHeight() <= 0) {
            alvo.setIcon(null);
            alvo.setText("Imagem não encontrada");
            return;
        }
        int w = ic.getIconWidth(), h = ic.getIconHeight();
        double s = Math.min(maxW / (double) w, maxH / (double) h);
        int nw = (int) Math.round(w * s), nh = (int) Math.round(h * s);

        Image scaled = ic.getImage().getScaledInstance(nw, nh, Image.SCALE_SMOOTH);
        alvo.setText(null);
        alvo.setIcon(new ImageIcon(scaled));
    }

    // =====================================================================
    // Listener do jogo
    // =====================================================================

    /** Chamado pelo GameManager quando o estado muda; reflete a nova carta. */
    @Override
    public void onGameStateChanged() {
        atualizarConteudo();
    }
}
