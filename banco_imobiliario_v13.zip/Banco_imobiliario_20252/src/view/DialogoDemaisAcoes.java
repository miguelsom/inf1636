package view;

import controller.GameManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Diálogo de "Demais Ações" (comprar / construir / vender / listar).
 * NUNCA importa nem toca em classes do model.*.
 * Tudo passa pelo controller.GameManager.
 */
public class DialogoDemaisAcoes extends JDialog {

    private final GameManager gm = GameManager.getInstance();

    // Propriedade atual
    private JLabel lblAtualNome;
    private JLabel lblAtualDono;
    private JLabel lblAtualPreco;
    private JLabel lblAtualConstrucao;
    private JButton btnComprar;
    private JButton btnConstruir;

    // Minhas propriedades
    private DefaultListModel<String> listModel;
    private JList<String> lista;
    private JButton btnVender;

    public DialogoDemaisAcoes(Window owner) {
        super(owner, "Demais Ações", ModalityType.APPLICATION_MODAL);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        setContentPane(root);

        root.add(montarPainelPropriedadeAtual(), BorderLayout.NORTH);
        root.add(montarPainelMinhasPropriedades(), BorderLayout.CENTER);

        JPanel rodape = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnFechar = new JButton("Fechar");
        btnFechar.addActionListener(e -> dispose());
        rodape.add(btnFechar);
        root.add(rodape, BorderLayout.SOUTH);

        carregarDados();
        pack();
        setMinimumSize(new Dimension(Math.max(420, getWidth()), getHeight()));
    }

    private JPanel montarPainelPropriedadeAtual() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createTitledBorder("Propriedade Atual"));

        JPanel grid = new JPanel(new GridLayout(4, 1, 4, 4));
        lblAtualNome = new JLabel("Nome: —");
        lblAtualDono = new JLabel("Dono: —");
        lblAtualPreco = new JLabel("Preço: —");
        lblAtualConstrucao = new JLabel("Construção: —");

        grid.add(lblAtualNome);
        grid.add(lblAtualDono);
        grid.add(lblAtualPreco);
        grid.add(lblAtualConstrucao);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnComprar = new JButton("Comprar");
        btnConstruir = new JButton("Construir");

        btnComprar.addActionListener(e -> {
            boolean ok = gm.comprarPropriedadeAtual();
            if (!ok) {
                JOptionPane.showMessageDialog(this,
                        "Não foi possível comprar (já tem dono ou saldo insuficiente).",
                        "Comprar", JOptionPane.WARNING_MESSAGE);
            }
            gm.refreshUI();
            carregarDados();
        });

        btnConstruir.addActionListener(e -> {
            boolean ok = gm.construirNaPropriedadeAtual();
            if (!ok) {
                JOptionPane.showMessageDialog(this,
                        "Não foi possível construir (não é dono, é companhia, saldo insuficiente ou já tem hotel).",
                        "Construir", JOptionPane.WARNING_MESSAGE);
            }
            gm.refreshUI();
            carregarDados();
        });

        botoes.add(btnComprar);
        botoes.add(btnConstruir);

        p.add(grid, BorderLayout.CENTER);
        p.add(botoes, BorderLayout.SOUTH);
        return p;
    }

    private JPanel montarPainelMinhasPropriedades() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createTitledBorder("Minhas Propriedades"));

        listModel = new DefaultListModel<>();
        lista = new JList<>(listModel);
        lista.setVisibleRowCount(8);
        p.add(new JScrollPane(lista), BorderLayout.CENTER);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnVender = new JButton("Vender Selecionada");

        btnVender.addActionListener(e -> {
            String selecionada = lista.getSelectedValue();
            if (selecionada == null || selecionada.trim().isEmpty()) {
                Toolkit.getDefaultToolkit().beep();
                return;
            }
            // O item é "Nome — tag | Preço: R$ X" -> pega nome antes de " — "
            String nome = selecionada;
            int idx = selecionada.indexOf(" — ");
            if (idx > 0) nome = selecionada.substring(0, idx);

            boolean ok = gm.venderPropriedade(nome);
            if (!ok) {
                JOptionPane.showMessageDialog(this,
                        "Não foi possível vender esta propriedade.",
                        "Vender", JOptionPane.WARNING_MESSAGE);
            }
            gm.refreshUI();
            carregarDados();
        });

        botoes.add(btnVender);
        p.add(botoes, BorderLayout.SOUTH);
        return p;
    }

    /** Lê tudo do GameManager e preenche os widgets. */
    private void carregarDados() {
        // Propriedade atual
        GameManager.PropriedadeVM vm = gm.getPropriedadeAtualVM();
        if (vm == null) {
            lblAtualNome.setText("Nome: —");
            lblAtualDono.setText("Dono: —");
            lblAtualPreco.setText("Preço: —");
            lblAtualConstrucao.setText("Construção: —");
            btnComprar.setEnabled(false);
            btnConstruir.setEnabled(false);
        } else {
            lblAtualNome.setText("Nome: " + vm.nome);
            lblAtualDono.setText("Dono: " + (vm.donoNome == null ? "Banco" : vm.donoNome));
            lblAtualPreco.setText("Preço: R$ " + vm.preco + (vm.precoConstrucao > 0 ? " | Construção: R$ " + vm.precoConstrucao : " | Companhia"));
            lblAtualConstrucao.setText(vm.companhia ? "Construção: — (companhia)" :
                    ("Construções: casas=" + vm.casas + (vm.hotel ? " + hotel" : "")));

            boolean podeComprar  = (vm.donoNome == null);
            boolean podeConstruir = (!vm.companhia) && (vm.donoNome != null && vm.donoNome.equals(gm.getNomeJogadorDaVez()));

            btnComprar.setEnabled(podeComprar);
            btnConstruir.setEnabled(podeConstruir);
        }

        // Minhas propriedades
        listModel.clear();
        List<GameManager.PropriedadeResumo> props = gm.getPropriedadesDoJogadorDaVezVM();
        for (GameManager.PropriedadeResumo ps : props) {
            String tagConstr =
                    ps.hotel ? "hotel" :
                            (ps.casas > 0 ? (ps.casas + " casa(s)") : "sem construção");
            listModel.addElement(ps.nome + " — " + tagConstr + " | Preço: R$ " + ps.preco);
        }
        btnVender.setEnabled(!listModel.isEmpty());
    }
}
