package view;

import javax.swing.*;

import controller.GameListener;
import controller.GameManager;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

/**
 * Painel dos Dados (versão simples e estável para layout).
 */
public class PainelDados extends JPanel implements GameListener {

    private static final long serialVersionUID = 1L;

    private final GameManager game;

    // Topo (identidade do jogador da vez)
    private final JPanel painelCorDaVez;
    private final JLabel lblJogadorDaVez;

    // Centro (dados e total)
    private final JLabel lblDado1, lblDado2, lblTotal;

    // Rodapé (ações da rodada)
    private final JButton btnRolar, btnEncerrar, btnDemaisAcoes, btnEncerrarJogo;

    public PainelDados() {
        super(new BorderLayout(6, 6));
        this.game = GameManager.getInstance();
        this.game.addGameListener(this);

        setOpaque(true);
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        Dimension min = new Dimension(300, 220);
        setMinimumSize(min);
        setPreferredSize(new Dimension(360, 260));

        // TOPO
        JPanel topo = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        topo.setOpaque(false);

        painelCorDaVez = new JPanel();
        painelCorDaVez.setPreferredSize(new Dimension(16, 16));
        topo.add(painelCorDaVez);

        lblJogadorDaVez = new JLabel("Jogador");
        lblJogadorDaVez.setFont(new Font("SansSerif", Font.BOLD, 14));
        topo.add(lblJogadorDaVez);

        add(topo, BorderLayout.NORTH);

        // CENTRO
        JPanel centro = new JPanel(new GridBagLayout());
        centro.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 8, 4, 8);

        lblDado1 = new JLabel();
        lblDado2 = new JLabel();
        Dimension dIcon = new Dimension(64, 64);
        lblDado1.setPreferredSize(dIcon);
        lblDado2.setPreferredSize(dIcon);

        lblTotal = new JLabel("Total: —");
        lblTotal.setFont(new Font("SansSerif", Font.PLAIN, 13));

        c.gridx = 0; c.gridy = 0; centro.add(lblDado1, c);
        c.gridx = 1; c.gridy = 0; centro.add(lblDado2, c);
        c.gridx = 0; c.gridy = 1; c.gridwidth = 2; centro.add(lblTotal, c);

        add(centro, BorderLayout.CENTER);

        // RODAPÉ
        JPanel barra = new JPanel(new GridLayout(1, 4, 8, 0));
        barra.setOpaque(false);

        btnRolar = new JButton("Rolar");
        btnRolar.addActionListener(this::onClickRolar);

        btnEncerrar = new JButton("Encerrar Turno");
        btnEncerrar.addActionListener(this::onClickEncerrarTurno);

        btnDemaisAcoes = new JButton("Demais Ações");
        btnDemaisAcoes.addActionListener(this::onClickDemaisAcoes);
        btnDemaisAcoes.setVisible(true);

        btnEncerrarJogo = new JButton("Encerrar Jogo");
        btnEncerrarJogo.addActionListener(this::onClickEncerrarJogo);

        barra.add(btnRolar);
        barra.add(btnEncerrar);
        barra.add(btnDemaisAcoes);
        barra.add(btnEncerrarJogo);

        JPanel sul = new JPanel(new BorderLayout());
        sul.setOpaque(false);
        sul.add(barra, BorderLayout.CENTER);
        add(sul, BorderLayout.SOUTH);

        // Atalho T: teste de dados (como nas versões antigas)
        getInputMap(WHEN_ANCESTOR_OF_FOCUSED_COMPONENT)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_T, 0), "teste_dados");
        getInputMap(WHEN_IN_FOCUSED_WINDOW)
                .put(KeyStroke.getKeyStroke(KeyEvent.VK_T, 0), "teste_dados");

        getActionMap().put("teste_dados", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) {
                abrirDialogoTesteDados();
            }
        });

        atualizarUI();
    }

    // Handlers
    private void onClickRolar(ActionEvent e) {
        if (!game.podeRolarDados()) { atualizarUI(); return; }
        int[] d = game.rolarDados();
        aplicarDados(d[0], d[1]);
        atualizarUI();
    }

    private void onClickEncerrarTurno(ActionEvent e) {
        if (game.podeRolarDados()) { atualizarUI(); return; }
        game.encerrarTurno();
        atualizarUI();
    }

    /** Abre o diálogo de ações (comprar/construir/vender/listar). */
    private void onClickDemaisAcoes(ActionEvent e) {
        if (game.podeRolarDados()) {
            Toolkit.getDefaultToolkit().beep();
            return;
        }
        Window owner = SwingUtilities.getWindowAncestor(this);
        DialogoDemaisAcoes dlg = new DialogoDemaisAcoes(owner);
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
        game.refreshUI();
        atualizarUI();
    }

    /** Força encerramento do jogo (abre tela final via listener da JanelaUnica). */
    private void onClickEncerrarJogo(ActionEvent e) {
        int opt = JOptionPane.showConfirmDialog(
                this,
                "Encerrar o jogo agora e mostrar o resultado?",
                "Encerrar Jogo",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );
        if (opt == JOptionPane.YES_OPTION) {
            game.encerrarJogoAgora();
        }
    }

    // Diálogo didático
    private void abrirDialogoTesteDados() {
        if (!game.podeRolarDados()) { Toolkit.getDefaultToolkit().beep(); return; }

        JDialog dlg = new JDialog(
                SwingUtilities.getWindowAncestor(this),
                "Teste de Dados",
                Dialog.ModalityType.APPLICATION_MODAL
        );
        dlg.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new GridBagLayout());
        root.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);

        Integer[] faces = {1, 2, 3, 4, 5, 6};
        JComboBox<Integer> cb1 = new JComboBox<>(faces);
        JComboBox<Integer> cb2 = new JComboBox<>(faces);

        c.gridx=0; c.gridy=0; c.anchor=GridBagConstraints.EAST; root.add(new JLabel("Dado 1:"), c);
        c.gridx=1; c.gridy=0; c.anchor=GridBagConstraints.WEST; root.add(cb1, c);
        c.gridx=0; c.gridy=1; c.anchor=GridBagConstraints.EAST; root.add(new JLabel("Dado 2:"), c);
        c.gridx=1; c.gridy=1; c.anchor=GridBagConstraints.WEST; root.add(cb2, c);

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 4));
        JButton btnCancelar = new JButton("Cancelar");
        JButton btnAplicar  = new JButton("Aplicar");
        botoes.add(btnCancelar);
        botoes.add(btnAplicar);

        c.gridx=0; c.gridy=2; c.gridwidth=2; c.anchor=GridBagConstraints.EAST;
        root.add(botoes, c);

        btnCancelar.addActionListener(ev -> dlg.dispose());
        btnAplicar.addActionListener(ev -> {
            Integer v1 = (Integer) cb1.getSelectedItem();
            Integer v2 = (Integer) cb2.getSelectedItem();
            if (v1 == null || v2 == null) { Toolkit.getDefaultToolkit().beep(); return; }
            if (!game.podeRolarDados()) { Toolkit.getDefaultToolkit().beep(); dlg.dispose(); return; }
            game.rolarDadosForcado(v1, v2);
            dlg.dispose();
        });

        dlg.setContentPane(root);
        dlg.pack();
        dlg.setLocationRelativeTo(this);
        dlg.setVisible(true);
    }

    // UI
    private void atualizarUI() {
        lblJogadorDaVez.setText(game.getNomeJogadorDaVez() + " — Saldo: R$ " + game.getSaldoJogadorDaVez());
        painelCorDaVez.setBackground(corParaPinId(game.getPinIdDoJogadorDaVez()));

        int[] d = game.getUltimoLancamento();
        if (d != null && d.length >= 2 && d[0] > 0 && d[1] > 0) {
            aplicarDados(d[0], d[1]);
        } else {
            limparDados();
        }

        boolean podeRolar = game.podeRolarDados();
        btnRolar.setEnabled(podeRolar);
        btnEncerrar.setEnabled(!podeRolar);
        btnDemaisAcoes.setEnabled(!podeRolar);
        btnEncerrarJogo.setEnabled(true); // sempre pode encerrar

        revalidate();
        repaint();
    }

    private void aplicarDados(int d1, int d2) {
        aplicarIconeDado(lblDado1, d1);
        aplicarIconeDado(lblDado2, d2);
        lblTotal.setText("Total: " + (d1 + d2));
    }

    private void limparDados() {
        lblDado1.setIcon(null);
        lblDado2.setIcon(null);
        lblTotal.setText("Total: —");
    }

    private void aplicarIconeDado(JLabel alvo, int valor) {
        ImageIcon ic = new ImageIcon("imagem/dados/die_face_" + valor + ".png");
        if (ic.getIconWidth() > 0) {
            Image scaled = ic.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
            alvo.setIcon(new ImageIcon(scaled));
            alvo.setText(null);
        } else {
            alvo.setIcon(null);
            alvo.setText(String.valueOf(valor));
        }
    }

    private static Color corParaPinId(int pinId) {
        switch (pinId % 6) {
            case 0: return new Color(220, 40, 50);
            case 1: return new Color(40, 80, 220);
            case 2: return new Color(245, 130, 30);
            case 3: return new Color(240, 200, 40);
            case 4: return new Color(150, 80, 200);
            default:return new Color(120, 120, 120);
        }
    }

    @Override
    public void onGameStateChanged() {
        atualizarUI();
    }
}
