package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tabuleiro do jogo (índices 0..39) com espaços fixos e propriedades nomeadas.
 * <p>
 * Características:
 * <ul>
 *   <li>Índice da prisão definido dinamicamente durante a montagem.</li>
 *   <li>Lookup O(1) de propriedades por nome (case-insensitive).</li>
 *   <li>Companhias usam {@code precoConstrucao = 0} (não constroem).</li>
 * </ul>
 * </p>
 */
class Tabuleiro {

    private final List<Espaco> espacos = new ArrayList<>();
    private final Map<String, Propriedade> propriedadesPorNome = new HashMap<>();
    private int indicePrisao = -1; // definido em montar()

    /** Constrói e monta o tabuleiro padrão. */
    Tabuleiro() { montar(); }

    /** Registra a propriedade no tabuleiro e no índice por nome. */
    private void registrar(Propriedade p) {
        espacos.add(p);
        propriedadesPorNome.put(p.getNome().toLowerCase(), p);
    }

    /**
     * Fábrica interna de {@link Propriedade}.
     *
     * @param nome nome exibível
     * @param preco preço de compra
     * @param aluguelBase aluguel sem construção
     * @param a1 aluguel com 1 casa
     * @param a2 aluguel com 2 casas
     * @param a3 aluguel com 3 casas
     * @param a4 aluguel com 4 casas
     * @param hotel aluguel com hotel
     * @param precoConstrucao custo por construção (0 para companhias)
     * @return propriedade criada
     */
    private Propriedade prop(String nome, int preco, int aluguelBase,
                             int a1, int a2, int a3, int a4, int hotel, int precoConstrucao) {
        return new Propriedade(nome, preco, aluguelBase, a1, a2, a3, a4, hotel, precoConstrucao);
    }

    /** Monta a sequência de 40 espaços do tabuleiro padrão. */
    private void montar() {
        // 0 PARTIDA
        espacos.add(new Espaco("PARTIDA", Espaco.Tipo.PARTIDA) {});

        // 1 Leblon
        registrar(prop("Leblon", 100, 6, 30, 90, 270, 400, 550, 50));
        // 2 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 3 Av. Presidente Vargas
        registrar(prop("Av. Presidente Vargas", 60, 2, 10, 30, 90, 160, 250, 50));
        // 4 Av. Nossa Sra. De Copacabana
        registrar(prop("Av. Nossa Sra. De Copacabana", 60, 4, 20, 60, 180, 320, 450, 50));
        // 5 Companhia Ferroviária (companhia)
        registrar(prop("Companhia Ferroviária", 200, 25, 50, 100, 200, 300, 400, 0));
        // 6 Av. Brigadeiro Faria Lima
        registrar(prop("Av. Brigadeiro Faria Lima", 100, 6, 30, 90, 270, 400, 550, 50));
        // 7 Companhia de Viação (companhia)
        registrar(prop("Companhia de Viação", 200, 25, 50, 100, 200, 300, 400, 0));
        // 8 Av. Rebouças
        registrar(prop("Av. Rebouças", 100, 6, 30, 90, 270, 400, 550, 50));
        // 9 Av. 9 de Julho
        registrar(prop("Av. 9 de Julho", 120, 8, 40, 100, 300, 450, 600, 50));

        // 10 PRISÃO (de visita) - índice dinâmico
        indicePrisao = espacos.size();
        espacos.add(new Espaco("PRISÃO", Espaco.Tipo.PRISAO) {});

        // 11 Av. Europa
        registrar(prop("Av. Europa", 140, 10, 50, 150, 450, 625, 750, 100));
        // 12 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 13 Rua Augusta
        registrar(prop("Rua Augusta", 140, 10, 50, 150, 450, 625, 750, 100));
        // 14 Av. Pacaembú
        registrar(prop("Av. Pacaembú", 160, 12, 60, 180, 500, 700, 900, 100));
        // 15 Companhia de Táxi (companhia)
        registrar(prop("Companhia de Táxi", 200, 25, 50, 100, 200, 300, 400, 0));
        // 16 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 17 Interlagos
        registrar(prop("Interlagos", 180, 14, 70, 200, 550, 750, 950, 100));
        // 18 Lucros ou Dividendos
        espacos.add(new Espaco("Lucros ou Dividendos", Espaco.Tipo.LUCROS_DIVIDENDOS) {});
        // 19 Morumbi
        registrar(prop("Morumbi", 200, 16, 80, 220, 600, 800, 1000, 100));

        // 20 PARADA LIVRE
        espacos.add(new Espaco("PARADA LIVRE", Espaco.Tipo.PARADA_LIVRE) {});

        // 21 Flamengo
        registrar(prop("Flamengo", 220, 18, 90, 250, 700, 875, 1050, 150));
        // 22 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 23 Botafogo
        registrar(prop("Botafogo", 220, 18, 90, 250, 700, 875, 1050, 150));
        // 24 Imposto de Renda
        espacos.add(new Espaco("Imposto de Renda", Espaco.Tipo.IMPOSTO) {});
        // 25 Companhia de Navegação (companhia)
        registrar(prop("Companhia de Navegação", 200, 25, 50, 100, 200, 300, 400, 0));
        // 26 Av. Brasil
        registrar(prop("Av. Brasil", 260, 22, 110, 330, 800, 975, 1150, 150));
        // 27 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 28 Av. Paulista
        registrar(prop("Av. Paulista", 260, 22, 110, 330, 800, 975, 1150, 150));
        // 29 Jardim Europa
        registrar(prop("Jardim Europa", 280, 24, 120, 360, 850, 1025, 1200, 150));

        // 30 VÁ PARA A PRISÃO
        espacos.add(new Espaco("VÁ PARA A PRISÃO", Espaco.Tipo.VA_PARA_PRISAO) {});

        // 31 Copacabana
        registrar(prop("Copacabana", 300, 26, 130, 390, 900, 1100, 1275, 200));
        // 32 Companhia de Aviação (companhia)
        registrar(prop("Companhia de Aviação", 200, 25, 50, 100, 200, 300, 400, 0));
        // 33 Av. Vieira Souto
        registrar(prop("Av. Vieira Souto", 300, 26, 130, 390, 900, 1100, 1275, 200));
        // 34 Av. Atlântica
        registrar(prop("Av. Atlântica", 320, 28, 150, 450, 1000, 1200, 1400, 200));
        // 35 Companhia de Táxi Aéreo (companhia)
        registrar(prop("Companhia de Táxi Aéreo", 200, 25, 50, 100, 200, 300, 400, 0));
        // 36 Ipanema
        registrar(prop("Ipanema", 350, 35, 175, 500, 1100, 1300, 1500, 200));
        // 37 Sorte ou Revés
        espacos.add(new Espaco("Sorte ou Revés", Espaco.Tipo.SORTE_OU_REVES) {});
        // 38 Jardim Paulista
        registrar(prop("Jardim Paulista", 400, 50, 200, 600, 1400, 1700, 2000, 200));
        // 39 Brooklin
        registrar(prop("Brooklin", 400, 50, 200, 600, 1400, 1700, 2000, 200));
    }

    /** @return quantidade de espaços no tabuleiro */
    int tamanho() { return espacos.size(); }

    /**
     * Retorna o espaço pelo índice.
     * @param idx índice (0..tamanho()-1)
     * @return espaço correspondente
     * @throws IndexOutOfBoundsException se o índice for inválido
     */
    Espaco getEspaco(int idx) { return espacos.get(idx); }

    /** @return índice do espaço de prisão */
    int getIndicePrisao() { return indicePrisao; }

    /**
     * Busca de propriedade por nome com complexidade O(1), ignorando maiúsculas/minúsculas.
     *
     * @param nome nome da propriedade (case-insensitive)
     * @return a propriedade correspondente ou {@code null} se não encontrada
     */
    Propriedade encontrarPropriedadePorNome(String nome) {
        if (nome == null) return null;
        return propriedadesPorNome.get(nome.toLowerCase());
    }
    
 // dentro de model.Tabuleiro
    public int getIndicePartida() {
        return 0; // índice da casa "PARTIDA" no seu tabuleiro
    }

}
