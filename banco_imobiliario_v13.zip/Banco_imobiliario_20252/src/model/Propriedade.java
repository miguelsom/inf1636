package model;

/**
 * Propriedade adquirível com construção (casas/hotel) e cálculo de aluguel.
 * 
 * Convenções desta iteração:
 * 
 * 	Terrenos só cobram aluguel quando houver ≥ 1 casa ou hotel (regra aplicada na Facade).</li>
 * 	Companhias (quando {@code precoConstrucao == 0}) não constroem e cobram aluguel-base (regra aplicada na Facade).</li>
 * 
 * 
 */
class Propriedade extends Espaco {

    private final int preco;
    private final int aluguelBase;
    private final int aluguel1Casa;
    private final int aluguel2Casas;
    private final int aluguel3Casas;
    private final int aluguel4Casas;
    private final int aluguelHotel;
    private final int precoConstrucao; // 0 para companhias (não constroem)

    private Jogador dono;

    private int casas;      // 0..4
    private boolean hotel;  // true se já virou hotel

    /**
     * Cria uma propriedade.
     *
     * @param nome            nome exibível
     * @param preco           preço de compra
     * @param aluguelBase     aluguel sem construção
     * @param aluguel1Casa    aluguel com 1 casa
     * @param aluguel2Casas   aluguel com 2 casas
     * @param aluguel3Casas   aluguel com 3 casas
     * @param aluguel4Casas   aluguel com 4 casas
     * @param aluguelHotel    aluguel com hotel
     * @param precoConstrucao custo por construção (casa/hotel); 0 para companhias
     */
    Propriedade(String nome, int preco, int aluguelBase,
                int aluguel1Casa, int aluguel2Casas, int aluguel3Casas, int aluguel4Casas,
                int aluguelHotel, int precoConstrucao) {
        super(nome, Tipo.PROPRIEDADE);
        this.preco = preco;
        this.aluguelBase = aluguelBase;
        this.aluguel1Casa = aluguel1Casa;
        this.aluguel2Casas = aluguel2Casas;
        this.aluguel3Casas = aluguel3Casas;
        this.aluguel4Casas = aluguel4Casas;
        this.aluguelHotel = aluguelHotel;
        this.precoConstrucao = precoConstrucao;
        this.dono = null;
        this.casas = 0;
        this.hotel = false;
    }

    int getPreco() { return preco; }

    int getPrecoConstrucao() { return precoConstrucao; }

    Jogador getDono() { return dono; }

    /** Define o dono da propriedade. */
    void setDono(Jogador novo) { this.dono = novo; }

    /** @return número de casas (0..4) */
    int getCasas() { return casas; }

    /** @return {@code true} se há hotel construído */
    boolean isHotel() { return hotel; }

    /**
     * Constrói uma unidade:
     * incrementa casa até 4; na próxima, converte em hotel.
     * Não tem efeito se já houver hotel.
     */
    void construirCasaOuHotel() {
        if (hotel) return;
        if (casas < 4) {
            casas++;
        } else {
            hotel = true;
        }
    }

    /**
     * Calcula o aluguel conforme o estágio de construção.
     *
     * @return valor de aluguel aplicável (base/casas/hotel)
     */
    int calcularAluguel() {
        if (precoConstrucao == 0) {
            // Companhias: regra aplicada na Facade, aqui devolvemos sempre o base
            return aluguelBase;
        }

        if (hotel) {
            return aluguelHotel;
        }
        switch (casas) {
            case 1:  return aluguel1Casa;
            case 2:  return aluguel2Casas;
            case 3:  return aluguel3Casas;
            case 4:  return aluguel4Casas;
            default: return aluguelBase;
        }
    }

    /** Reseta a propriedade ao estado do banco (sem dono e sem construções). */
    void resetarParaBanco() {
        dono = null;
        casas = 0;
        hotel = false;
    }

    /**
     * Atualiza diretamente o estado de construções (casas/hotel).
     * Uso exclusivo para rotinas de carregamento (save/load).
     */
    void carregarEstadoConstrucoes(int casas, boolean hotel) {
        if (casas < 0) casas = 0;
        if (casas > 4) casas = 4;
        this.casas = casas;
        this.hotel = hotel;
    }

    /**
     * Vende a propriedade de volta ao banco por ~90% do investimento total.
     * O investimento total considera: preço de compra + custo das casas + custo do hotel (se houver).
     *
     * @param vendedor jogador que está vendendo; deve ser o dono atual
     * @return {@code true} se a venda foi realizada; {@code false} caso não seja o dono
     */
    boolean venderDeVoltaAoBanco(Jogador vendedor) {
        if (dono != vendedor) return false;
        int valorInvestido = preco + casas * precoConstrucao + (hotel ? precoConstrucao : 0);
        int valorVenda = (int) Math.round(valorInvestido * 0.90);
        vendedor.creditar(valorVenda);
        resetarParaBanco();
        return true;
    }
}
