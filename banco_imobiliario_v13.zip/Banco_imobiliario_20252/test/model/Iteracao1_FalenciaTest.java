package model;

import static org.junit.Assert.*;
import org.junit.*;

/**
 * Falência (1ª iteração):
 * - Falência por multas de prisão.
 * - Falência por aluguel (hotel).
 * - Remoção só ocorre ao finalizarTurno().
 */
public class Iteracao1_FalenciaTest {

    private ModelFacade facade;

    @Before
    public void setup() {
        facade = new ModelFacade();
        facade.reset();
        facade.adicionarJogador("A");
        facade.adicionarJogador("B");
    }

    // Funções Auxiliares
    private void moverAte(String nome) {
        int guard = 0;
        while (guard++ < 200) {
            ModelFacade.MovementResult mv = facade.deslocarJogadorDaVez(1);
            if (mv.getNomeEspaco().equalsIgnoreCase(nome)) break;
        }
    }
    private void processHere() { facade.processarCasaAtualDaVez(); }
    private void endTurn()     { facade.finalizarTurno(); }
    private int saldoDaVez()   { return facade.getJogadorDaVezSnapshot().getSaldo(); }

    @Test
    public void falenciaPorMultasDePrisao() {
        // Falência por multas: B cai na prisão repetidas vezes, paga a multa na 3ª tentativa, até ficar < 1.
        // Remoção confirmada apenas após finalizar o turno.
        endTurn(); // agora é B

        int guard = 0;
        while (saldoDaVez() >= Regras.VALOR_MINIMO_ATIVO && guard++ < 2000) {
            moverAte("VÁ PARA A PRISÃO");
            processHere();
            assertTrue(facade.getJogadorDaVezSnapshot().isPreso());

            int saldoAntes = saldoDaVez();
            assertFalse(facade.tentarSairDaPrisaoComDadosDaVez(1, 2));
            assertFalse(facade.tentarSairDaPrisaoComDadosDaVez(2, 3));
            assertTrue(facade.tentarSairDaPrisaoComDadosDaVez(3, 5)); // paga multa
            assertEquals(saldoAntes - Regras.MULTA_SAIDA_PRISAO, saldoDaVez());

            int jogadoresAntes = facade.getJogadoresSnapshot().size();
            endTurn(); // B encerra; se quebrou, remove aqui

            if (facade.getJogadoresSnapshot().size() < jogadoresAntes) {
                assertEquals(1, facade.getJogadoresSnapshot().size());
                return;
            }
            endTurn(); // volta para B
        }
        fail("Não foi possível provocar falência no limite previsto.");
    }

    @Test
    public void falenciaPorAluguel() {
        // Falência por aluguel: A deixa Ibirapuera com hotel; B cai 1+ vezes até ficar < 1.
        // Remoção confirmada apenas após finalizar o turno de B.
        facade.deslocarJogadorDaVez(39);
        assertTrue(facade.comprarPropriedadeAtualDaVez());
        for (int i = 0; i < 4; i++) {
            facade.deslocarJogadorDaVez(40);
            assertTrue(facade.construirNaPropriedadeAtualDaVez());
        }
        facade.deslocarJogadorDaVez(40);
        assertTrue(facade.construirNaPropriedadeAtualDaVez()); // hotel

        endTurn(); // B
        facade.deslocarJogadorDaVez(39);
        processHere();

        int guard = 0;
        while (facade.getJogadorDaVezSnapshot().getSaldo() >= Regras.VALOR_MINIMO_ATIVO && guard++ < 10) {
            endTurn(); // B -> A
            endTurn(); // A -> B
            facade.deslocarJogadorDaVez(40);
            processHere();
        }

        assertEquals(2, facade.getJogadoresSnapshot().size()); // antes do finish, não remove
        endTurn(); // remove ao finalizar turno do B
        assertEquals(1, facade.getJogadoresSnapshot().size());
    }
}
