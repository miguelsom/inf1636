package view;

import javax.swing.*;
import java.awt.*;

import controller.GameListener;
import controller.GameManager;

/**
 * PainelStatus ("Mais Ações") desacoplado do model.
 * Agora sem exibir o saldo (ele foi para o PainelDados ao lado do nome).
 */
public class PainelStatus extends JPanel implements GameListener {

    private static final long serialVersionUID = 1L;

    private final GameManager game;

    private final JLabel lblJogador;
    private final JLabel lblPosicao;
    private final JLabel lblProps;

    private final JButton btnRolar;
    private final JButton btnEncerrar;

    public PainelStatus() {
        super(new BorderLayout(8, 8));
        setOpaque(true);
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        this.game = GameManager.getInstance();
        this.game.addGameListener(this);

        // Título
        JLabel titulo = new JLabel("Mais Ações", SwingConstants.LEFT);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 14));
        add(titulo, BorderLayout.NORTH);

        // Centro com infos (sem saldo)
        JPanel centro = new JPanel(new GridLayout(3, 1, 4, 4));
        centro.setOpaque(false);

        lblJogador = linha("Jogador da vez: —");
        lblPosicao = linha("Posição: —");
        lblProps   = linha("Propriedades: —");

        centro.add(lblJogador);
        centro.add(lblPosicao);
        centro.add(lblProps);
        add(centro, BorderLayout.CENTER);

        // Rodapé com botões
        JPanel rodape = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rodape.setOpaque(false);

        btnRolar = new JButton("Rolar Dados");
        btnEncerrar = new JButton("Encerrar Turno");

        btnRolar.addActionListener(e -> {
            if (game.podeRolarDados()) game.rolarDados();
            atualizarBotoes();
        });

        btnEncerrar.addActionListener(e -> {
            game.encerrarTurno();
            atualizarBotoes();
        });

        rodape.add(btnRolar);
        rodape.add(btnEncerrar);
        add(rodape, BorderLayout.SOUTH);

        // Primeira carga
        refresh();
        atualizarBotoes();
    }

    private static JLabel linha(String txt) {
        JLabel l = new JLabel(txt);
        l.setFont(new Font("SansSerif", Font.PLAIN, 12));
        return l;
    }

    /** Atualiza textos lendo SEMPRE do GameManager (sem cache local). */
    private void refresh() {
        String nome = game.getNomeJogadorDaVez();
        lblJogador.setText("Jogador da vez: " + nome);

        lblPosicao.setText("Posição: " + game.getPosicaoJogadorDaVez());
        lblProps.setText("Propriedades: " + game.getQtdPropriedadesJogadorDaVez());
    }

    private void atualizarBotoes() {
        boolean pode = game.podeRolarDados();
        boolean terminou = game.jogoEncerrado();
        btnRolar.setEnabled(pode && !terminou);
        btnEncerrar.setEnabled(!pode && !terminou);
    }

    @Override
    public void onGameStateChanged() {
        SwingUtilities.invokeLater(() -> {
            refresh();
            atualizarBotoes();
        });
    }
}
