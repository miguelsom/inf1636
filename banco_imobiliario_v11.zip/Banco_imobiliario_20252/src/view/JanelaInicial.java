package view;

import javax.swing.*;

import controller.GameManager;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.HashSet;
import java.util.Set;

/**
 * Janela inicial do jogo.
 *
 * Racional:
 * - Passo 1: usuário escolhe a quantidade de jogadores (3..6).
 * - Passo 2: cada jogador escolhe um peão (pin0..pin5) sem duplicações.
 * - Passo 3: inicia a partida via {@link GameManager}, define os pins por jogador
 *            e abre a janela principal em tela única ({@link JanelaUnica}).
 *
 * Observações de design:
 * - A ordem de turnos NÃO é definida aqui; ela é embaralhada no backend
 *   (GameManager/ModelFacade) para manter o encapsulamento das regras.
 * - Não há acesso direto ao Model; a View conversa apenas com o GameManager.
 */
public class JanelaInicial extends JFrame {

    private static final long serialVersionUID = 1L;

    /** Combo com a quantidade de jogadores (3..6). */
    private final JComboBox<Integer> comboQuantidade;

    /** Painel onde ficam as linhas de seleção de pinos por jogador. */
    private final JPanel painelSelecaoPinos;

    /** Um combo por jogador para escolher o peão (pin0..pin5). */
    private JComboBox<PinItem>[] combosDePinos;

    /** Botão de iniciar partida. */
    private final JButton botaoIniciar;

    // Opções fixas de pinos
    private static final PinItem[] OPCOES_PINO = new PinItem[] {
            new PinItem(0, "Vermelho (pin0)"),
            new PinItem(1, "Azul (pin1)"),
            new PinItem(2, "Laranja (pin2)"),
            new PinItem(3, "Amarelo (pin3)"),
            new PinItem(4, "Roxo (pin4)"),
            new PinItem(5, "Cinza (pin5)")
    };

    /**
     * Constrói a janela inicial com layout simples:
     * - Norte: seleção de quantidade.
     * - Centro: linhas "Jogador i" + combo de pin.
     * - Sul: botão "Iniciar Partida".
     */
    @SuppressWarnings("unchecked")
    public JanelaInicial() {
        super("Banco Imobiliário — Nova Partida");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(12, 12));
        setResizable(false);

        // ===== Norte: quantidade de jogadores =====
        JPanel topo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        topo.add(new JLabel("Número de jogadores:"));

        comboQuantidade = new JComboBox<>(new Integer[]{3, 4, 5, 6});
        comboQuantidade.setSelectedItem(3);
        comboQuantidade.addActionListener(e -> recriarLinhasDePinos());
        topo.add(comboQuantidade);

        add(topo, BorderLayout.NORTH);

        // ===== Centro: seleção de pinos =====
        painelSelecaoPinos = new JPanel(new GridBagLayout());
        painelSelecaoPinos.setBorder(BorderFactory.createTitledBorder("Seleção de pinos (sem repetição)"));
        add(painelSelecaoPinos, BorderLayout.CENTER);

        // ===== Sul: iniciar =====
        JPanel sul = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        botaoIniciar = new JButton("Iniciar Partida");
        botaoIniciar.addActionListener(this::onClickIniciar);
        sul.add(botaoIniciar);
        add(sul, BorderLayout.SOUTH);

        // Inicializa as linhas conforme valor padrão do combo
        recriarLinhasDePinos();

        pack();
        setLocationRelativeTo(null);
    }

    // =====================================================================
    // UI: criação/atualização dinâmica das linhas de pinos
    // =====================================================================

    /**
     * Recria as linhas de seleção de pinos conforme a quantidade atual.
     *
     * Racional:
     * - Para cada jogador, gera uma linha "Jogador i" + combo com as 6 opções.
     * - Sugere seleções iniciais distintas (padrão: índice i) para acelerar o setup.
     */
    @SuppressWarnings("unchecked")
    private void recriarLinhasDePinos() {
        painelSelecaoPinos.removeAll();

        int qtd = (Integer) comboQuantidade.getSelectedItem();
        combosDePinos = new JComboBox[qtd];

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 8, 6, 8);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1.0;

        for (int i = 0; i < qtd; i++) {
            c.gridx = 0; c.gridy = i;
            painelSelecaoPinos.add(new JLabel("Jogador " + (i + 1) + ":"), c);

            JComboBox<PinItem> combo = new JComboBox<>(OPCOES_PINO);
            combo.setSelectedIndex(i % OPCOES_PINO.length); // sugestão diferente por jogador

            c.gridx = 1;
            painelSelecaoPinos.add(combo, c);

            combosDePinos[i] = combo;
        }

        painelSelecaoPinos.revalidate();
        painelSelecaoPinos.repaint();
        pack();
        setLocationRelativeTo(null);
    }

    // =====================================================================
    // Ação: iniciar partida
    // =====================================================================

    /**
     * Handler do botão "Iniciar Partida".
     *
     * Lógica:
     * - Valida a quantidade (3..6).
     * - Coleta os pins escolhidos, garantindo que não haja repetição.
     * - Dispara o backend: {@link GameManager#iniciarNovaPartida(int)} e
     *   {@link GameManager#definirPinsPorJogador(int[])}.
     * - Abre a {@link JanelaUnica} e fecha a janela inicial.
     *
     * @param e evento do Swing (não utilizado).
     */
    private void onClickIniciar(ActionEvent e) {
        Integer qtd = (Integer) comboQuantidade.getSelectedItem();
        if (qtd == null) qtd = 3;
        if (qtd < 3) qtd = 3;
        if (qtd > 6) qtd = 6;

        // Coleta e valida pinos sem repetição
        int[] pinIds = new int[qtd];
        Set<Integer> usados = new HashSet<>();
        for (int i = 0; i < qtd; i++) {
            PinItem item = (PinItem) combosDePinos[i].getSelectedItem();
            if (item == null) {
                JOptionPane.showMessageDialog(this,
                        "Selecione um pin para o Jogador " + (i + 1) + ".",
                        "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (usados.contains(item.id)) {
                JOptionPane.showMessageDialog(this,
                        "Dois jogadores não podem escolher o mesmo pin.\nConflito no Jogador " + (i + 1) + ".",
                        "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }
            usados.add(item.id);
            pinIds[i] = item.id;
        }

        // Backend: prepara a nova partida e fixa os pins por jogador
        GameManager gm = GameManager.getInstance();
        gm.iniciarNovaPartida(qtd);
        gm.definirPinsPorJogador(pinIds);

        // Abre a janela principal e fecha a inicial
        JanelaUnica janelaPrincipal = new JanelaUnica();
        janelaPrincipal.setVisible(true);
        dispose();
    }

    // =====================================================================
    // Apoio: item do combo de pinos
    // =====================================================================

    /**
     * Item simples para o combo de pinos.
     *
     * Racional:
     * - Mantém o id numérico (0..5) que corresponde aos arquivos de imagem
     *   "imagem/pinos/pin<id>.png" e uma descrição legível para o usuário.
     */
    private static final class PinItem {
        final int id;
        final String label;
        PinItem(int id, String label) { this.id = id; this.label = label; }
        @Override public String toString() { return label; }
    }

    // =====================================================================
    // Ponto de entrada opcional (somente a janela inicial)
    // =====================================================================

    /**
     * Executa apenas a JanelaInicial (útil para testes de UI isolados).
     *
     * @param args argumentos de linha de comando (não utilizados).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JanelaInicial janelaInicial = new JanelaInicial();
            janelaInicial.setVisible(true);
        });
    }
}
