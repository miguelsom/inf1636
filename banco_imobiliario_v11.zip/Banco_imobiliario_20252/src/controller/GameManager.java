package controller;

import model.ModelFacade;

import java.util.*;

/**
 * GameManager (Singleton)
 * UI só conversa com este cara. Nada de Model na View.
 */
public final class GameManager {

    // ===================== Singleton =====================
    private static final GameManager INSTANCE = new GameManager();
    public static GameManager getInstance() { return INSTANCE; }
    private GameManager() {}

    // ===================== Núcleo (Facade interna) =====================
    private final ModelFacade model = new ModelFacade();

    // ===================== Listeners (UI) =====================
    private final List<GameListener> listeners = new ArrayList<>();
    public void addGameListener(GameListener l) {
        if (l == null) return;
        synchronized (listeners) {
            if (!listeners.contains(l)) listeners.add(l);
        }
    }
    public void removeGameListener(GameListener l) {
        if (l == null) return;
        synchronized (listeners) { listeners.remove(l); }
    }
    private void notificarListeners() {
        List<GameListener> snap;
        synchronized (listeners) { snap = new ArrayList<>(listeners); }
        for (GameListener l : snap) {
            try { l.onGameStateChanged(); } catch (Exception ignored) {}
        }
    }
    /** Permite que a View force um refresh/repaint. */
    public void refreshUI() { notificarListeners(); }

    // ===================== Info por índice de ordem =====================
    public int getPosicaoDoJogadorPorIndice(int idx) {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        if (idx < 0 || idx >= snaps.size()) return 0;
        return snaps.get(idx).getPosicao();
    }
    public String getNomeJogadorPorIndice(int idx) {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        if (idx < 0 || idx >= snaps.size()) return "—";
        return snaps.get(idx).getNome();
    }
    public int getSaldoDoJogadorPorIndice(int idx) {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        if (idx < 0 || idx >= snaps.size()) return 0;
        return snaps.get(idx).getSaldo();
    }

    // ===================== Estado de UI / Fluxo =====================
    private boolean podeRolar = true;
    private int[] ultimoLancamento = {0, 0};
    private String ultimaCasaNome = null;
    private boolean ultimaCasaEhPropriedade = false;
    private boolean encerradoForcado = false;

    // ===================== Peões (pins) =====================
    private final Map<String, Integer> pinPorNome = new HashMap<>();
    private int[] pinIdPorJogador = new int[0];

    // ===================== Sorte/Revés (exibição) =====================
    private boolean mostrarSorteReves = false;
    private String caminhoCartaSorteReves = null;

    // ===================== LOG DE ATIVIDADES (para PainelLog) =====================
    private final List<String> activityLog = new ArrayList<>();
    private void addLog(String msg) {
        if (msg == null || msg.isEmpty()) return;
        activityLog.add(msg);
        notificarListeners();
    }
    public String getLogText() {
        if (activityLog.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String s : activityLog) sb.append(s).append("\n");
        return sb.toString();
    }
    /** Apaga o log (usado ao trocar de turno). */
    private void clearLog() {
        activityLog.clear();
        notificarListeners();
    }

    // ===================== DTOs expostos à View =====================
    /** VM da propriedade onde o jogador DA VEZ está parado. */
    public static final class PropriedadeVM {
        public final String nome;
        public final int preco;
        public final int precoConstrucao;
        public final int casas;
        public final boolean hotel;
        public final String donoNome;   // null = Banco
        public final Integer donoPinId; // null = Banco
        public final boolean companhia;

        public PropriedadeVM(String nome, int preco, int precoConstrucao,
                             int casas, boolean hotel,
                             String donoNome, Integer donoPinId,
                             boolean companhia) {
            this.nome = nome;
            this.preco = preco;
            this.precoConstrucao = precoConstrucao;
            this.casas = casas;
            this.hotel = hotel;
            this.donoNome = donoNome;
            this.donoPinId = donoPinId;
            this.companhia = companhia;
        }
    }

    /** Resumo de propriedade do JOGADOR DA VEZ (para listar e vender). */
    public static final class PropriedadeResumo {
        public final String nome;
        public final int preco;
        public final int precoConstrucao;
        public final int casas;
        public final boolean hotel;
        public final boolean companhia;

        public PropriedadeResumo(String nome, int preco, int precoConstrucao,
                                 int casas, boolean hotel, boolean companhia) {
            this.nome = nome;
            this.preco = preco;
            this.precoConstrucao = precoConstrucao;
            this.casas = casas;
            this.hotel = hotel;
            this.companhia = companhia;
        }
    }

    // ============================================================
    // Setup / Nova Partida
    // ============================================================
    public void iniciarNovaPartida(int qtdJogadores) {
        if (qtdJogadores < 3) qtdJogadores = 3;
        if (qtdJogadores > 6) qtdJogadores = 6;

        model.reset();
        for (int i = 1; i <= qtdJogadores; i++) model.adicionarJogador("Jogador " + i);
        if (qtdJogadores > 1) model.embaralharOrdemJogadores();

        podeRolar = true;
        ultimoLancamento[0] = ultimoLancamento[1] = 0;
        ultimaCasaNome = null;
        ultimaCasaEhPropriedade = false;

        mostrarSorteReves = false;
        caminhoCartaSorteReves = null;

        pinPorNome.clear();
        for (int i = 1; i <= qtdJogadores; i++) pinPorNome.put("Jogador " + i, (i - 1) % 6);

        clearLog();
        addLog("Nova partida iniciada com " + qtdJogadores + " jogadores.");
        addLog("Vez de: " + getNomeJogadorDaVez());

        reconstruirPinsNaOrdemAtual();
        notificarListeners();
    }

    public void definirPinsPorJogador(int[] pinIds) {
        if (pinIds == null) return;
        int n = getNumeroJogadores();
        if (pinIds.length != n) return;

        pinPorNome.clear();
        for (int i = 1; i <= n; i++) pinPorNome.put("Jogador " + i, pinIds[i - 1]);
        reconstruirPinsNaOrdemAtual();
        notificarListeners();
    }

    private void reconstruirPinsNaOrdemAtual() {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        pinIdPorJogador = new int[snaps.size()];
        for (int i = 0; i < snaps.size(); i++) {
            String nome = snaps.get(i).getNome();
            Integer pin = pinPorNome.get(nome);
            pinIdPorJogador[i] = (pin != null) ? pin : (i % 6);
        }
    }

    // ============================================================
    // Consultas para a View
    // ============================================================
    public int getNumeroJogadores() { return model.getJogadoresSnapshot().size(); }
    public String getNomeJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getNome() : "—";
    }
    public int getSaldoJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getSaldo() : 0;
    }
    public int getPosicaoJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getPosicao() : 0;
    }
    public int getQtdPropriedadesJogadorDaVez() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null) ? s.getQtdProps() : 0;
    }

    public boolean podeRolarDados() { return podeRolar; }
    public int[] getUltimoLancamento() { return ultimoLancamento.clone(); }
    public String getUltimaCasaNome() { return ultimaCasaNome; }
    public boolean isUltimaCasaPropriedade() { return ultimaCasaEhPropriedade; }

    public int getPinIdDoJogador(int idx) {
        if (idx < 0 || idx >= pinIdPorJogador.length) return idx % 6;
        return pinIdPorJogador[idx];
    }
    public int getPinIdDoJogadorDaVez() {
        String nome = getNomeJogadorDaVez();
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        for (int i = 0; i < snaps.size(); i++) {
            if (snaps.get(i).getNome().equals(nome)) return getPinIdDoJogador(i);
        }
        return 0;
    }

    // ===================== Propriedade atual (para PainelCarta/ações) =====================
    public PropriedadeVM getPropriedadeAtualVM() {
        ModelFacade.PropriedadeInfo info = model.getPropriedadeAtualInfo();
        if (info == null) return null;

        Integer donoPin = null;
        if (info.getDonoNome() != null) {
            Integer p = pinPorNome.get(info.getDonoNome());
            if (p != null) donoPin = p;
        }

        return new PropriedadeVM(
                info.getNome(),
                info.getPreco(),
                info.getPrecoConstrucao(),
                info.getCasas(),
                info.isHotel(),
                info.getDonoNome(),
                donoPin,
                info.isCompanhia()
        );
    }

    // ===================== Sorte/Revés (exibição) =====================
    public boolean temCartaSorteReves() { return mostrarSorteReves && caminhoCartaSorteReves != null; }
    public String getImagemCartaSorteRevesPath() { return caminhoCartaSorteReves; }
    public void limparCartaSorteReves() {
        mostrarSorteReves = false;
        caminhoCartaSorteReves = null;
        model.limparCartaSorteReves();
        notificarListeners();
    }

    public boolean jogadorDaVezEstaPreso() {
        ModelFacade.PlayerSnapshot s = model.getJogadorDaVezSnapshot();
        return (s != null && s.isPreso());
    }

    // ===================== Ações principais (turno) =====================
    public int[] rolarDados() {
        if (!podeRolar) return getUltimoLancamento();

        int[] d = model.lancarDados();
        ultimoLancamento = d.clone();

        if (jogadorDaVezEstaPreso()) {
            boolean saiu = model.tentarSairDaPrisaoComDadosDaVez(d[0], d[1]);
            if (saiu) {
                addLog(getNomeJogadorDaVez() + " saiu da prisão com dupla (" + d[0] + "+" + d[1] + ").");
                ModelFacade.MovementResult mr = model.deslocarJogadorDaVez(d[0] + d[1]);
                model.processarCasaAtualDaVez();
                aplicarMovementResult(mr);
            } else {
                addLog(getNomeJogadorDaVez() + " tentou sair da prisão (" + d[0] + "+" + d[1] + "), mas não conseguiu.");
                aplicarMovementResult(null);
            }
            podeRolar = false;
            notificarListeners();
            return getUltimoLancamento();
        }

        ModelFacade.MovementResult mr = model.jogarDadosDaVez(d[0], d[1]);
        addLog(getNomeJogadorDaVez() + " rolou " + d[0] + "+" + d[1] + " e parou em " + mr.getNomeEspaco() + " (" + mr.getTipoNome() + ").");
        model.processarCasaAtualDaVez();
        aplicarMovementResult(mr);

        boolean dupla = (d[0] == d[1]);
        boolean foiParaPrisao = jogadorDaVezEstaPreso()
                || (mr != null && "VA_PARA_PRISAO".equals(mr.getTipoNome()));

        if (foiParaPrisao) addLog(getNomeJogadorDaVez() + " foi para a PRISÃO.");
        if (dupla && !foiParaPrisao) addLog("Dupla! " + getNomeJogadorDaVez() + " pode rolar novamente.");

        podeRolar = (!foiParaPrisao) && dupla; // só joga de novo se dupla e não foi preso
        notificarListeners();
        return getUltimoLancamento();
    }

    public int[] rolarDadosForcado(int d1, int d2) {
        if (!podeRolar) return getUltimoLancamento();
        if (d1 < 1 || d1 > 6 || d2 < 1 || d2 > 6) return getUltimoLancamento();

        ultimoLancamento = new int[]{d1, d2};

        if (jogadorDaVezEstaPreso()) {
            boolean saiu = model.tentarSairDaPrisaoComDadosDaVez(d1, d2);
            if (saiu) {
                addLog(getNomeJogadorDaVez() + " saiu da prisão com dupla (" + d1 + "+" + d2 + ").");
                ModelFacade.MovementResult mr = model.deslocarJogadorDaVez(d1 + d2);
                model.processarCasaAtualDaVez();
                aplicarMovementResult(mr);
            } else {
                addLog(getNomeJogadorDaVez() + " tentou sair da prisão (" + d1 + "+" + d2 + "), mas não conseguiu.");
                aplicarMovementResult(null);
            }
            podeRolar = false;
            notificarListeners();
            return getUltimoLancamento();
        }

        ModelFacade.MovementResult mr = model.jogarDadosDaVez(d1, d2);
        addLog(getNomeJogadorDaVez() + " rolou " + d1 + "+" + d2 + " e parou em " + mr.getNomeEspaco() + " (" + mr.getTipoNome() + ").");
        model.processarCasaAtualDaVez();
        aplicarMovementResult(mr);

        boolean dupla = (d1 == d2);
        boolean foiParaPrisao = jogadorDaVezEstaPreso()
                || (mr != null && "VA_PARA_PRISAO".equals(mr.getTipoNome()));

        if (foiParaPrisao) addLog(getNomeJogadorDaVez() + " foi para a PRISÃO.");
        if (dupla && !foiParaPrisao) addLog("Dupla! " + getNomeJogadorDaVez() + " pode rolar novamente.");

        podeRolar = (!foiParaPrisao) && dupla;
        notificarListeners();
        return getUltimoLancamento();
    }

    private void aplicarMovementResult(ModelFacade.MovementResult mr) {
        if (mr != null) {
            ultimaCasaNome = mr.getNomeEspaco();
            ultimaCasaEhPropriedade = mr.isPropriedade();

            if (model.temCartaSorteRevesAtiva()) {
                caminhoCartaSorteReves = model.getUltimaCartaImagemPath();
                mostrarSorteReves = (caminhoCartaSorteReves != null);
                if (mostrarSorteReves) addLog("Carta Sorte/Revés revelada.");
            } else {
                mostrarSorteReves = false;
                caminhoCartaSorteReves = null;
            }
        } else {
            mostrarSorteReves = false;
            caminhoCartaSorteReves = null;
        }
    }

    public void encerrarTurno() {
        String atual = getNomeJogadorDaVez();
        model.finalizarTurno();

        podeRolar = true;
        ultimoLancamento[0] = ultimoLancamento[1] = 0;
        ultimaCasaNome = null;
        ultimaCasaEhPropriedade = false;

        mostrarSorteReves = false;
        caminhoCartaSorteReves = null;

        clearLog(); // APAGA o log ao trocar de turno (seu pedido)
        addLog("Vez de: " + getNomeJogadorDaVez());

        reconstruirPinsNaOrdemAtual();
        notificarListeners();
    }
    
 // ===================== Encerramento de jogo =====================
    /** Força o encerramento do jogo agora (abre tela final via listener da janela). */
    public void encerrarJogoAgora() {
        this.encerradoForcado = true;
        notificarListeners();
    }

    /** True se o jogo acabou por falência/eliminação OU por forçamento. */
    public boolean jogoEncerrado() {
        return encerradoForcado || model.jogoEncerrado();
    }

    // ============================================================
    // Delegates (View chama só estes métodos)
    // ============================================================
    public List<PropriedadeResumo> getPropriedadesDoJogadorDaVezVM() {
        List<ModelFacade.PropriedadeSnapshot> src = model.getPropriedadesDoJogadorDaVez();
        List<PropriedadeResumo> out = new ArrayList<>();
        for (ModelFacade.PropriedadeSnapshot ps : src) {
            out.add(new PropriedadeResumo(
                    ps.getNome(),
                    ps.getPreco(),
                    ps.getPrecoConstrucao(),
                    ps.getCasas(),
                    ps.isHotel(),
                    ps.getPrecoConstrucao() <= 0
            ));
        }
        return Collections.unmodifiableList(out);
    }

    public boolean comprarPropriedadeAtual() {
        boolean ok = model.comprarPropriedadeAtualDaVez();
        if (ok) addLog(getNomeJogadorDaVez() + " comprou \"" + (getPropriedadeAtualVM()!=null?getPropriedadeAtualVM().nome:"propriedade") + "\".");
        else addLog("Compra não realizada.");
        notificarListeners();
        return ok;
    }

    public boolean construirNaPropriedadeAtual() {
        boolean ok = model.construirNaPropriedadeAtualDaVez();
        if (ok) addLog(getNomeJogadorDaVez() + " construiu em \"" + (getPropriedadeAtualVM()!=null?getPropriedadeAtualVM().nome:"propriedade") + "\".");
        else addLog("Construção não permitida agora.");
        notificarListeners();
        return ok;
    }

    public boolean venderPropriedade(String nome) {
        boolean ok = model.venderPropriedadePorNome(nome);
        if (ok) addLog(getNomeJogadorDaVez() + " vendeu \"" + nome + "\" ao banco.");
        else addLog("Venda não realizada.");
        notificarListeners();
        return ok;
    }

    // ===================== Ranking / Encerramento =====================
    public static final class RankingItem {
        public final String nome;
        public final int saldo;
        public RankingItem(String nome, int saldo) { this.nome = nome; this.saldo = saldo; }
    }

    /** Retorna ranking por saldo (desc). */
    public List<RankingItem> getRankingPorSaldo() {
        List<ModelFacade.PlayerSnapshot> snaps = model.getJogadoresSnapshot();
        List<RankingItem> list = new ArrayList<>();
        for (ModelFacade.PlayerSnapshot s : snaps) list.add(new RankingItem(s.getNome(), s.getSaldo()));
        list.sort((a,b) -> Integer.compare(b.saldo, a.saldo));
        return list;
    }
}
