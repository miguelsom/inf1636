package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import static model.CartaSorteReves.Efeito;
import static model.CartaSorteReves.Tipo;

/**
 * Baralho fixo (30 cartas) baseado nas imagens chance1..chance30.png.
 * Embaralha no início e recicla quando termina.
 */
public final class BaralhoSorteReves {

    private final List<CartaSorteReves> cartas = new ArrayList<>();
    private int topo = 0;

    public BaralhoSorteReves() {
        // ==== SORTE (recebas, avanço, saída livre) ====
        cartas.add(new CartaSorteReves( 1, Tipo.SORTE, Efeito.RECEBER,         25, "Valorização do terreno"));
	cartas.add(new CartaSorteReves( 2, Tipo.SORTE, Efeito.RECEBER,         150, "Assalto segurado"));
	cartas.add(new CartaSorteReves( 3, Tipo.SORTE, Efeito.RECEBER,         80, "Empréstimo devolvido"));
        cartas.add(new CartaSorteReves( 4, Tipo.SORTE, Efeito.RECEBER,        200, "Ações em alta"));
        cartas.add(new CartaSorteReves( 5, Tipo.SORTE, Efeito.RECEBER,         50, "Troca de carro lucrativa"));
        cartas.add(new CartaSorteReves( 6, Tipo.SORTE, Efeito.RECEBER,         50, "13º salário"));
        cartas.add(new CartaSorteReves( 7, Tipo.SORTE, Efeito.RECEBER,        100, "1º lugar no torneio de tênis"));
        cartas.add(new CartaSorteReves( 8, Tipo.SORTE, Efeito.RECEBER,        100, "1º prêmio do cachorro"));
        cartas.add(new CartaSorteReves( 9, Tipo.SORTE, Efeito.CARTA_SAIDA_LIVRE, 0, "Saída livre da prisão"));
        cartas.add(new CartaSorteReves( 10, Tipo.SORTE, Efeito.AVANCAR_PARTIDA,  0, "Avance ao ponto de partida"));
        cartas.add(new CartaSorteReves( 11, Tipo.SORTE, Efeito.RECEBER_DE_CADA, 50, "Receba 50 de cada um"));
        cartas.add(new CartaSorteReves( 12, Tipo.SORTE, Efeito.RECEBER,         45, "Economizou o hotel"));
        cartas.add(new CartaSorteReves( 13, Tipo.SORTE, Efeito.RECEBER,        100, "Herança"));
        cartas.add(new CartaSorteReves( 14, Tipo.SORTE, Efeito.RECEBER,        100, "Promoção a diretor"));
        cartas.add(new CartaSorteReves( 15, Tipo.SORTE, Efeito.RECEBER,         20, "Loteria esportiva"));

        // ==== REVÉS (pagamentos e prisão direta) ====
        cartas.add(new CartaSorteReves( 16, Tipo.REVES, Efeito.PAGAR,            15, "Empréstimo a amigo"));
        cartas.add(new CartaSorteReves(17, Tipo.REVES, Efeito.PAGAR,            25, "Comprar apartamento"));
        cartas.add(new CartaSorteReves(18, Tipo.REVES, Efeito.PAGAR,            45, "Hotel de montanha"));
        cartas.add(new CartaSorteReves(19, Tipo.REVES, Efeito.PAGAR,            30, "Ballet"));
        cartas.add(new CartaSorteReves(20, Tipo.REVES, Efeito.PAGAR,           100, "Festa de aniversário"));
        cartas.add(new CartaSorteReves(21, Tipo.REVES, Efeito.PAGAR,           100, "Despesas de maternidade"));
        cartas.add(new CartaSorteReves(22, Tipo.REVES, Efeito.PAGAR,            40, "Livros novos"));
        cartas.add(new CartaSorteReves(23, Tipo.REVES, Efeito.IR_PARA_PRISAO,    0, "Vá para a prisão (sem receber nada)"));
        cartas.add(new CartaSorteReves(24, Tipo.REVES, Efeito.PAGAR,            30, "Estacionou na contramão"));
        cartas.add(new CartaSorteReves(25, Tipo.REVES, Efeito.PAGAR,            50, "Imposto de renda"));
        cartas.add(new CartaSorteReves(26, Tipo.REVES, Efeito.PAGAR,            25, "Clube ampliando piscinas"));
        cartas.add(new CartaSorteReves(27, Tipo.REVES, Efeito.PAGAR,            30, "Renovar licença do automóvel"));
        cartas.add(new CartaSorteReves(28, Tipo.REVES, Efeito.PAGAR,            45, "Parentes em 'férias' na sua casa"));
        cartas.add(new CartaSorteReves(29, Tipo.REVES, Efeito.PAGAR,            50, "Filhos na escola - 1ª mensalidade"));
        cartas.add(new CartaSorteReves(30, Tipo.REVES, Efeito.PAGAR,            50, "Geada na safra de café"));

        embaralhar();
    }

    public void embaralhar() {
        Collections.shuffle(cartas, new java.util.Random());
        topo = 0;
    }

    /** Compra a próxima carta; recicla o baralho ao fim. */
    public CartaSorteReves comprar() {
        if (cartas.isEmpty()) throw new IllegalStateException("Baralho vazio");
        if (topo >= cartas.size()) topo = 0;
        return cartas.get(topo++);
    }
}
