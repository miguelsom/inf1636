package model;

import static org.junit.Assert.*;
import org.junit.*;

/**
 * Prisão (1ª iteração):
 * - Entrar na prisão, sair com dupla, sair na 3ª pagando multa.
 * - Usar carta sem possuir (nega).
 * - Tentativas sem dupla mantêm preso.
 * - Tentativa sair com carta
 */
public class Iteracao1_PrisaoTest {

    private ModelFacade facade;

    @Before
    public void setup() {
        facade = new ModelFacade();
        facade.reset();
        facade.adicionarJogador("A");
        facade.adicionarJogador("B");
    }

    // Funções Auxiliares
    private void moverAte(String nome) {
        int guard = 0;
        while (guard++ < 300) {
            ModelFacade.MovementResult mv = facade.deslocarJogadorDaVez(1);
            if (mv.getNomeEspaco().equalsIgnoreCase(nome)) break;
        }
    }
    private void processHere() { facade.processarCasaAtualDaVez(); }

    @Test
    public void prisao_fluxoBasico_semCarta() {
        // Vai para a prisão
        moverAte("VÁ PARA A PRISÃO");
        processHere();
        assertTrue(facade.getJogadorDaVezSnapshot().isPreso());

        // Carta sem possuir → nega
        assertFalse(facade.usarCartaSairLivreDaVez());

        // Sai com dupla
        assertTrue(facade.tentarSairDaPrisaoComDadosDaVez(4, 4));
        assertFalse(facade.getJogadorDaVezSnapshot().isPreso());

        // Preso de novo
        moverAte("VÁ PARA A PRISÃO");
        processHere();
        assertTrue(facade.getJogadorDaVezSnapshot().isPreso());

        // Falha 2 vezes, na 3ª paga multa e sai
        assertFalse(facade.tentarSairDaPrisaoComDadosDaVez(1, 2));
        assertTrue(facade.getJogadorDaVezSnapshot().isPreso());
        assertFalse(facade.tentarSairDaPrisaoComDadosDaVez(2, 3));
        assertTrue(facade.getJogadorDaVezSnapshot().isPreso());

        int saldoAntes = facade.getJogadorDaVezSnapshot().getSaldo();
        assertTrue(facade.tentarSairDaPrisaoComDadosDaVez(3, 5));
        int saldoDepois = facade.getJogadorDaVezSnapshot().getSaldo();

        assertFalse(facade.getJogadorDaVezSnapshot().isPreso());
        assertEquals(saldoAntes - Regras.MULTA_SAIDA_PRISAO, saldoDepois);
    }

    @Test
    public void tentativasIndependentesMantemPreso() {
        // Continua preso enquanto não obtém dupla
        moverAte("VÁ PARA A PRISÃO");
        processHere();
        assertTrue(facade.getJogadorDaVezSnapshot().isPreso());

        assertFalse(facade.tentarSairDaPrisaoComDadosDaVez(1, 2));
        assertTrue(facade.getJogadorDaVezSnapshot().isPreso());

        assertFalse(facade.tentarSairDaPrisaoComDadosDaVez(2, 1));
        assertTrue(facade.getJogadorDaVezSnapshot().isPreso());
    }
    
    @Test
    public void prisao_comCarta_soltoNoProximoTurno() {
        // Concede a carta ao jogador da vez (A)
        facade.concederCartaSairLivreJogadorDaVez();

        // A cai em "VÁ PARA A PRISÃO" e fica preso
        moverAte("VÁ PARA A PRISÃO");
        processHere();
        assertTrue("Deveria estar preso após cair em 'VÁ PARA A PRISÃO'",
                facade.getJogadorDaVezSnapshot().isPreso());

        // Encerramos o turno de A -> B; B não faz nada -> volta para A (próximo turno de A)
        facade.finalizarTurno(); // A -> B
        facade.finalizarTurno(); // B -> A

        // No início do novo turno de A, usar a carta e sair da prisão
        assertTrue("Com carta, deveria conseguir sair da prisão",
                facade.usarCartaSairLivreDaVez());
        assertFalse("Após usar a carta, não deve continuar preso",
                facade.getJogadorDaVezSnapshot().isPreso());

        // Carta é consumida: segunda tentativa deve falhar
        assertFalse("A carta deve ter sido consumida",
                facade.usarCartaSairLivreDaVez());
    }

}
